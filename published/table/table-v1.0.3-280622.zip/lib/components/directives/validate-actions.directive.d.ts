import { TemplateRef, ViewContainerRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ValidateActionDirective {
    private templateRef;
    private viewContainer;
    constructor(templateRef: TemplateRef<any>, viewContainer: ViewContainerRef);
    set validateActions({ rowData: rowData, actions: actions }: {
        rowData: any;
        actions: any;
    });
    static ɵfac: i0.ɵɵFactoryDeclaration<ValidateActionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ValidateActionDirective, "[validateActions]", never, { "validateActions": "validateActions"; }, {}, never>;
}
