export declare enum TableSortSelectionModes {
    Single = "single",
    Multiple = "multiple"
}
