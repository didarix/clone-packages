export interface ITablePageOptions {
    pageSize?: number;
    totalCount?: number;
    pagesCount?: number;
    pageNumber?: number;
    searchKey?: string;
}
