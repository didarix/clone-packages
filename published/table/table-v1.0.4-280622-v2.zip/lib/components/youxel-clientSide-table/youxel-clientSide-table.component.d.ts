import { EventEmitter, OnInit } from '@angular/core';
import { SortEvent } from 'primeng/api';
import { DialogService } from 'primeng/dynamicdialog';
import { IColumnsOptions, ITableActions, ITableOptions, UrlListItem } from '../../models/interfaces';
import { ColumnDataTypes } from '../../models/enums';
import { YxlTableService } from '../../services/yxl-table.service';
import { LanguageService } from '@youxel/core';
import { ITranslatedItemsFromEndUser } from '../../models/interfaces';
import { TranslateService } from '@ngx-translate/core';
import * as i0 from "@angular/core";
export declare class YouxelClientSideTableComponent implements OnInit {
    languageService: LanguageService;
    private dialogService;
    service: YxlTableService;
    private translateService;
    data: any;
    columns: IColumnsOptions[];
    selectedData: any[];
    options: ITableOptions;
    actions: ITableActions[];
    roles: ITableActions[];
    id: string;
    primaryKey: string;
    /**
     * all needed translation text for table package
     *
     *  the actions col header
     *
     * text for the model header
     *
     * text for the model button
     *
     * text for the model button
     *
     */
    tableTranslatedItemsFromEndUser: ITranslatedItemsFromEndUser;
    urls: UrlListItem;
    onSelected: EventEmitter<any[]>;
    onItemSelected: EventEmitter<any>;
    onSendUserInfo: EventEmitter<any>;
    onStatusChanged: EventEmitter<boolean>;
    onItemDeleted: EventEmitter<boolean>;
    onEditItem: EventEmitter<any>;
    deleteModal: any;
    columnDataTypes: typeof ColumnDataTypes;
    selectedItem: any[];
    openActionPopup: boolean;
    expandedRows: {};
    sortOrder: string;
    item: string;
    isAscending: boolean;
    constructor(languageService: LanguageService, dialogService: DialogService, service: YxlTableService, translateService: TranslateService);
    ngOnInit(): void;
    onSort(event: SortEvent): void;
    validateAction(event: any): boolean;
    validateCustomAction(event: any): boolean;
    actionClick(event: any): void;
    onRowSelect(event: any): void;
    onRowUnselect(event: any): void;
    cellClicked(col: IColumnsOptions, row: any, callback?: any): any;
    editUserRoles(event: any): void;
    handleStatusChange(rowData: any): void;
    onImageError(event: any, col: any): void;
    applyAction(event: any): void;
    deleteRow(row: any): void;
    editRow(row: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<YouxelClientSideTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<YouxelClientSideTableComponent, "app-youxel-clientSide-table", never, { "data": "data"; "columns": "columns"; "selectedData": "selectedData"; "options": "options"; "actions": "actions"; "roles": "roles"; "id": "id"; "primaryKey": "primaryKey"; "tableTranslatedItemsFromEndUser": "tableTranslatedItemsFromEndUser"; "urls": "urls"; }, { "onSelected": "onSelected"; "onItemSelected": "onItemSelected"; "onSendUserInfo": "onSendUserInfo"; "onStatusChanged": "onStatusChanged"; "onItemDeleted": "onItemDeleted"; "onEditItem": "onEditItem"; }, never, never>;
}
