import { DoCheck, EventEmitter, OnInit } from '@angular/core';
import { IColumnsOptions, ITableActions, ITableOptions, ITranslatedItemsFromEndUser, UrlListItem } from './models/interfaces';
import { YxlTableService } from './services/yxl-table.service';
import * as i0 from "@angular/core";
export declare class DataTableComponent implements OnInit, DoCheck {
    service: YxlTableService;
    data: any;
    urls: UrlListItem;
    columns: IColumnsOptions[];
    options: ITableOptions;
    actions: ITableActions;
    id: string;
    /**
     * all needed translation text for table package
     *
     *  the actions col header
     *
     * text for the model header
     *
     * text for the model button
     *
     * text for the model button
     *
     */
    tableTranslatedItemsFromEndUser: ITranslatedItemsFromEndUser;
    onSendUserInfo: EventEmitter<any>;
    onStatusChanged: EventEmitter<boolean>;
    onItemDeleted: EventEmitter<boolean>;
    onGetData: EventEmitter<any>;
    onSortData: EventEmitter<any>;
    onEditItem: EventEmitter<any>;
    onFilterReseted: EventEmitter<any>;
    tableTranslatedItems: ITranslatedItemsFromEndUser;
    constructor(service: YxlTableService);
    ngOnInit(): void;
    ngDoCheck(): void;
    toggleResultFilter(): boolean;
    sendUserData(event: any): void;
    resetFilter(): void;
    onClickEditItem(event: any): void;
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DataTableComponent, "app-data-table", never, { "data": "data"; "urls": "urls"; "columns": "columns"; "options": "options"; "actions": "actions"; "id": "id"; "tableTranslatedItemsFromEndUser": "tableTranslatedItemsFromEndUser"; }, { "onSendUserInfo": "onSendUserInfo"; "onStatusChanged": "onStatusChanged"; "onItemDeleted": "onItemDeleted"; "onGetData": "onGetData"; "onSortData": "onSortData"; "onEditItem": "onEditItem"; "onFilterReseted": "onFilterReseted"; }, never, ["[yxlTable='title']", "[yxlTable='addBtn']", "[yxlTable='filterModal']", "[yxlTable='filterResult']", "[emptyList]"]>;
}
