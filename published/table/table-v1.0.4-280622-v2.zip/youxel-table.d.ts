/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@youxel/table" />
export * from './index';
