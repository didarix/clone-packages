import { EventEmitter, OnInit } from '@angular/core';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import * as i0 from "@angular/core";
export declare class ModalComponent implements OnInit {
    ref: DynamicDialogRef;
    config: DynamicDialogConfig;
    title: string;
    template: any;
    rowData: any;
    buttonsText: {
        delete: string;
        cancel: string;
    };
    passEntry: EventEmitter<boolean>;
    closeModal: EventEmitter<any>;
    constructor(ref: DynamicDialogRef, config: DynamicDialogConfig);
    ngOnInit(): void;
    confirm(data: any): void;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModalComponent, "Delete-confirm-dailog", never, { "buttonsText": "buttonsText"; }, { "passEntry": "passEntry"; "closeModal": "closeModal"; }, never, ["*"]>;
}
