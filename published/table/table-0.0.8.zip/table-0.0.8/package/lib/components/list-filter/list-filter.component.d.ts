import { OnInit, EventEmitter } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormlyFieldConfig } from '@ngx-formly/core';
import { LanguageService } from '@youxel/core';
import { YxlTableService } from '../../services/yxl-table.service';
import * as i0 from "@angular/core";
export declare class ListFilterComponent implements OnInit {
    private yxlTableService;
    languageService: LanguageService;
    formGroup: FormGroup;
    fields: FormlyFieldConfig[];
    model: {
        [key: string]: any;
    };
    filterBtnStyle: any;
    buttonsText: {
        apply: string;
        close: string;
    };
    closeFilterPopup: EventEmitter<any>;
    filteredData: EventEmitter<any>;
    filterpopup: boolean;
    isActive: boolean;
    constructor(yxlTableService: YxlTableService, languageService: LanguageService);
    ngOnInit(): void;
    openFilter(): void;
    closeFilter(): void;
    sendFilterData(): void;
    hideFilterPopup(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListFilterComponent, "youxel-list-filter", never, { "formGroup": "formGroup"; "fields": "fields"; "model": "model"; "filterBtnStyle": "filterBtnStyle"; "buttonsText": "buttonsText"; "isActive": "isActive"; }, { "closeFilterPopup": "closeFilterPopup"; "filteredData": "filteredData"; }, never, never>;
}
