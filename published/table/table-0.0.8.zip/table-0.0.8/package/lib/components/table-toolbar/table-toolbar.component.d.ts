import { OnInit } from '@angular/core';
import { ITableOptions } from '../../models';
import * as i0 from "@angular/core";
export declare class TableToolbarComponent implements OnInit {
    options: ITableOptions;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TableToolbarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TableToolbarComponent, "youxel-table-toolbar", never, { "options": "options"; }, {}, never, ["*"]>;
}
