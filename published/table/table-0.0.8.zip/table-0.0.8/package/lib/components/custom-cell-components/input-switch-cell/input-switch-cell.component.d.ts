import { EventEmitter } from '@angular/core';
import { IColumnsOptions } from '../../../models';
import * as i0 from "@angular/core";
export declare class InputSwitchCellComponent {
    col: IColumnsOptions;
    rowData: any;
    statusChangedEmitter: EventEmitter<any>;
    constructor();
    emitStatusChange(row: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputSwitchCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputSwitchCellComponent, "table-input-switch-cell", never, { "col": "col"; "rowData": "rowData"; }, { "statusChangedEmitter": "statusChangedEmitter"; }, never, never>;
}
