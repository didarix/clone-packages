import { EventEmitter } from '@angular/core';
import { IColumnsOptions } from '../../../models';
import * as i0 from "@angular/core";
export declare class ImageCellComponent {
    col: IColumnsOptions;
    rowData: any;
    imageStyle: any;
    emitError: EventEmitter<any>;
    constructor();
    emitLoadError(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImageCellComponent, "table-image-cell", never, { "col": "col"; "rowData": "rowData"; "imageStyle": "imageStyle"; }, { "emitError": "emitError"; }, never, never>;
}
