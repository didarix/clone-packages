import { EventEmitter, OnInit } from '@angular/core';
import { ITableActions } from '../../../models';
import * as i0 from "@angular/core";
export declare class ActionsCellComponent implements OnInit {
    actions: ITableActions[];
    rowData: any;
    onItemSelected: EventEmitter<any>;
    constructor();
    ngOnInit(): void;
    validateAction(action: ITableActions, row: any): boolean;
    validateCustomAction(action: ITableActions, row: any): boolean;
    actionClick(action: ITableActions, row: any, callback?: any): any;
    closeAftersSelect(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionsCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActionsCellComponent, "actions-cell", never, { "actions": "actions"; "rowData": "rowData"; }, { "onItemSelected": "onItemSelected"; }, never, never>;
}
