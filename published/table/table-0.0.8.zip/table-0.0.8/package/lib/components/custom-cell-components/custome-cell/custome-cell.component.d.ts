import { IColumnsOptions } from '../../../models';
import * as i0 from "@angular/core";
export declare class CustomeCellComponent {
    col: IColumnsOptions;
    rowData: any;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomeCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomeCellComponent, "table-custome-cell", never, { "col": "col"; "rowData": "rowData"; }, {}, never, never>;
}
