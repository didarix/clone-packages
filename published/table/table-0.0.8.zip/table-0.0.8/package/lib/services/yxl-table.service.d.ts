import { HttpService, LanguageService, ToastService } from '@youxel/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { ITableOptions } from '../models';
import * as i0 from "@angular/core";
export declare class YxlTableService {
    private http;
    private toaster;
    private lang;
    tableData: any[];
    loading: boolean;
    sortOrder: string;
    sort: string;
    colId: string;
    search$: BehaviorSubject<{}>;
    pageOptions: ITableOptions;
    constructor(http: HttpService, toaster: ToastService, lang: LanguageService);
    getAllByGet({ url, pageNumber, sortOrder, sort, colId }: IGetTableData): Observable<any>;
    getAllByPost({ url, initialFilter, pageNumber, filter, orderByValue, }: IGetTableData): Observable<any>;
    changeStatus({ url, id }: {
        url: any;
        id: any;
    }): Observable<any>;
    deleteItem({ url, id }: {
        url: any;
        id: any;
    }): Observable<void>;
    initTableData(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<YxlTableService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<YxlTableService>;
}
export interface IGetTableData {
    url: string;
    sortOrder?: string;
    pageNumber?: number;
    orderByValue?: any[];
    filter?: any;
    initialFilter?: any;
    sort?: any;
    colId?: any;
}
