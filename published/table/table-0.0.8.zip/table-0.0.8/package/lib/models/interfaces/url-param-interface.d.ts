export interface UrlParam {
    pageNumber?: number;
    pageSize?: number;
}
