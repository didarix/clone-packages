export interface FileList {
    name: string;
    id: number;
    type: string;
    linkShare: string;
    dateCreate: string;
    size: string;
}
