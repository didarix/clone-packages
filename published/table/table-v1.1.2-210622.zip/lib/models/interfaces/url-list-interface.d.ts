export interface UrlListItem {
    getAll?: string;
    search?: string;
    changeStatus?: string;
    delete?: string;
    pindFilterData?: any;
}
