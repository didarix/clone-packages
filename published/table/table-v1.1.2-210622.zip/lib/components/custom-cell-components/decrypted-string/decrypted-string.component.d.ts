import { IColumnsOptions } from '../../../models/interfaces';
import * as i0 from "@angular/core";
export declare class DecryptedStringComponent {
    col: IColumnsOptions;
    rowData: any;
    static ɵfac: i0.ɵɵFactoryDeclaration<DecryptedStringComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DecryptedStringComponent, "table-decrypted-string", never, { "col": "col"; "rowData": "rowData"; }, {}, never, never>;
}
