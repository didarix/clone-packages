export { YxlTableService } from './yxl-table.service';
