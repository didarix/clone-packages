import { LanguageService } from '@youxel/core';
import { EventEmitter } from '@angular/core';
import { IColumnsOptions } from '../../../models/interfaces';
import * as i0 from "@angular/core";
export declare class ImageStringCellComponent {
    private languageService;
    col: IColumnsOptions;
    rowData: any;
    imageStyle: any;
    emitError: EventEmitter<any>;
    constructor(languageService: LanguageService);
    emitLoadError(event: any): void;
    lang(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageStringCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImageStringCellComponent, "table-image-string-cell", never, { "col": "col"; "rowData": "rowData"; "imageStyle": "imageStyle"; }, { "emitError": "emitError"; }, never, never>;
}
