import { LanguageService } from '@youxel/core';
import { EventEmitter, OnInit } from '@angular/core';
import { IColumnsOptions } from '../../../models/interfaces';
import * as i0 from "@angular/core";
export declare class TablesRolesComponent implements OnInit {
    languageService: LanguageService;
    col: IColumnsOptions;
    rowData: any;
    onUserDataChanged: EventEmitter<boolean>;
    constructor(languageService: LanguageService);
    ngOnInit(): void;
    sendUserData(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TablesRolesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TablesRolesComponent, "tables-roles-cell", never, { "col": "col"; "rowData": "rowData"; }, { "onUserDataChanged": "onUserDataChanged"; }, never, never>;
}
