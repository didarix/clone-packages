import { EventEmitter, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SortEvent } from 'primeng/api';
import { DialogService } from 'primeng/dynamicdialog';
import { Subscription } from 'rxjs';
import { LanguageService } from '@youxel/core';
import { IColumnsOptions, ITableActions, ITableOptions, UrlListItem, UrlParam } from '../../models/interfaces';
import { ColumnDataTypes } from '../../models/enums';
import { ERequestTypes } from '../../models/interfaces/table-options-interface';
import { IGetTableData, YxlTableService } from '../../services/yxl-table.service';
import { ITranslatedItemsFromEndUser } from '../../models/interfaces';
import * as i0 from "@angular/core";
export declare class YouxelTableComponent implements OnInit, OnDestroy {
    languageService: LanguageService;
    service: YxlTableService;
    private dialogService;
    private router;
    private route;
    data: any;
    urls: UrlListItem;
    columns: IColumnsOptions[];
    options: ITableOptions;
    actions: ITableActions[];
    id: string;
    /**
     * all needed translation text for table package
     *
     *  the actions col header
     *
     * text for the model header
     *
     * text for the model button
     *
     * text for the model button
     *
     */
    tableTranslatedItemsFromEndUser: ITranslatedItemsFromEndUser;
    onSelected: EventEmitter<any[]>;
    onStatusChanged: EventEmitter<any>;
    onItemDeleted: EventEmitter<any>;
    onGetData: EventEmitter<any>;
    onSortData: EventEmitter<any>;
    deleteModal: any;
    bindFilter: string;
    sortType: string;
    columnDataTypes: typeof ColumnDataTypes;
    selectedItems: any[];
    openActionPopup: boolean;
    expandedRows: {};
    sortOrder: string;
    isAscending: boolean;
    selectedData: any[];
    selectedItem: any;
    searchSub: Subscription;
    constructor(languageService: LanguageService, service: YxlTableService, dialogService: DialogService, router: Router, route: ActivatedRoute);
    ngOnInit(): void;
    defaultOptions(): void;
    changeRowStatus(row: any): void;
    getServerSideData(): void;
    onPageChange(pageNumber: number): void;
    getAllData({ pageNumber }: UrlParam): void;
    dataFactory(requestType: ERequestTypes, data: IGetTableData): (() => import("rxjs").Observable<any>) | (() => import("rxjs").Observable<any>);
    selectRow(rowIndex: number): void;
    onSort(event: SortEvent): void;
    paginate(event: any): void;
    applyAction(event: any): void;
    asyncAction(row: any, asyncAction: any): void;
    deleteRow(row: any): void;
    editRow(row: any): void;
    onRowSelect(event: any): void;
    onRowUnselect(event: any): void;
    cellClicked(col: IColumnsOptions, row: any, callback?: any): any;
    onImageError(event: any, col: any): void;
    getSelected(selected: any[]): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<YouxelTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<YouxelTableComponent, "app-youxel-table", never, { "data": "data"; "urls": "urls"; "columns": "columns"; "options": "options"; "actions": "actions"; "id": "id"; "tableTranslatedItemsFromEndUser": "tableTranslatedItemsFromEndUser"; }, { "onSelected": "onSelected"; "onStatusChanged": "onStatusChanged"; "onItemDeleted": "onItemDeleted"; "onGetData": "onGetData"; "onSortData": "onSortData"; }, never, never>;
}
