import { IColumnsOptions } from '../../../models/interfaces';
import * as i0 from "@angular/core";
export declare class StringCellComponent {
    col: IColumnsOptions;
    rowData: any;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<StringCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StringCellComponent, "table-string-cell", never, { "col": "col"; "rowData": "rowData"; }, {}, never, never>;
}
