import { IColumnsOptions } from '../../../models/interfaces';
import * as i0 from "@angular/core";
export declare class RenderStringCellComponent {
    col: IColumnsOptions;
    rowData: any;
    sliced: any;
    rowPlainText: any;
    constructor();
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RenderStringCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RenderStringCellComponent, "table-render-string-cell", never, { "col": "col"; "rowData": "rowData"; }, {}, never, never>;
}
