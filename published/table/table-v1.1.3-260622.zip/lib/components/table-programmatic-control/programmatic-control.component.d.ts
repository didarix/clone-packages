import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ProgrammaticControlComponent implements OnInit {
    first: number;
    rows: number;
    data: any[];
    constructor();
    ngOnInit(): void;
    next(): void;
    prev(): void;
    reset(): void;
    isLastPage(): boolean;
    isFirstPage(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgrammaticControlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProgrammaticControlComponent, "youxel-programmatic-control", never, { "first": "first"; "rows": "rows"; "data": "data"; }, {}, never, never>;
}
