import * as i0 from '@angular/core';
import { Injectable, Component, Input, EventEmitter, Output, Directive, ViewChild, NgModule } from '@angular/core';
import * as i1$4 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i5 from 'primeng/table';
import { TableModule } from 'primeng/table';
import { BehaviorSubject } from 'rxjs';
import { map, take } from 'rxjs/operators';
import * as i1 from '@youxel/core';
import { YouxelCoreModule } from '@youxel/core';
import * as i1$1 from 'primeng/button';
import { ButtonModule } from 'primeng/button';
import * as i1$2 from 'primeng/toolbar';
import { ToolbarModule } from 'primeng/toolbar';
import * as i1$3 from 'primeng/dynamicdialog';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import * as i2 from '@ngx-translate/core';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import * as i3 from 'primeng/api';
import * as i4$1 from '@angular/router';
import * as i1$5 from 'primeng/inputswitch';
import { InputSwitchModule } from 'primeng/inputswitch';
import * as i4 from '@angular/forms';
import * as i1$6 from 'primeng/overlaypanel';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import * as i19 from 'primeng/ripple';
import { RippleModule } from 'primeng/ripple';
import { YouxelFormModule } from '@youxel/form';
import { NgApexchartsModule } from 'ng-apexcharts';
import { MenuModule } from 'primeng/menu';
import { ToastModule } from 'primeng/toast';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ChartModule } from 'primeng/chart';
import { CheckboxModule } from 'primeng/checkbox';
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';
import { MultiSelectModule } from 'primeng/multiselect';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MenubarModule } from 'primeng/menubar';
import { AvatarModule } from 'primeng/avatar';
import { AvatarGroupModule } from 'primeng/avatargroup';
import { EditorModule } from 'primeng/editor';
import { SelectButtonModule } from 'primeng/selectbutton';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { DividerModule } from 'primeng/divider';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { DialogModule } from 'primeng/dialog';
import { AccordionModule } from 'primeng/accordion';
import { TabViewModule } from 'primeng/tabview';
import { InputTextModule } from 'primeng/inputtext';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { RadioButtonModule } from 'primeng/radiobutton';
import { NgSelectModule } from '@ng-select/ng-select';
import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

class YxlTableService {
    constructor(http, toaster, lang) {
        this.http = http;
        this.toaster = toaster;
        this.lang = lang;
        this.tableData = [];
        this.search$ = new BehaviorSubject({});
        this.pageOptions = {
            totalCount: 0,
            pagesCount: 0,
            pageNumber: 0,
            pageSize: 0,
        };
    }
    getAllByGet({ url, pageNumber, sortOrder, sort, colId, }) {
        this.loading = true;
        const pageSize = this.pageOptions.pageSize;
        sortOrder = sortOrder !== null && sortOrder !== void 0 ? sortOrder : this.sortOrder;
        sort = sort !== null && sort !== void 0 ? sort : this.sort;
        colId = colId !== null && colId !== void 0 ? colId : this.colId;
        return this.http
            .get(`${url}?PageNumber=${pageNumber}&PageSize=${pageSize}&colId=${colId}&sort=${sort}`)
            .pipe(map(({ result }) => {
            this.tableData = result.data;
            this.pageOptions.totalCount = result.totalCount;
            this.pageOptions.pagesCount = result.pagesCount;
            this.loading = false;
            return result;
        }), take(1));
        // .subscribe();
    }
    getAllByPost({ url, initialFilter, pageNumber, filter, orderByValue, }) {
        this.loading = true;
        const pageSize = this.pageOptions.pageSize;
        filter = Object.assign(Object.assign(Object.assign({}, filter), initialFilter), this.search$.value);
        if (orderByValue[0].colId == undefined) {
            orderByValue = [];
        }
        const data = {
            pageNumber,
            pageSize,
            filter,
            orderByValue,
        };
        return this.http.post(url, data).pipe(map(({ result }) => {
            this.tableData = result.data;
            this.pageOptions.totalCount = result.totalCount;
            this.pageOptions.pagesCount = result.pagesCount;
            this.loading = false;
            return result;
        }), take(1));
        // .subscribe();
    }
    changeStatus({ url, id }) {
        return this.http.put(`${url}/${id}`).pipe(map((resp) => {
            const message = this.lang.translateTs('TOASTER.SUCCESS_MESSAGE');
            const title = this.lang.translateTs('TOASTER.SUCCESS');
            if (resp.success) {
                this.toaster.show({ message, title });
                return resp.result.data;
            }
        }));
    }
    deleteItem({ url, id }) {
        this.loading = true;
        return this.http.delete(url, id).pipe(take(1), map((resp) => {
            const message = this.lang.translateTs('GENERAL.DELETE_MESSAGE_SUCCESS');
            const title = this.lang.translateTs('TOASTER.SUCCESS');
            if (resp.success)
                this.toaster.show({ message, title });
            this.loading = false;
        }));
    }
    initTableData() {
        this.sortOrder = undefined;
        this.sort = undefined;
        this.colId = undefined;
        this.tableData = [];
        this.search$.next({});
        this.pageOptions = {
            totalCount: 0,
            pageNumber: 1,
            pagesCount: 0,
            pageSize: 10,
            paginator: true,
        };
    }
}
YxlTableService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: YxlTableService, deps: [{ token: i1.HttpService }, { token: i1.ToastService }, { token: i1.LanguageService }], target: i0.ɵɵFactoryTarget.Injectable });
YxlTableService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: YxlTableService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: YxlTableService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: i1.HttpService }, { type: i1.ToastService }, { type: i1.LanguageService }]; } });

class ProgrammaticControlComponent {
    constructor() {
        this.first = 1;
        this.data = [];
    }
    ngOnInit() {
    }
    next() {
        this.first = this.first + this.rows;
    }
    prev() {
        this.first = this.first - this.rows;
    }
    reset() {
        this.first = 0;
    }
    isLastPage() {
        return this.data ? this.first === (this.data.length - this.rows) : true;
    }
    isFirstPage() {
        return this.data ? this.first === 0 : true;
    }
}
ProgrammaticControlComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: ProgrammaticControlComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
ProgrammaticControlComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: ProgrammaticControlComponent, selector: "youxel-programmatic-control", inputs: { first: "first", rows: "rows", data: "data" }, ngImport: i0, template: "<h5>{{'TABLE.TOOLBAR.PROGAMMATIC_CONTROL' }}</h5>\r\n<div class=\"p-mb-3\">\r\n    <p-button type=\"button\" icon=\"pi pi-chevron-left\" (click)=\"prev()\" [disabled]=\"isFirstPage()\"\r\n        styleClass=\"p-button-text\"></p-button>\r\n    <p-button type=\"button\" icon=\"pi pi-refresh\" (click)=\"reset()\" styleClass=\"p-button-text\"></p-button>\r\n    <p-button type=\"button\" icon=\"pi pi-chevron-right\" (click)=\"next()\" [disabled]=\"isLastPage()\"\r\n        styleClass=\"p-button-text\"></p-button>\r\n</div>\r\n", styles: [""], components: [{ type: i1$1.Button, selector: "p-button", inputs: ["type", "iconPos", "icon", "badge", "label", "disabled", "loading", "loadingIcon", "style", "styleClass", "badgeClass"], outputs: ["onClick", "onFocus", "onBlur"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: ProgrammaticControlComponent, decorators: [{
            type: Component,
            args: [{ selector: 'youxel-programmatic-control', template: "<h5>{{'TABLE.TOOLBAR.PROGAMMATIC_CONTROL' }}</h5>\r\n<div class=\"p-mb-3\">\r\n    <p-button type=\"button\" icon=\"pi pi-chevron-left\" (click)=\"prev()\" [disabled]=\"isFirstPage()\"\r\n        styleClass=\"p-button-text\"></p-button>\r\n    <p-button type=\"button\" icon=\"pi pi-refresh\" (click)=\"reset()\" styleClass=\"p-button-text\"></p-button>\r\n    <p-button type=\"button\" icon=\"pi pi-chevron-right\" (click)=\"next()\" [disabled]=\"isLastPage()\"\r\n        styleClass=\"p-button-text\"></p-button>\r\n</div>\r\n", styles: [""] }]
        }], ctorParameters: function () { return []; }, propDecorators: { first: [{
                type: Input
            }], rows: [{
                type: Input
            }], data: [{
                type: Input
            }] } });

class TableToolbarComponent {
    constructor() { }
    ngOnInit() { }
}
TableToolbarComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: TableToolbarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
TableToolbarComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: TableToolbarComponent, selector: "youxel-table-toolbar", inputs: { options: "options" }, ngImport: i0, template: "<div class=\"table-toolbar\">\r\n  <p-toolbar>\r\n    <ng-content></ng-content>\r\n  </p-toolbar>\r\n</div>\r\n", styles: [".table-toolbar ::ng-deep .p-toolbar,.table-toolbar .p-toolbar-group-left,.table-toolbar .p-toolbar-group-right{border:none!important}.table-toolbar p-toolbar{justify-content:space-between;width:100%}\n"], components: [{ type: i1$2.Toolbar, selector: "p-toolbar", inputs: ["style", "styleClass"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: TableToolbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'youxel-table-toolbar', template: "<div class=\"table-toolbar\">\r\n  <p-toolbar>\r\n    <ng-content></ng-content>\r\n  </p-toolbar>\r\n</div>\r\n", styles: [".table-toolbar ::ng-deep .p-toolbar,.table-toolbar .p-toolbar-group-left,.table-toolbar .p-toolbar-group-right{border:none!important}.table-toolbar p-toolbar{justify-content:space-between;width:100%}\n"] }]
        }], ctorParameters: function () { return []; }, propDecorators: { options: [{
                type: Input
            }] } });

var ColumnDataTypes;
(function (ColumnDataTypes) {
    ColumnDataTypes["String"] = "string";
    ColumnDataTypes["Date"] = "date";
    ColumnDataTypes["Boolean"] = "boolean";
    ColumnDataTypes["Image"] = "image";
    ColumnDataTypes["ImageWithString"] = "imageWithString";
    ColumnDataTypes["Custom"] = "customContent";
    ColumnDataTypes["customeCell"] = "customeCell";
    ColumnDataTypes["Number"] = "number";
    ColumnDataTypes["DateTime"] = "dateTime";
    ColumnDataTypes["RenderString"] = "renderSting";
    ColumnDataTypes["Roles"] = "roles";
    ColumnDataTypes["DecryptedString"] = "decryptedString";
})(ColumnDataTypes || (ColumnDataTypes = {}));

var TableSortSelectionModes;
(function (TableSortSelectionModes) {
    TableSortSelectionModes["Single"] = "single";
    TableSortSelectionModes["Multiple"] = "multiple";
})(TableSortSelectionModes || (TableSortSelectionModes = {}));

var ERequestTypes;
(function (ERequestTypes) {
    ERequestTypes["post"] = "POST";
    ERequestTypes["get"] = "GET";
})(ERequestTypes || (ERequestTypes = {}));

class ModalComponent {
    constructor(ref, config, translateService) {
        this.ref = ref;
        this.config = config;
        this.translateService = translateService;
        this.buttonsText = {
            delete: this.translateService.instant('MODEL.delete') || 'Delete',
            cancel: this.translateService.instant('MODEL.Cancel') || 'Cancel',
        };
        this.passEntry = new EventEmitter();
        this.closeModal = new EventEmitter();
    }
    ngOnInit() {
        var _a, _b, _c, _d;
        this.template = this.config.data.template;
        this.rowData = this.config.data.rowData;
        this.buttonsText.cancel = (_b = (_a = this.config.data) === null || _a === void 0 ? void 0 : _a.buttons) === null || _b === void 0 ? void 0 : _b.cancel;
        this.buttonsText.delete = (_d = (_c = this.config.data) === null || _c === void 0 ? void 0 : _c.buttons) === null || _d === void 0 ? void 0 : _d.delete;
    }
    confirm(data) {
        this.ref.close(data);
    }
    close() {
        this.ref.close();
    }
}
ModalComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: ModalComponent, deps: [{ token: i1$3.DynamicDialogRef }, { token: i1$3.DynamicDialogConfig }, { token: i2.TranslateService }], target: i0.ɵɵFactoryTarget.Component });
ModalComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: ModalComponent, selector: "Delete-confirm-dailog", inputs: { buttonsText: "buttonsText" }, outputs: { passEntry: "passEntry", closeModal: "closeModal" }, ngImport: i0, template: "<ng-template pTemplate=\"header\">\r\n  <div class=\"modal-header\">\r\n    <div class=\"header-wrapper d-flex align-items-center justify-content-between w-100\">\r\n      <h4 class=\"modal-title\">{{ 'title' }}</h4>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n<div class=\"modal-body\">\r\n  <ng-content *ngTemplateOutlet=\"template\"></ng-content>\r\n</div>\r\n<p-footer>\r\n  <div class=\"modal-footer\">\r\n    <div class=\"confirmation-wrapper d-flex flex-row-reverse\">\r\n      <button type=\"button\" (click)=\"close()\" class=\"youxel-btn outline\">{{ buttonsText?.cancel || 'Cancel' }}</button>\r\n      <button type=\"button\" (click)=\"confirm(rowData)\" class=\"youxel-btn solid primary-gredient\">{{ buttonsText?.delete\r\n        || 'Delete'}} </button>\r\n    </div>\r\n  </div>\r\n</p-footer>\r\n", styles: [":root{--black: #000000;--primary-darker: #003e71;--gray-700: #4e4d55;--gray-500: #868894;--gray-300: #dcdde5;--red-50: #e5e5e5;--white: #fff;--white-50: #f1f3f4;--white-200: #f5f5f5;--white-500: #dadcdd;--gray-100: #e4ebf3;--primary: #1650ed;--danger: #e03303;--rejected-color: #f16b6b;--pending: #f2ae75;--yellow-600: #d99a28;--warning-light-color: #eecf7e;--yellow-900: #937644;--green: green;--green-700: #85cb9c;--shadow-green: rgba(73, 164, 135, .1);--shadow-light-blue: rgba(228, 233, 241, .2);--shadow-blue: rgba(114, 159, 197, .1);--shadow-black: #0000002b;--green-300: #49a487;--primary-light: #1650ed;--primary-light-gradient: linear-gradient(to bottom, #1650ed 40%, #1650ed 93%);--primary-light-right-gradient: linear-gradient(to right, #1650ed, #1650ed);--primary-gradient: linear-gradient(45deg, #1650ed, #1650ed);--secondary-gradient: linear-gradient(45deg, #937644, #f2ae75);--gradient-white: linear-gradient(to top, #fff, #fff);--box-shadow: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-green: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-10: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-primary-light: 0 -25px 0 0 #1650ed;--box-shadow-black: 3px 7px 25px 0 #0000002b;--box-shadow-light: 0 0 16px 0 rgba(107, 132, 153, .12);--box-shadow-light-blue: 6px 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-blue: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-blue-alpha: 0 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-white: 0 0 3px #ccc;--box-shadow-6: 0 4px 10px 0 rgba(0, 0, 0, .06)}::ng-deep .modal-body{margin-bottom:20px}::ng-deep .modal-footer{border-top:none}::ng-deep .modal-footer .confirmation-wrapper{justify-content:flex-end!important}::ng-deep .modal-footer .youxel-btn{border:none;text-align:center;border-radius:5px;color:#fff;font-family:STC Regular;background-color:transparent;text-transform:capitalize;line-height:16px;font-size:14px;padding:10px 19px}::ng-deep .modal-footer .youxel-btn.outline{color:#1650ed}::ng-deep .modal-footer .youxel-btn.primary-gredient{background-image:linear-gradient(45deg,#1650ed,#1650ed)}::ng-deep .modal-footer .youxel-btn.solid{background-color:#1650ed}::ng-deep .modal-header{border-bottom:none;padding:.5rem}::ng-deep .modal-header .header-wrapper .modal-title{margin:0;color:#4e4d55;font-size:24px;font-weight:700}::ng-deep .cursor-pointer{cursor:pointer}::ng-deep .youxel-close:before{content:\"\\e90b\"}\n"], components: [{ type: i3.Footer, selector: "p-footer" }], directives: [{ type: i3.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { type: i1$4.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: ModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'Delete-confirm-dailog', template: "<ng-template pTemplate=\"header\">\r\n  <div class=\"modal-header\">\r\n    <div class=\"header-wrapper d-flex align-items-center justify-content-between w-100\">\r\n      <h4 class=\"modal-title\">{{ 'title' }}</h4>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n<div class=\"modal-body\">\r\n  <ng-content *ngTemplateOutlet=\"template\"></ng-content>\r\n</div>\r\n<p-footer>\r\n  <div class=\"modal-footer\">\r\n    <div class=\"confirmation-wrapper d-flex flex-row-reverse\">\r\n      <button type=\"button\" (click)=\"close()\" class=\"youxel-btn outline\">{{ buttonsText?.cancel || 'Cancel' }}</button>\r\n      <button type=\"button\" (click)=\"confirm(rowData)\" class=\"youxel-btn solid primary-gredient\">{{ buttonsText?.delete\r\n        || 'Delete'}} </button>\r\n    </div>\r\n  </div>\r\n</p-footer>\r\n", styles: [":root{--black: #000000;--primary-darker: #003e71;--gray-700: #4e4d55;--gray-500: #868894;--gray-300: #dcdde5;--red-50: #e5e5e5;--white: #fff;--white-50: #f1f3f4;--white-200: #f5f5f5;--white-500: #dadcdd;--gray-100: #e4ebf3;--primary: #1650ed;--danger: #e03303;--rejected-color: #f16b6b;--pending: #f2ae75;--yellow-600: #d99a28;--warning-light-color: #eecf7e;--yellow-900: #937644;--green: green;--green-700: #85cb9c;--shadow-green: rgba(73, 164, 135, .1);--shadow-light-blue: rgba(228, 233, 241, .2);--shadow-blue: rgba(114, 159, 197, .1);--shadow-black: #0000002b;--green-300: #49a487;--primary-light: #1650ed;--primary-light-gradient: linear-gradient(to bottom, #1650ed 40%, #1650ed 93%);--primary-light-right-gradient: linear-gradient(to right, #1650ed, #1650ed);--primary-gradient: linear-gradient(45deg, #1650ed, #1650ed);--secondary-gradient: linear-gradient(45deg, #937644, #f2ae75);--gradient-white: linear-gradient(to top, #fff, #fff);--box-shadow: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-green: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-10: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-primary-light: 0 -25px 0 0 #1650ed;--box-shadow-black: 3px 7px 25px 0 #0000002b;--box-shadow-light: 0 0 16px 0 rgba(107, 132, 153, .12);--box-shadow-light-blue: 6px 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-blue: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-blue-alpha: 0 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-white: 0 0 3px #ccc;--box-shadow-6: 0 4px 10px 0 rgba(0, 0, 0, .06)}::ng-deep .modal-body{margin-bottom:20px}::ng-deep .modal-footer{border-top:none}::ng-deep .modal-footer .confirmation-wrapper{justify-content:flex-end!important}::ng-deep .modal-footer .youxel-btn{border:none;text-align:center;border-radius:5px;color:#fff;font-family:STC Regular;background-color:transparent;text-transform:capitalize;line-height:16px;font-size:14px;padding:10px 19px}::ng-deep .modal-footer .youxel-btn.outline{color:#1650ed}::ng-deep .modal-footer .youxel-btn.primary-gredient{background-image:linear-gradient(45deg,#1650ed,#1650ed)}::ng-deep .modal-footer .youxel-btn.solid{background-color:#1650ed}::ng-deep .modal-header{border-bottom:none;padding:.5rem}::ng-deep .modal-header .header-wrapper .modal-title{margin:0;color:#4e4d55;font-size:24px;font-weight:700}::ng-deep .cursor-pointer{cursor:pointer}::ng-deep .youxel-close:before{content:\"\\e90b\"}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$3.DynamicDialogRef }, { type: i1$3.DynamicDialogConfig }, { type: i2.TranslateService }]; }, propDecorators: { buttonsText: [{
                type: Input
            }], passEntry: [{
                type: Output
            }], closeModal: [{
                type: Output
            }] } });

class StringCellComponent {
    constructor() {
        this.col = {
            header: '',
            field: '',
        };
        this.rowData = {};
    }
}
StringCellComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: StringCellComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
StringCellComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: StringCellComponent, selector: "table-string-cell", inputs: { col: "col", rowData: "rowData" }, ngImport: i0, template: `
    <span
      *ngIf="col.isNested; else ifNotNested"
      [ngStyle]="
        col.customStyles?.customCellDesign
          ? col.customStyles?.customCellDesign
          : ''
      "
    >
      {{
        rowData[col.field]
          ? (rowData[col.field][col.nestedKey] + (col.appendAfter || '')
            | strLimit)
          : col.emptyCell
      }}
    </span>

    <ng-template
      #ifNotNested
      [ngStyle]="
        col.customStyles?.customCellDesign
          ? col.customStyles?.customCellDesign
          : ''
      "
    >
      {{
        rowData[col.field]
          ? (rowData[col.field] + (col.appendAfter || '') | strLimit)
          : col.emptyCell
      }}
    </ng-template>
  `, isInline: true, directives: [{ type: i1$4.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i1$4.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }], pipes: { "strLimit": i1.StringLimitPipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: StringCellComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'table-string-cell',
                    template: `
    <span
      *ngIf="col.isNested; else ifNotNested"
      [ngStyle]="
        col.customStyles?.customCellDesign
          ? col.customStyles?.customCellDesign
          : ''
      "
    >
      {{
        rowData[col.field]
          ? (rowData[col.field][col.nestedKey] + (col.appendAfter || '')
            | strLimit)
          : col.emptyCell
      }}
    </span>

    <ng-template
      #ifNotNested
      [ngStyle]="
        col.customStyles?.customCellDesign
          ? col.customStyles?.customCellDesign
          : ''
      "
    >
      {{
        rowData[col.field]
          ? (rowData[col.field] + (col.appendAfter || '') | strLimit)
          : col.emptyCell
      }}
    </ng-template>
  `,
                }]
        }], ctorParameters: function () { return []; }, propDecorators: { col: [{
                type: Input
            }], rowData: [{
                type: Input
            }] } });

class RenderStringCellComponent {
    constructor() {
        this.col = {
            header: '',
            field: '',
        };
        this.rowData = {};
    }
    ngOnChanges() {
        this.rowPlainText = this.col.isNested
            ? this.rowData[this.col.field][this.col.nestedKey].replace(/<[^>]*>/g, '')
            : this.rowData[this.col.field].replace(/<[^>]*>/g, '');
    }
}
RenderStringCellComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: RenderStringCellComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
RenderStringCellComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: RenderStringCellComponent, selector: "table-render-string-cell", inputs: { col: "col", rowData: "rowData" }, usesOnChanges: true, ngImport: i0, template: `
    <span>
      {{ rowPlainText ? (rowPlainText | strLimit) : col.emptyCell }}
    </span>
  `, isInline: true, pipes: { "strLimit": i1.StringLimitPipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: RenderStringCellComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'table-render-string-cell',
                    template: `
    <span>
      {{ rowPlainText ? (rowPlainText | strLimit) : col.emptyCell }}
    </span>
  `,
                }]
        }], ctorParameters: function () { return []; }, propDecorators: { col: [{
                type: Input
            }], rowData: [{
                type: Input
            }] } });

class CustomeCellComponent {
    constructor() {
        this.col = {
            header: '',
            field: '',
        };
        this.rowData = {};
    }
}
CustomeCellComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: CustomeCellComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
CustomeCellComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: CustomeCellComponent, selector: "table-custome-cell", inputs: { col: "col", rowData: "rowData" }, ngImport: i0, template: `
    <ng-container
      [ngTemplateOutlet]="
        col.customTemplate ? col.customTemplate(rowData) : default
      "
      [ngTemplateOutletContext]="{ $implicit: rowData }"
    ></ng-container>

    <ng-template let-rowData #default>
      {{ rowData[col.field] }}
    </ng-template>
  `, isInline: true, directives: [{ type: i1$4.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: CustomeCellComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'table-custome-cell',
                    template: `
    <ng-container
      [ngTemplateOutlet]="
        col.customTemplate ? col.customTemplate(rowData) : default
      "
      [ngTemplateOutletContext]="{ $implicit: rowData }"
    ></ng-container>

    <ng-template let-rowData #default>
      {{ rowData[col.field] }}
    </ng-template>
  `,
                }]
        }], ctorParameters: function () { return []; }, propDecorators: { col: [{
                type: Input
            }], rowData: [{
                type: Input
            }] } });

class DateCellComponent {
    constructor() {
        this.col = {
            header: '',
            field: '',
        };
        this.rowData = {};
    }
}
DateCellComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: DateCellComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
DateCellComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: DateCellComponent, selector: "table-date-cell", inputs: { col: "col", rowData: "rowData" }, ngImport: i0, template: ` <span
      *ngIf="col.isNested; else ifNotNested"
      [ngStyle]="
        col.customStyles?.customCellDesign
          ? col.customStyles?.customCellDesign
          : ''
      "
    >
      {{
        rowData[col.field]
          ? (rowData[col.field][col.nestedKey]
            | date: col.dateFormate ?? 'MM-d-yyyy')
          : col.emptyCell
      }}
    </span>

    <ng-template #ifNotNested>
      <div
        [ngStyle]="
          col.customStyles?.customCellDesign
            ? col.customStyles?.customCellDesign
            : ''
        "
      >
        {{
          rowData[col.field]
            ? (rowData[col.field] | date: col.dateFormate ?? 'MM-d-yyyy')
            : col.emptyCell
        }}
      </div>
    </ng-template>`, isInline: true, directives: [{ type: i1$4.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i1$4.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }], pipes: { "date": i1$4.DatePipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: DateCellComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'table-date-cell',
                    template: ` <span
      *ngIf="col.isNested; else ifNotNested"
      [ngStyle]="
        col.customStyles?.customCellDesign
          ? col.customStyles?.customCellDesign
          : ''
      "
    >
      {{
        rowData[col.field]
          ? (rowData[col.field][col.nestedKey]
            | date: col.dateFormate ?? 'MM-d-yyyy')
          : col.emptyCell
      }}
    </span>

    <ng-template #ifNotNested>
      <div
        [ngStyle]="
          col.customStyles?.customCellDesign
            ? col.customStyles?.customCellDesign
            : ''
        "
      >
        {{
          rowData[col.field]
            ? (rowData[col.field] | date: col.dateFormate ?? 'MM-d-yyyy')
            : col.emptyCell
        }}
      </div>
    </ng-template>`,
                }]
        }], ctorParameters: function () { return []; }, propDecorators: { col: [{
                type: Input
            }], rowData: [{
                type: Input
            }] } });

class TableDateTimeCellComponent {
    constructor() {
        this.col = {
            header: '',
            field: '',
        };
        this.rowData = {};
    }
}
TableDateTimeCellComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: TableDateTimeCellComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
TableDateTimeCellComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: TableDateTimeCellComponent, selector: "table-date-time-cell", inputs: { col: "col", rowData: "rowData" }, ngImport: i0, template: ` <span
      *ngIf="col.isNested; else ifNotNested"
      [ngStyle]="
        col.customStyles?.customCellDesign
          ? col.customStyles?.customCellDesign
          : ''
      "
    >
      {{
        rowData[col.field]
          ? (rowData[col.field][col.nestedKey]
            | date: col.dateFormate ?? 'MMM d, y')
          : col.emptyCell
      }}

      <p class="mt-2">
        {{
          rowData[col.field]
            ? (rowData[col.field] | date: col.dateFormate ?? 'h:mm a')
            : col.emptyCell
        }}
      </p>
    </span>

    <ng-template #ifNotNested>
      <div
        [ngStyle]="
          col.customStyles?.customCellDesign
            ? col.customStyles?.customCellDesign
            : ''
        "
      >
        {{
          rowData[col.field]
            ? (rowData[col.field] | date: col.dateFormate ?? 'MMM d, y')
            : col.emptyCell
        }}

        <p class="mt-2">
          {{
            rowData[col.field]
              ? (rowData[col.field] | date: col.dateFormate ?? 'h:mm a')
              : col.emptyCell
          }}
        </p>
      </div>
    </ng-template>`, isInline: true, directives: [{ type: i1$4.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i1$4.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }], pipes: { "date": i1$4.DatePipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: TableDateTimeCellComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'table-date-time-cell',
                    template: ` <span
      *ngIf="col.isNested; else ifNotNested"
      [ngStyle]="
        col.customStyles?.customCellDesign
          ? col.customStyles?.customCellDesign
          : ''
      "
    >
      {{
        rowData[col.field]
          ? (rowData[col.field][col.nestedKey]
            | date: col.dateFormate ?? 'MMM d, y')
          : col.emptyCell
      }}

      <p class="mt-2">
        {{
          rowData[col.field]
            ? (rowData[col.field] | date: col.dateFormate ?? 'h:mm a')
            : col.emptyCell
        }}
      </p>
    </span>

    <ng-template #ifNotNested>
      <div
        [ngStyle]="
          col.customStyles?.customCellDesign
            ? col.customStyles?.customCellDesign
            : ''
        "
      >
        {{
          rowData[col.field]
            ? (rowData[col.field] | date: col.dateFormate ?? 'MMM d, y')
            : col.emptyCell
        }}

        <p class="mt-2">
          {{
            rowData[col.field]
              ? (rowData[col.field] | date: col.dateFormate ?? 'h:mm a')
              : col.emptyCell
          }}
        </p>
      </div>
    </ng-template>`,
                }]
        }], ctorParameters: function () { return []; }, propDecorators: { col: [{
                type: Input
            }], rowData: [{
                type: Input
            }] } });

class InputSwitchCellComponent {
    constructor() {
        this.col = {
            header: '',
            field: '',
        };
        this.rowData = {};
        this.statusChangedEmitter = new EventEmitter();
    }
    emitStatusChange(row) {
        this.statusChangedEmitter.emit(row);
    }
}
InputSwitchCellComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: InputSwitchCellComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
InputSwitchCellComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: InputSwitchCellComponent, selector: "table-input-switch-cell", inputs: { col: "col", rowData: "rowData" }, outputs: { statusChangedEmitter: "statusChangedEmitter" }, ngImport: i0, template: `
    <p-inputSwitch
      (onChange)="emitStatusChange(rowData)"
      [(ngModel)]="rowData[col.field]"
    ></p-inputSwitch>
  `, isInline: true, components: [{ type: i1$5.InputSwitch, selector: "p-inputSwitch", inputs: ["style", "styleClass", "tabindex", "inputId", "name", "disabled", "readonly", "trueValue", "falseValue", "ariaLabelledBy"], outputs: ["onChange"] }], directives: [{ type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { type: i4.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: InputSwitchCellComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'table-input-switch-cell',
                    template: `
    <p-inputSwitch
      (onChange)="emitStatusChange(rowData)"
      [(ngModel)]="rowData[col.field]"
    ></p-inputSwitch>
  `,
                }]
        }], ctorParameters: function () { return []; }, propDecorators: { col: [{
                type: Input
            }], rowData: [{
                type: Input
            }], statusChangedEmitter: [{
                type: Output
            }] } });

class ImageCellComponent {
    constructor() {
        this.col = {
            header: '',
            field: '',
        };
        this.rowData = {};
        this.emitError = new EventEmitter();
    }
    emitLoadError(event) {
        this.emitError.emit(event);
    }
}
ImageCellComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: ImageCellComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
ImageCellComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: ImageCellComponent, selector: "table-image-cell", inputs: { col: "col", rowData: "rowData", imageStyle: "imageStyle" }, outputs: { emitError: "emitError" }, ngImport: i0, template: ` <img
      *ngIf="col.isNested; else ifNotNested"
      [ngStyle]="imageStyle"
      [src]="rowData[col.field][col.nestedKey]"
      (error)="emitLoadError($event)"
      alt=""
    />

    <ng-template #ifNotNested>
      <img
        [ngStyle]="imageStyle"
        [src]="rowData[col.field]"
        (error)="emitLoadError($event)"
        alt=""
      />
    </ng-template>`, isInline: true, styles: ["img{width:80px;height:80px}\n"], directives: [{ type: i1$4.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i1$4.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: ImageCellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'table-image-cell', template: ` <img
      *ngIf="col.isNested; else ifNotNested"
      [ngStyle]="imageStyle"
      [src]="rowData[col.field][col.nestedKey]"
      (error)="emitLoadError($event)"
      alt=""
    />

    <ng-template #ifNotNested>
      <img
        [ngStyle]="imageStyle"
        [src]="rowData[col.field]"
        (error)="emitLoadError($event)"
        alt=""
      />
    </ng-template>`, styles: ["img{width:80px;height:80px}\n"] }]
        }], ctorParameters: function () { return []; }, propDecorators: { col: [{
                type: Input
            }], rowData: [{
                type: Input
            }], imageStyle: [{
                type: Input
            }], emitError: [{
                type: Output
            }] } });

class ImageStringCellComponent {
    constructor(languageService) {
        this.languageService = languageService;
        this.col = {
            header: '',
            field: '',
        };
        this.rowData = {};
        this.emitError = new EventEmitter();
    }
    emitLoadError(event) {
        this.emitError.emit(event);
    }
    lang() {
        return this.languageService.currentLanguage();
    }
}
ImageStringCellComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: ImageStringCellComponent, deps: [{ token: i1.LanguageService }], target: i0.ɵɵFactoryTarget.Component });
ImageStringCellComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: ImageStringCellComponent, selector: "table-image-string-cell", inputs: { col: "col", rowData: "rowData", imageStyle: "imageStyle" }, outputs: { emitError: "emitError" }, ngImport: i0, template: `
    <div
      class="image-title"
      *ngIf="col.isNestedImage && col.isNested; else ifNotNested"
    >
      <img
        class="image-data"
        *ngIf="rowData[col.field]"
        [ngStyle]="imageStyle"
        [src]="rowData[col.field][col.imageUrl]"
        (error)="emitLoadError($event)"
        alt=""
      />

      <span
        class="mx-2"
        [ngStyle]="
          col.customStyles?.customCellDesign
            ? col.customStyles?.customCellDesign
            : ''
        "
      >
        {{
          rowData[col.field] ? rowData[col.field][col.nestedKey] : col.emptyCell
        }}
      </span>
    </div>
    <ng-template #ifNotNested>
      <div class="image-title">
        <img
          class="image-data"
          *ngIf="rowData[col.imageUrl]"
          [ngStyle]="imageStyle"
          [src]="rowData[col.imageUrl]"
          (error)="emitLoadError($event)"
          alt=""
        />

        <span
          [ngStyle]="
            col.customStyles?.customCellDesign
              ? col.customStyles?.customCellDesign
              : ''
          "
          [ngClass]="lang() === 'ar' ? 'mr-2' : 'ml-2'"
        >
          {{ rowData[col.field] ? rowData[col.field] : col.emptyCell }}
        </span>
      </div>
    </ng-template>
  `, isInline: true, styles: [".image-title{display:flex;flex-direction:row;align-items:center}.image-title img{width:35px;height:35px}\n"], directives: [{ type: i1$4.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i1$4.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { type: i1$4.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: ImageStringCellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'table-image-string-cell', template: `
    <div
      class="image-title"
      *ngIf="col.isNestedImage && col.isNested; else ifNotNested"
    >
      <img
        class="image-data"
        *ngIf="rowData[col.field]"
        [ngStyle]="imageStyle"
        [src]="rowData[col.field][col.imageUrl]"
        (error)="emitLoadError($event)"
        alt=""
      />

      <span
        class="mx-2"
        [ngStyle]="
          col.customStyles?.customCellDesign
            ? col.customStyles?.customCellDesign
            : ''
        "
      >
        {{
          rowData[col.field] ? rowData[col.field][col.nestedKey] : col.emptyCell
        }}
      </span>
    </div>
    <ng-template #ifNotNested>
      <div class="image-title">
        <img
          class="image-data"
          *ngIf="rowData[col.imageUrl]"
          [ngStyle]="imageStyle"
          [src]="rowData[col.imageUrl]"
          (error)="emitLoadError($event)"
          alt=""
        />

        <span
          [ngStyle]="
            col.customStyles?.customCellDesign
              ? col.customStyles?.customCellDesign
              : ''
          "
          [ngClass]="lang() === 'ar' ? 'mr-2' : 'ml-2'"
        >
          {{ rowData[col.field] ? rowData[col.field] : col.emptyCell }}
        </span>
      </div>
    </ng-template>
  `, styles: [".image-title{display:flex;flex-direction:row;align-items:center}.image-title img{width:35px;height:35px}\n"] }]
        }], ctorParameters: function () { return [{ type: i1.LanguageService }]; }, propDecorators: { col: [{
                type: Input
            }], rowData: [{
                type: Input
            }], imageStyle: [{
                type: Input
            }], emitError: [{
                type: Output
            }] } });

class DecryptedStringComponent {
    constructor() {
        this.col = {
            header: '',
            field: '',
        };
        this.rowData = {};
    }
}
DecryptedStringComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: DecryptedStringComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
DecryptedStringComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: DecryptedStringComponent, selector: "table-decrypted-string", inputs: { col: "col", rowData: "rowData" }, ngImport: i0, template: `
    <span>
      {{
        rowData[col.field]
          ? (rowData[col.field] | decryptString | strLimit)
          : col.emptyCell
      }}
    </span>
  `, isInline: true, pipes: { "strLimit": i1.StringLimitPipe, "decryptString": i1.DecryptStringPipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: DecryptedStringComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'table-decrypted-string',
                    template: `
    <span>
      {{
        rowData[col.field]
          ? (rowData[col.field] | decryptString | strLimit)
          : col.emptyCell
      }}
    </span>
  `,
                }]
        }], propDecorators: { col: [{
                type: Input
            }], rowData: [{
                type: Input
            }] } });

class ValidateActionDirective {
    constructor(templateRef, viewContainer) {
        this.templateRef = templateRef;
        this.viewContainer = viewContainer;
    }
    set validateActions({ rowData: rowData, actions: actions }) {
        const toggleShow = actions.reduce((acc, crr) => acc || !crr.customPermission || crr.customPermission(rowData), false);
        if (toggleShow) {
            let view = this.viewContainer.createEmbeddedView(this.templateRef);
            this.viewContainer.insert(view);
        }
        else
            this.viewContainer.clear();
    }
}
ValidateActionDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: ValidateActionDirective, deps: [{ token: i0.TemplateRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive });
ValidateActionDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.1.1", type: ValidateActionDirective, selector: "[validateActions]", inputs: { validateActions: "validateActions" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: ValidateActionDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[validateActions]',
                }]
        }], ctorParameters: function () { return [{ type: i0.TemplateRef }, { type: i0.ViewContainerRef }]; }, propDecorators: { validateActions: [{
                type: Input
            }] } });

class ActionsCellComponent {
    constructor() {
        this.actions = [];
        this.onItemSelected = new EventEmitter();
    }
    ngOnInit() { }
    validateAction(action, row) {
        return !action.customPermission || action.customPermission(row);
    }
    validateCustomAction(action, row) {
        return (!(action.isEdit || action.isDelete) && this.validateAction(action, row));
    }
    actionClick(action, row, callback) {
        this.onItemSelected.emit({ action, row });
        if (action.call)
            return action.call(row);
        if (action.callAsync)
            return action.callAsync(row);
        return callback;
    }
    closeAftersSelect(event) {
        event.overlayVisible = false;
    }
}
ActionsCellComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: ActionsCellComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
ActionsCellComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: ActionsCellComponent, selector: "actions-cell", inputs: { actions: "actions", rowData: "rowData" }, outputs: { onItemSelected: "onItemSelected" }, ngImport: i0, template: "<div #mydiv>\r\n  <div class=\"actions-img-container\" (click)=\"op.toggle($event)\" *validateActions=\"{rowData, actions}\">\r\n    <img src=\"assets/svg-icon/more-icon.svg\" alt=\"more\" />\r\n  </div>\r\n  <p-overlayPanel #op dismissable=\"true\" [appendTo]=\"mydiv\" styleClass=\"panelStyles\">\r\n    <ng-template pTemplate>\r\n      <ng-container *ngFor=\"let action of actions\">\r\n        <p *ngIf=\"action.isDelete && validateAction(action, rowData)\" class=\"action-label red-text\"\r\n          (click)=\"closeAftersSelect(op); actionClick(action, rowData)\">\r\n          {{\r\n          action.name\r\n          ? (action.name )\r\n          : ('TABLE.TOOLBAR.DELETE' )\r\n          }}\r\n        </p>\r\n        <p *ngIf=\"action.isEdit && validateAction(action, rowData)\" class=\"action-label\"\r\n          (click)=\"actionClick(action, rowData)\">\r\n          {{\r\n          action.name\r\n          ? (action.name )\r\n          : ('TABLE.TOOLBAR.VIEW_EDIT' )\r\n          }}\r\n        </p>\r\n        <p *ngIf=\"validateCustomAction(action, rowData)\" class=\"action-label\" (click)=\"actionClick(action, rowData)\">\r\n          <i [class]=\"action.icon\"></i>\r\n          {{ action.name }}\r\n        </p>\r\n      </ng-container>\r\n    </ng-template>\r\n  </p-overlayPanel>\r\n</div>\r\n", styles: [":root{--black: #000000;--primary-darker: #003e71;--gray-700: #4e4d55;--gray-500: #868894;--gray-300: #dcdde5;--red-50: #e5e5e5;--white: #fff;--white-50: #f1f3f4;--white-200: #f5f5f5;--white-500: #dadcdd;--gray-100: #e4ebf3;--primary: #1650ed;--danger: #e03303;--rejected-color: #f16b6b;--pending: #f2ae75;--yellow-600: #d99a28;--warning-light-color: #eecf7e;--yellow-900: #937644;--green: green;--green-700: #85cb9c;--shadow-green: rgba(73, 164, 135, .1);--shadow-light-blue: rgba(228, 233, 241, .2);--shadow-blue: rgba(114, 159, 197, .1);--shadow-black: #0000002b;--green-300: #49a487;--primary-light: #1650ed;--primary-light-gradient: linear-gradient(to bottom, #1650ed 40%, #1650ed 93%);--primary-light-right-gradient: linear-gradient(to right, #1650ed, #1650ed);--primary-gradient: linear-gradient(45deg, #1650ed, #1650ed);--secondary-gradient: linear-gradient(45deg, #937644, #f2ae75);--gradient-white: linear-gradient(to top, #fff, #fff);--box-shadow: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-green: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-10: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-primary-light: 0 -25px 0 0 #1650ed;--box-shadow-black: 3px 7px 25px 0 #0000002b;--box-shadow-light: 0 0 16px 0 rgba(107, 132, 153, .12);--box-shadow-light-blue: 6px 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-blue: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-blue-alpha: 0 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-white: 0 0 3px #ccc;--box-shadow-6: 0 4px 10px 0 rgba(0, 0, 0, .06)}::ng-deep .action-label{font-size:13px!important;color:#4e4d55;font-stretch:normal;font-style:normal;line-height:20px;letter-spacing:normal;text-align:left;margin:0!important;padding:5px 5px 5px 10px}::ng-deep .action-label:hover{background-color:#dadcdd}::ng-deep .red-text{color:#f16b6b;font-weight:700}::ng-deep .p-overlaypanel:after{border-width:8px;margin-left:-4px}::ng-deep .p-overlaypanel:before{display:none!important}::ng-deep .p-overlaypanel{display:inline-block!important;position:absolute!important;z-index:1016!important;margin-top:-5px!important;left:auto!important;top:auto!important;width:130px!important;border-radius:10px!important;box-shadow:6px 6px 15px #0080ff1f!important;border:.5px solid #e9ebf1!important;background-color:#fff}.actions-img-container img{cursor:pointer}\n"], components: [{ type: i1$6.OverlayPanel, selector: "p-overlayPanel", inputs: ["dismissable", "showCloseIcon", "style", "styleClass", "appendTo", "autoZIndex", "ariaCloseLabel", "baseZIndex", "focusOnShow", "showTransitionOptions", "hideTransitionOptions"], outputs: ["onShow", "onHide"] }], directives: [{ type: ValidateActionDirective, selector: "[validateActions]", inputs: ["validateActions"] }, { type: i3.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { type: i1$4.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { type: i1$4.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: ActionsCellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'actions-cell', template: "<div #mydiv>\r\n  <div class=\"actions-img-container\" (click)=\"op.toggle($event)\" *validateActions=\"{rowData, actions}\">\r\n    <img src=\"assets/svg-icon/more-icon.svg\" alt=\"more\" />\r\n  </div>\r\n  <p-overlayPanel #op dismissable=\"true\" [appendTo]=\"mydiv\" styleClass=\"panelStyles\">\r\n    <ng-template pTemplate>\r\n      <ng-container *ngFor=\"let action of actions\">\r\n        <p *ngIf=\"action.isDelete && validateAction(action, rowData)\" class=\"action-label red-text\"\r\n          (click)=\"closeAftersSelect(op); actionClick(action, rowData)\">\r\n          {{\r\n          action.name\r\n          ? (action.name )\r\n          : ('TABLE.TOOLBAR.DELETE' )\r\n          }}\r\n        </p>\r\n        <p *ngIf=\"action.isEdit && validateAction(action, rowData)\" class=\"action-label\"\r\n          (click)=\"actionClick(action, rowData)\">\r\n          {{\r\n          action.name\r\n          ? (action.name )\r\n          : ('TABLE.TOOLBAR.VIEW_EDIT' )\r\n          }}\r\n        </p>\r\n        <p *ngIf=\"validateCustomAction(action, rowData)\" class=\"action-label\" (click)=\"actionClick(action, rowData)\">\r\n          <i [class]=\"action.icon\"></i>\r\n          {{ action.name }}\r\n        </p>\r\n      </ng-container>\r\n    </ng-template>\r\n  </p-overlayPanel>\r\n</div>\r\n", styles: [":root{--black: #000000;--primary-darker: #003e71;--gray-700: #4e4d55;--gray-500: #868894;--gray-300: #dcdde5;--red-50: #e5e5e5;--white: #fff;--white-50: #f1f3f4;--white-200: #f5f5f5;--white-500: #dadcdd;--gray-100: #e4ebf3;--primary: #1650ed;--danger: #e03303;--rejected-color: #f16b6b;--pending: #f2ae75;--yellow-600: #d99a28;--warning-light-color: #eecf7e;--yellow-900: #937644;--green: green;--green-700: #85cb9c;--shadow-green: rgba(73, 164, 135, .1);--shadow-light-blue: rgba(228, 233, 241, .2);--shadow-blue: rgba(114, 159, 197, .1);--shadow-black: #0000002b;--green-300: #49a487;--primary-light: #1650ed;--primary-light-gradient: linear-gradient(to bottom, #1650ed 40%, #1650ed 93%);--primary-light-right-gradient: linear-gradient(to right, #1650ed, #1650ed);--primary-gradient: linear-gradient(45deg, #1650ed, #1650ed);--secondary-gradient: linear-gradient(45deg, #937644, #f2ae75);--gradient-white: linear-gradient(to top, #fff, #fff);--box-shadow: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-green: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-10: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-primary-light: 0 -25px 0 0 #1650ed;--box-shadow-black: 3px 7px 25px 0 #0000002b;--box-shadow-light: 0 0 16px 0 rgba(107, 132, 153, .12);--box-shadow-light-blue: 6px 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-blue: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-blue-alpha: 0 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-white: 0 0 3px #ccc;--box-shadow-6: 0 4px 10px 0 rgba(0, 0, 0, .06)}::ng-deep .action-label{font-size:13px!important;color:#4e4d55;font-stretch:normal;font-style:normal;line-height:20px;letter-spacing:normal;text-align:left;margin:0!important;padding:5px 5px 5px 10px}::ng-deep .action-label:hover{background-color:#dadcdd}::ng-deep .red-text{color:#f16b6b;font-weight:700}::ng-deep .p-overlaypanel:after{border-width:8px;margin-left:-4px}::ng-deep .p-overlaypanel:before{display:none!important}::ng-deep .p-overlaypanel{display:inline-block!important;position:absolute!important;z-index:1016!important;margin-top:-5px!important;left:auto!important;top:auto!important;width:130px!important;border-radius:10px!important;box-shadow:6px 6px 15px #0080ff1f!important;border:.5px solid #e9ebf1!important;background-color:#fff}.actions-img-container img{cursor:pointer}\n"] }]
        }], ctorParameters: function () { return []; }, propDecorators: { actions: [{
                type: Input
            }], rowData: [{
                type: Input
            }], onItemSelected: [{
                type: Output
            }] } });

class YouxelTableComponent {
    constructor(languageService, service, dialogService, router, route) {
        this.languageService = languageService;
        this.service = service;
        this.dialogService = dialogService;
        this.router = router;
        this.route = route;
        this.data = [];
        this.actions = [];
        this.id = 'id';
        this.onSelected = new EventEmitter();
        this.onStatusChanged = new EventEmitter();
        this.onItemDeleted = new EventEmitter();
        this.onGetData = new EventEmitter();
        this.onSortData = new EventEmitter();
        this.columnDataTypes = ColumnDataTypes;
        this.openActionPopup = false;
        this.expandedRows = {};
        this.sortOrder = '';
    }
    ngOnInit() {
        this.languageService.enableLanguage();
        this.searchSub = this.service.search$.subscribe((resp) => {
            this.defaultOptions();
            this.getServerSideData();
        });
    }
    defaultOptions() {
        this.service.pageOptions = Object.assign({ pageSize: 10, isServerSide: true, addCheckBox: false, sortMode: TableSortSelectionModes.Multiple, requestType: ERequestTypes.get }, this.options);
    }
    changeRowStatus(row) {
        if (this.urls && this.urls.changeStatus)
            this.service
                .changeStatus({
                url: this.urls.changeStatus,
                id: row.id,
            })
                .subscribe((res) => {
                this.onStatusChanged.emit(row);
            });
        else
            this.onStatusChanged.emit(row);
    }
    getServerSideData() {
        if (this.urls && this.urls.getAll)
            this.getAllData({ pageNumber: 1 });
    }
    onPageChange(pageNumber) {
        this.getAllData({ pageNumber });
    }
    getAllData({ pageNumber }) {
        var _a;
        const url = this.urls.getAll;
        const initialFilter = this.urls.pindFilterData;
        const requestType = (_a = this.options.requestType) !== null && _a !== void 0 ? _a : ERequestTypes.get;
        this.service.pageOptions.pageNumber = pageNumber !== null && pageNumber !== void 0 ? pageNumber : 1;
        pageNumber = this.service.pageOptions.pageNumber;
        this.dataFactory(requestType, {
            url,
            pageNumber,
            initialFilter,
            orderByValue: [{ colId: this.bindFilter, sort: this.sortType }],
        })().subscribe((res) => {
            this.onGetData.emit(res);
        });
    }
    dataFactory(requestType, data) {
        const switcher = {
            [ERequestTypes.get]: () => {
                return this.service.getAllByGet(data);
            },
            [ERequestTypes.post]: () => {
                return this.service.getAllByPost(data);
            },
        };
        return switcher[requestType];
    }
    selectRow(rowIndex) {
        const index = this.selectedItems.indexOf(rowIndex);
        if (index !== -1)
            this.selectedItems.push(rowIndex);
    }
    onSort(event) {
        this.isAscending = event.order === -1;
        this.sortType = this.isAscending ? 'asc' : 'desc';
        const requestType = this.options.requestType;
        const filtered = this.columns.find((item) => event.field === item.field);
        this.bindFilter =
            filtered && filtered.filterKey ? filtered.filterKey : event.field;
        this.service.colId = `${this.bindFilter}`;
        if (this.isAscending) {
            this.service.sortOrder = `${this.bindFilter}`;
            this.service.sort = 'asc';
        }
        if (!this.isAscending) {
            this.service.sortOrder = `${this.bindFilter}_desc`;
            this.service.sort = 'desc';
        }
        const initialFilter = this.urls.pindFilterData;
        this.dataFactory(requestType, {
            url: this.urls.getAll,
            pageNumber: this.service.pageOptions.pageNumber,
            orderByValue: [{ colId: this.bindFilter, sort: this.sortType }],
            sort: this.sortType,
            colId: this.bindFilter,
            initialFilter,
        })().subscribe((res) => {
            this.onGetData.emit(res);
        });
    }
    paginate(event) {
        const pageIndex = event.first / event.rows + 1;
        this.onPageChange(pageIndex);
    }
    applyAction(event) {
        var _a;
        this.selectedItem = event.row;
        this.selectedItem.isHTMLContent = event.action.isHTMLContent;
        this.selectedItem.primaryKey = (_a = event.action.primaryKey) !== null && _a !== void 0 ? _a : 'title';
        if (event.action.isDelete)
            this.deleteRow(event.row);
        else if (event.action.isEdit)
            this.editRow(event.row);
        else if (event.action.callAsync)
            this.asyncAction(event.row, event.action.callAsync);
    }
    asyncAction(row, asyncAction) {
        asyncAction(row).subscribe(() => this.getAllData({ pageNumber: 1 }));
    }
    deleteRow(row) {
        var _a, _b, _c, _d, _e;
        const ref = this.dialogService.open(ModalComponent, {
            data: {
                template: this.deleteModal,
                rowData: row,
                buttons: {
                    cancel: (_b = (_a = this.tableTranslatedItemsFromEndUser) === null || _a === void 0 ? void 0 : _a.modelButtonsText) === null || _b === void 0 ? void 0 : _b.cancel,
                    delete: (_d = (_c = this.tableTranslatedItemsFromEndUser) === null || _c === void 0 ? void 0 : _c.modelButtonsText) === null || _d === void 0 ? void 0 : _d.delete,
                },
            },
            header: ((_e = this.tableTranslatedItemsFromEndUser) === null || _e === void 0 ? void 0 : _e.modelHeaderText) ||
                'Delete Confirmation',
        });
        ref.onClose.subscribe((res) => {
            if (res && this.urls.delete)
                this.service
                    .deleteItem({ url: this.urls.delete, id: row.id })
                    .subscribe((res) => {
                    this.onItemDeleted.emit(true);
                    this.getAllData({
                        pageNumber: this.service.pageOptions.pageNumber,
                    });
                });
        });
    }
    editRow(row) {
        this.router.navigate(['edit/' + row.id], { relativeTo: this.route.parent });
    }
    onRowSelect(event) {
        this.selectedData = event;
    }
    onRowUnselect(event) {
        this.selectedData = event;
    }
    cellClicked(col, row, callback) {
        if (!col.isClicked)
            return;
        return col.action ? col.action(row) : callback;
    }
    onImageError(event, col) {
        if (col.loadingError)
            event.target.src = col.loadingError;
    }
    getSelected(selected) {
        this.selectedData = selected;
    }
    ngOnDestroy() {
        this.searchSub.unsubscribe();
        this.service.initTableData();
    }
}
YouxelTableComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: YouxelTableComponent, deps: [{ token: i1.LanguageService }, { token: YxlTableService }, { token: i1$3.DialogService }, { token: i4$1.Router }, { token: i4$1.ActivatedRoute }], target: i0.ɵɵFactoryTarget.Component });
YouxelTableComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: YouxelTableComponent, selector: "app-youxel-table", inputs: { data: "data", urls: "urls", columns: "columns", options: "options", actions: "actions", id: "id", tableTranslatedItemsFromEndUser: "tableTranslatedItemsFromEndUser" }, outputs: { onSelected: "onSelected", onStatusChanged: "onStatusChanged", onItemDeleted: "onItemDeleted", onGetData: "onGetData", onSortData: "onSortData" }, viewQueries: [{ propertyName: "deleteModal", first: true, predicate: ["deleteModal"], descendants: true, static: true }], ngImport: i0, template: "<div class=\"youxel-table\" *ngIf=\"service.tableData?.length\">\r\n  <p-table\r\n    [value]=\"service.tableData\"\r\n    [paginator]=\"service.pageOptions.paginator\"\r\n    [resetPageOnSort]=\"false\"\r\n    [lazy]=\"true\"\r\n    [columns]=\"columns\"\r\n    [rows]=\"service.pageOptions.pageSize\"\r\n    [expandedRowKeys]=\"expandedRows\"\r\n    currentPageReportTemplate=\"{{\r\n      tableTranslatedItemsFromEndUser?.paginationTranslationTxt?.showing\r\n    }}\r\n    {last}\r\n    {{ tableTranslatedItemsFromEndUser?.paginationTranslationTxt?.off }}\r\n    {totalRecords}\"\r\n    [showCurrentPageReport]=\"\r\n      service.pageOptions.showCurrentPageReport === undefined\r\n        ? true\r\n        : service.pageOptions.showCurrentPageReport\r\n    \"\r\n    [totalRecords]=\"service.pageOptions.totalCount\"\r\n    [loading]=\"service.pageOptions.loading\"\r\n    (onRowSelect)=\"onRowSelect($event)\"\r\n    (onRowUnselect)=\"onRowUnselect($event)\"\r\n    [ngClass]=\"{ 'sticky-header': service.pageOptions.sticky }\"\r\n    styleClass=\"p-datatable-responsive-demo\"\r\n    [sortMode]=\"service.pageOptions.sortMode\"\r\n    [(selection)]=\"selectedData\"\r\n    selectionMode=\"service.pageOptions.selectionMode\"\r\n    resizableColumns=\"service.pageOptions.resizableColumns\"\r\n    responsiveLayout=\"scroll\"\r\n    [responsive]=\"true\"\r\n    (onSort)=\"onSort($event)\"\r\n    (onPage)=\"paginate($event)\"\r\n    [styleClass]=\"languageService.isEnglish() ? '' : 'rtl'\"\r\n    dataKey=\"row\"\r\n    expandableRows=\"true\"\r\n  >\r\n    <ng-template pTemplate=\"header\" let-columns>\r\n      <tr *ngIf=\"service.pageOptions.filter\">\r\n        <th style=\"width: 3rem\" *ngIf=\"service.pageOptions.addCheckBox\">\r\n          <p-tableHeaderCheckbox></p-tableHeaderCheckbox>\r\n        </th>\r\n\r\n        <th\r\n          pResizableColumn\r\n          *ngFor=\"let col of columns\"\r\n          [pSortableColumn]=\"service.pageOptions.showSort && col.field\"\r\n          [ngClass]=\"{ disableSort: col.type === columnDataTypes.Image }\"\r\n        >\r\n          <div\r\n            class=\"align-header-title\"\r\n            [style]=\"col.customStyles?.headerStyle\"\r\n          >\r\n            {{ col.header }}\r\n\r\n            <div class=\"align-icons Image_Data_table\" *ngIf=\"col.hideSort\">\r\n              <p-sortIcon\r\n                [field]=\"col.field\"\r\n                [class.up]=\"isAscending == true\"\r\n                [class.down]=\"isAscending == false\"\r\n                *ngIf=\"service.pageOptions.showSort\"\r\n              >\r\n              </p-sortIcon>\r\n            </div>\r\n\r\n            <div class=\"align-icons\" *ngIf=\"!col.hideSort\">\r\n              <p-sortIcon\r\n                [field]=\"col.field\"\r\n                [class.up]=\"isAscending == true\"\r\n                [class.down]=\"isAscending == false\"\r\n                *ngIf=\"service.pageOptions.showSort\"\r\n              >\r\n              </p-sortIcon>\r\n            </div>\r\n          </div>\r\n        </th>\r\n\r\n        <th class=\"align-header-title\" *ngIf=\"actions\">\r\n          {{ tableTranslatedItemsFromEndUser?.actionColHeader }}\r\n        </th>\r\n      </tr>\r\n    </ng-template>\r\n\r\n    <ng-template\r\n      pTemplate=\"body\"\r\n      let-rowData\r\n      let-columns=\"columns\"\r\n      let-expanded=\"expanded\"\r\n    >\r\n      <tr [pSelectableRow]=\"rowData\" class=\"rowItem\">\r\n        <td class=\"checkbox-width\" *ngIf=\"service.pageOptions.addCheckBox\">\r\n          <p-tableCheckbox [value]=\"rowData\"></p-tableCheckbox>\r\n        </td>\r\n        <td\r\n          *ngFor=\"let col of columns\"\r\n          [style]=\"col.customStyles?.columnStyle\"\r\n          [ngClass]=\"{ pointer: col.isClicked }\"\r\n          (click)=\"cellClicked(col, rowData)\"\r\n        >\r\n          <table-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.String\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-string-cell>\r\n\r\n          <table-render-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.RenderString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-render-string-cell>\r\n\r\n          <table-custome-cell\r\n            *ngIf=\"col.type === columnDataTypes.customeCell\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-custome-cell>\r\n\r\n          <table-date-cell\r\n            *ngIf=\"col.type === columnDataTypes.Date\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-date-cell>\r\n\r\n          <table-date-time-cell\r\n            *ngIf=\"col.type === columnDataTypes.DateTime\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-date-time-cell>\r\n\r\n          <table-input-switch-cell\r\n            *ngIf=\"col.type === columnDataTypes.Boolean\"\r\n            [rowData]=\"rowData\"\r\n            [col]=\"col\"\r\n            (statusChangedEmitter)=\"changeRowStatus($event)\"\r\n          ></table-input-switch-cell>\r\n\r\n          <table-image-cell\r\n            *ngIf=\"col.type === columnDataTypes.Image\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (emitError)=\"onImageError($event, col)\"\r\n          ></table-image-cell>\r\n\r\n          <table-image-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.ImageWithString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (emitError)=\"onImageError($event, col)\"\r\n          ></table-image-string-cell>\r\n\r\n          <table-decrypted-string\r\n            *ngIf=\"col.type === columnDataTypes.DecryptedString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-decrypted-string>\r\n        </td>\r\n\r\n        <td *ngIf=\"actions && actions.length > 0\" class=\"actionsCol\">\r\n          <actions-cell\r\n            [rowData]=\"rowData\"\r\n            [actions]=\"actions\"\r\n            (onItemSelected)=\"applyAction($event)\"\r\n          ></actions-cell>\r\n        </td>\r\n\r\n        <td id=\"showExpand\" class=\"d-xl-none d-lg-none\">\r\n          <button\r\n            type=\"button\"\r\n            pButton\r\n            pRipple\r\n            [pRowToggler]=\"rowData\"\r\n            class=\"p-button-text p-button-rounded p-button-plain\"\r\n            [icon]=\"expanded ? 'pi pi-chevron-down' : 'pi pi-chevron-right'\"\r\n          ></button>\r\n        </td>\r\n      </tr>\r\n    </ng-template>\r\n    <ng-template pTemplate=\"rowexpansion\" let-rowData let-columns=\"columns\">\r\n      <div class=\"expanded-container\">\r\n        <div class=\"expand-row\" *ngFor=\"let col of columns\">\r\n          <div class=\"expand-header\">{{ col.header }}</div>\r\n\r\n          <table-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.String\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-string-cell>\r\n\r\n          <table-render-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.RenderString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-render-string-cell>\r\n\r\n          <table-custome-cell\r\n            *ngIf=\"col.type === columnDataTypes.customeCell\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-custome-cell>\r\n\r\n          <table-date-cell\r\n            *ngIf=\"col.type === columnDataTypes.Date\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-date-cell>\r\n\r\n          <table-date-time-cell\r\n            *ngIf=\"col.type === columnDataTypes.DateTime\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-date-time-cell>\r\n\r\n          <table-input-switch-cell\r\n            *ngIf=\"col.type === columnDataTypes.Boolean\"\r\n            [rowData]=\"rowData\"\r\n            [col]=\"col\"\r\n            (statusChangedEmitter)=\"changeRowStatus($event)\"\r\n          ></table-input-switch-cell>\r\n\r\n          <table-image-cell\r\n            *ngIf=\"col.type === columnDataTypes.Image\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (emitError)=\"onImageError($event, col)\"\r\n          ></table-image-cell>\r\n\r\n          <table-image-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.ImageWithString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (emitError)=\"onImageError($event, col)\"\r\n          ></table-image-string-cell>\r\n\r\n          <table-decrypted-string\r\n            *ngIf=\"col.type === columnDataTypes.DecryptedString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-decrypted-string>\r\n        </div>\r\n      </div>\r\n    </ng-template>\r\n  </p-table>\r\n</div>\r\n\r\n<ng-template #deleteModal>\r\n  <div class=\"confirmation d-flex align-items-center\">\r\n    <div class=\"d-flex align-items-center\">\r\n      {{ tableTranslatedItemsFromEndUser?.modelDeleteActionName }}\r\n      <span\r\n        class=\"font-weight-bold text-truncate\"\r\n        *ngIf=\"!selectedItem.isHTMLContent\"\r\n        >\"{{ selectedItem[selectedItem.primaryKey] | strLimit }}\"</span\r\n      >\r\n      <span\r\n        class=\"font-weight-bold text-truncate\"\r\n        [innerHtml]=\"selectedItem[selectedItem.primaryKey] | strLimit\"\r\n        *ngIf=\"selectedItem.isHTMLContent\"\r\n      ></span>\r\n      <span> {{ tableTranslatedItemsFromEndUser?.confirmationDeleteMsg }}</span>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n", styles: [":root{--black: #000000;--primary-darker: #003e71;--gray-700: #4e4d55;--gray-500: #868894;--gray-300: #dcdde5;--red-50: #e5e5e5;--white: #fff;--white-50: #f1f3f4;--white-200: #f5f5f5;--white-500: #dadcdd;--gray-100: #e4ebf3;--primary: #1650ed;--danger: #e03303;--rejected-color: #f16b6b;--pending: #f2ae75;--yellow-600: #d99a28;--warning-light-color: #eecf7e;--yellow-900: #937644;--green: green;--green-700: #85cb9c;--shadow-green: rgba(73, 164, 135, .1);--shadow-light-blue: rgba(228, 233, 241, .2);--shadow-blue: rgba(114, 159, 197, .1);--shadow-black: #0000002b;--green-300: #49a487;--primary-light: #1650ed;--primary-light-gradient: linear-gradient(to bottom, #1650ed 40%, #1650ed 93%);--primary-light-right-gradient: linear-gradient(to right, #1650ed, #1650ed);--primary-gradient: linear-gradient(45deg, #1650ed, #1650ed);--secondary-gradient: linear-gradient(45deg, #937644, #f2ae75);--gradient-white: linear-gradient(to top, #fff, #fff);--box-shadow: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-green: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-10: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-primary-light: 0 -25px 0 0 #1650ed;--box-shadow-black: 3px 7px 25px 0 #0000002b;--box-shadow-light: 0 0 16px 0 rgba(107, 132, 153, .12);--box-shadow-light-blue: 6px 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-blue: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-blue-alpha: 0 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-white: 0 0 3px #ccc;--box-shadow-6: 0 4px 10px 0 rgba(0, 0, 0, .06)}.youxel-table .sticky-header ::ng-deep .p-datatable .p-datatable-thead>tr>th{position:sticky}.youxel-table .green-color{color:#cd5c5c}.youxel-table .p-button-danger{margin-left:10px;margin-right:10px}.youxel-table .checkbox-width{width:50px}.youxel-table .p-input-icon-left{margin-left:10px}.youxel-table .p-input-icon-left input{height:36px}.youxel-table .expand-header{color:#868894;margin-bottom:10px}.youxel-table .expand-content{margin-bottom:10px}.youxel-table .description-text{width:200px;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;word-break:break-word;white-space:nowrap;text-overflow:ellipsis}.youxel-table .expanded-container{width:max-content;padding:20px}.youxel-table .expanded-container .expaned-description-text{word-wrap:break-word;width:350px}.youxel-table .image-data{width:45px;height:40px}.youxel-table .image-title{display:flex;align-items:center}.youxel-table .image-title .td-data{margin-left:5px}.youxel-table ::ng-deep .p-datatable .p-datatable-thead>tr>th{border:none}.youxel-table ::ng-deep p-table tr td{cursor:default!important}.youxel-table ::ng-deep p-table tr td.pointer{cursor:pointer!important}.youxel-table ::ng-deep p-table .p-datatable#news-grid .datatable-body .datatable-scroll .datatable-row-wrapper:last-child{border-radius:0 0 8px 8px}@media screen and (min-width: 280px) and (max-width: 550px){.youxel-table ::ng-deep p-table tr th:nth-child(n+4):not(:last-child),.youxel-table ::ng-deep p-table tr td:nth-child(n+4):not(:last-child){display:none}}@media screen and (min-width: 500px) and (max-width: 992px){.youxel-table ::ng-deep .expaned-description-text{width:550px!important}}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator{margin-top:20px;background-color:#e4ebf3;border:none}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator .p-paginator-current{color:#868894;position:absolute;left:0}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-first.p-paginator-element.p-link.p-disabled.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-first.p-paginator-element.p-link.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-last.p-paginator-element.p-link.p-ripple{display:none}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-prev.p-paginator-element.p-link.p-disabled.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-prev.p-paginator-element.p-link.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-next.p-paginator-element.p-link.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-next.p-paginator-element.p-link.p-disabled.p-ripple{color:#cce8ff!important;text-align:center;width:56px!important;border-radius:50px!important;background-color:#fff}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-next.p-paginator-element.p-link.p-ripple span.p-paginator-icon:before,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-next.p-paginator-element.p-link.p-disabled.p-ripple span.p-paginator-icon:before{content:\"\\e91b\"}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-prev.p-paginator-element.p-link.p-ripple span.p-paginator-icon:before,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-prev.p-paginator-element.p-link.p-disabled.p-ripple span.p-paginator-icon:before{content:\"\\e91a\"}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator span.p-paginator-pages{margin:0 20px;padding:0;border-radius:18px;overflow:hidden;background-color:#fff;box-shadow:0 0 20px #729fc51a;list-style:none;display:flex}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator span.p-paginator-pages .p-paginator-page{margin:0}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator span.p-paginator-pages .p-paginator-page.p-paginator-element.p-link.p-highlight.p-ripple{width:45px;height:35px;border:0;display:flex;align-items:center;justify-content:center;padding:.4rem .75rem;z-index:1;color:#01254c!important;font-weight:500!important;border-radius:18px;background-color:#1650ed4d}.youxel-table ::ng-deep p-table .ui-sortable-column-icon:before{content:\"\"}.youxel-table ::ng-deep p-table .p-datatable .datatable-body .datatable-scroll .datatable-row-wrapper:last-child{border-radius:0 0 8px 8px}.youxel-table ::ng-deep p-table .ui-sortable-column-icon.fa-sort-desc:before{content:\"newdownicon\"}.youxel-table ::ng-deep p-table .ui-sortable-column-icon.fa-sort-asc:before{content:\"newupicon\"}.youxel-table ::ng-deep p-table .p-datatable .p-datatable-tbody>tr:hover{background-color:#fff}.youxel-table ::ng-deep p-table .p-datatable{background-color:#e4ebf3}.youxel-table ::ng-deep p-table .p-inputswitch.p-inputswitch-checked .p-inputswitch-slider{background:#a5e6ba}.youxel-table ::ng-deep p-table .p-datatable .p-sortable-column .p-sortable-column-icon{margin-left:0!important}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt{display:flex;flex-direction:column}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt:before,.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt:after{font-size:10px;position:relative}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt:before{content:\"\\e907\";top:5px}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt:after{content:\"\\e906\";top:4px}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-up-alt:after,.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-down:after{position:relative;right:6px;top:5px;font-size:10px;background-position:center;background-repeat:no-repeat;background-size:contain}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-up-alt:before,.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-down:before{font-size:10px;background-size:contain;top:-4px;left:4px;position:relative}.youxel-table ::ng-deep p-table p-sorticon.up .pi-sort-amount-up-alt:before{background-image:url(../../../../assets/images/icons/sort-up.png);color:transparent}.youxel-table ::ng-deep p-table p-sorticon.down .pi-sort-amount-up-alt:after{background-image:url(../../../../assets/images/icons/sort-down.png);color:transparent}.youxel-table ::ng-deep p-table p-sorticon.up .pi-sort-amount-down:before{background-image:url(../../../../assets/images/icons/sort-up.png);color:transparent}.youxel-table ::ng-deep p-table p-sorticon.down .pi-sort-amount-down:after{background-image:url(../../../../assets/images/icons/sort-down.png);color:transparent}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-up-alt:before{content:\"\\e907\"}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-up-alt:after{content:\"\\e906\"}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-down:before{content:\"\\e907\"}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-down:after{content:\"\\e906\"}.youxel-table ::ng-deep p-table .p-datatable .p-sortable-column.p-highlight .p-sortable-column-icon{color:#1650ed}.youxel-table ::ng-deep p-table .p-datatable .p-sortable-column:focus{box-shadow:none;outline:none;background:transparent;color:#1650ed}.youxel-table ::ng-deep p-table .p-datatable .p-sortable-column:hover{background:transparent}.youxel-table ::ng-deep p-table .align-icons{display:flex;flex-direction:column;margin-top:-5px}.youxel-table ::ng-deep p-table .align-header-title{display:flex;align-items:center;font-size:14px;font-weight:400;font-stretch:normal;font-style:normal;line-height:1.29;letter-spacing:normal;text-align:left;color:#868894}.font-weight-bold{font-weight:700;margin:0 5px}.pinIcon{width:16px;height:16px;background-image:url(/assets/images/icons/pin.png)}:host-context(body.lang-ar){direction:rtl!important}:host-context(body.lang-ar) ::ng-deep .youxel-table p-table .p-paginator-bottom.p-paginator{direction:rtl!important}:host-context(body.lang-ar) ::ng-deep button.p-paginator-next.p-paginator-element.p-link.p-ripple span.p-paginator-icon:before,:host-context(body.lang-ar) ::ng-deep button.p-paginator-next.p-paginator-element.p-link.p-disabled.p-ripple span.p-paginator-icon:before{content:\"\\e91a\"!important}:host-context(body.lang-ar) ::ng-deep button.p-paginator-prev.p-paginator-element.p-link.p-ripple span.p-paginator-icon:before,:host-context(body.lang-ar) ::ng-deep button.p-paginator-prev.p-paginator-element.p-link.p-disabled.p-ripple span.p-paginator-icon:before{content:\"\\e91b\"!important}\n"], components: [{ type: i5.Table, selector: "p-table", inputs: ["frozenColumns", "frozenValue", "style", "styleClass", "tableStyle", "tableStyleClass", "paginator", "pageLinks", "rowsPerPageOptions", "alwaysShowPaginator", "paginatorPosition", "paginatorDropdownAppendTo", "paginatorDropdownScrollHeight", "currentPageReportTemplate", "showCurrentPageReport", "showJumpToPageDropdown", "showJumpToPageInput", "showFirstLastIcon", "showPageLinks", "defaultSortOrder", "sortMode", "resetPageOnSort", "selectionMode", "contextMenuSelection", "contextMenuSelectionMode", "dataKey", "metaKeySelection", "rowTrackBy", "lazy", "lazyLoadOnInit", "compareSelectionBy", "csvSeparator", "exportFilename", "filters", "globalFilterFields", "filterDelay", "filterLocale", "expandedRowKeys", "editingRowKeys", "rowExpandMode", "scrollable", "scrollDirection", "rowGroupMode", "scrollHeight", "virtualScroll", "virtualScrollDelay", "virtualRowHeight", "frozenWidth", "responsive", "contextMenu", "resizableColumns", "columnResizeMode", "reorderableColumns", "loading", "loadingIcon", "showLoader", "rowHover", "customSort", "showInitialSortBadge", "autoLayout", "exportFunction", "stateKey", "stateStorage", "editMode", "groupRowsBy", "groupRowsByOrder", "minBufferPx", "maxBufferPx", "responsiveLayout", "breakpoint", "value", "columns", "first", "rows", "totalRecords", "sortField", "sortOrder", "multiSortMeta", "selection"], outputs: ["selectionChange", "contextMenuSelectionChange", "onRowSelect", "onRowUnselect", "onPage", "onSort", "onFilter", "onLazyLoad", "onRowExpand", "onRowCollapse", "onContextMenuSelect", "onColResize", "onColReorder", "onRowReorder", "onEditInit", "onEditComplete", "onEditCancel", "onHeaderCheckboxToggle", "sortFunction", "firstChange", "rowsChange", "onStateSave", "onStateRestore"] }, { type: i5.TableHeaderCheckbox, selector: "p-tableHeaderCheckbox", inputs: ["disabled", "inputId", "name", "ariaLabel"] }, { type: i5.SortIcon, selector: "p-sortIcon", inputs: ["field"] }, { type: i5.TableCheckbox, selector: "p-tableCheckbox", inputs: ["disabled", "value", "index", "inputId", "name", "required", "ariaLabel"] }, { type: StringCellComponent, selector: "table-string-cell", inputs: ["col", "rowData"] }, { type: RenderStringCellComponent, selector: "table-render-string-cell", inputs: ["col", "rowData"] }, { type: CustomeCellComponent, selector: "table-custome-cell", inputs: ["col", "rowData"] }, { type: DateCellComponent, selector: "table-date-cell", inputs: ["col", "rowData"] }, { type: TableDateTimeCellComponent, selector: "table-date-time-cell", inputs: ["col", "rowData"] }, { type: InputSwitchCellComponent, selector: "table-input-switch-cell", inputs: ["col", "rowData"], outputs: ["statusChangedEmitter"] }, { type: ImageCellComponent, selector: "table-image-cell", inputs: ["col", "rowData", "imageStyle"], outputs: ["emitError"] }, { type: ImageStringCellComponent, selector: "table-image-string-cell", inputs: ["col", "rowData", "imageStyle"], outputs: ["emitError"] }, { type: DecryptedStringComponent, selector: "table-decrypted-string", inputs: ["col", "rowData"] }, { type: ActionsCellComponent, selector: "actions-cell", inputs: ["actions", "rowData"], outputs: ["onItemSelected"] }], directives: [{ type: i1$4.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i1$4.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { type: i3.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { type: i1$4.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { type: i5.ResizableColumn, selector: "[pResizableColumn]", inputs: ["pResizableColumnDisabled"] }, { type: i5.SortableColumn, selector: "[pSortableColumn]", inputs: ["pSortableColumn", "pSortableColumnDisabled"] }, { type: i5.SelectableRow, selector: "[pSelectableRow]", inputs: ["pSelectableRow", "pSelectableRowIndex", "pSelectableRowDisabled"] }, { type: i1$1.ButtonDirective, selector: "[pButton]", inputs: ["iconPos", "loadingIcon", "label", "icon", "loading"] }, { type: i19.Ripple, selector: "[pRipple]" }, { type: i5.RowToggler, selector: "[pRowToggler]", inputs: ["pRowToggler", "pRowTogglerDisabled"] }], pipes: { "strLimit": i1.StringLimitPipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: YouxelTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-youxel-table', template: "<div class=\"youxel-table\" *ngIf=\"service.tableData?.length\">\r\n  <p-table\r\n    [value]=\"service.tableData\"\r\n    [paginator]=\"service.pageOptions.paginator\"\r\n    [resetPageOnSort]=\"false\"\r\n    [lazy]=\"true\"\r\n    [columns]=\"columns\"\r\n    [rows]=\"service.pageOptions.pageSize\"\r\n    [expandedRowKeys]=\"expandedRows\"\r\n    currentPageReportTemplate=\"{{\r\n      tableTranslatedItemsFromEndUser?.paginationTranslationTxt?.showing\r\n    }}\r\n    {last}\r\n    {{ tableTranslatedItemsFromEndUser?.paginationTranslationTxt?.off }}\r\n    {totalRecords}\"\r\n    [showCurrentPageReport]=\"\r\n      service.pageOptions.showCurrentPageReport === undefined\r\n        ? true\r\n        : service.pageOptions.showCurrentPageReport\r\n    \"\r\n    [totalRecords]=\"service.pageOptions.totalCount\"\r\n    [loading]=\"service.pageOptions.loading\"\r\n    (onRowSelect)=\"onRowSelect($event)\"\r\n    (onRowUnselect)=\"onRowUnselect($event)\"\r\n    [ngClass]=\"{ 'sticky-header': service.pageOptions.sticky }\"\r\n    styleClass=\"p-datatable-responsive-demo\"\r\n    [sortMode]=\"service.pageOptions.sortMode\"\r\n    [(selection)]=\"selectedData\"\r\n    selectionMode=\"service.pageOptions.selectionMode\"\r\n    resizableColumns=\"service.pageOptions.resizableColumns\"\r\n    responsiveLayout=\"scroll\"\r\n    [responsive]=\"true\"\r\n    (onSort)=\"onSort($event)\"\r\n    (onPage)=\"paginate($event)\"\r\n    [styleClass]=\"languageService.isEnglish() ? '' : 'rtl'\"\r\n    dataKey=\"row\"\r\n    expandableRows=\"true\"\r\n  >\r\n    <ng-template pTemplate=\"header\" let-columns>\r\n      <tr *ngIf=\"service.pageOptions.filter\">\r\n        <th style=\"width: 3rem\" *ngIf=\"service.pageOptions.addCheckBox\">\r\n          <p-tableHeaderCheckbox></p-tableHeaderCheckbox>\r\n        </th>\r\n\r\n        <th\r\n          pResizableColumn\r\n          *ngFor=\"let col of columns\"\r\n          [pSortableColumn]=\"service.pageOptions.showSort && col.field\"\r\n          [ngClass]=\"{ disableSort: col.type === columnDataTypes.Image }\"\r\n        >\r\n          <div\r\n            class=\"align-header-title\"\r\n            [style]=\"col.customStyles?.headerStyle\"\r\n          >\r\n            {{ col.header }}\r\n\r\n            <div class=\"align-icons Image_Data_table\" *ngIf=\"col.hideSort\">\r\n              <p-sortIcon\r\n                [field]=\"col.field\"\r\n                [class.up]=\"isAscending == true\"\r\n                [class.down]=\"isAscending == false\"\r\n                *ngIf=\"service.pageOptions.showSort\"\r\n              >\r\n              </p-sortIcon>\r\n            </div>\r\n\r\n            <div class=\"align-icons\" *ngIf=\"!col.hideSort\">\r\n              <p-sortIcon\r\n                [field]=\"col.field\"\r\n                [class.up]=\"isAscending == true\"\r\n                [class.down]=\"isAscending == false\"\r\n                *ngIf=\"service.pageOptions.showSort\"\r\n              >\r\n              </p-sortIcon>\r\n            </div>\r\n          </div>\r\n        </th>\r\n\r\n        <th class=\"align-header-title\" *ngIf=\"actions\">\r\n          {{ tableTranslatedItemsFromEndUser?.actionColHeader }}\r\n        </th>\r\n      </tr>\r\n    </ng-template>\r\n\r\n    <ng-template\r\n      pTemplate=\"body\"\r\n      let-rowData\r\n      let-columns=\"columns\"\r\n      let-expanded=\"expanded\"\r\n    >\r\n      <tr [pSelectableRow]=\"rowData\" class=\"rowItem\">\r\n        <td class=\"checkbox-width\" *ngIf=\"service.pageOptions.addCheckBox\">\r\n          <p-tableCheckbox [value]=\"rowData\"></p-tableCheckbox>\r\n        </td>\r\n        <td\r\n          *ngFor=\"let col of columns\"\r\n          [style]=\"col.customStyles?.columnStyle\"\r\n          [ngClass]=\"{ pointer: col.isClicked }\"\r\n          (click)=\"cellClicked(col, rowData)\"\r\n        >\r\n          <table-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.String\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-string-cell>\r\n\r\n          <table-render-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.RenderString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-render-string-cell>\r\n\r\n          <table-custome-cell\r\n            *ngIf=\"col.type === columnDataTypes.customeCell\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-custome-cell>\r\n\r\n          <table-date-cell\r\n            *ngIf=\"col.type === columnDataTypes.Date\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-date-cell>\r\n\r\n          <table-date-time-cell\r\n            *ngIf=\"col.type === columnDataTypes.DateTime\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-date-time-cell>\r\n\r\n          <table-input-switch-cell\r\n            *ngIf=\"col.type === columnDataTypes.Boolean\"\r\n            [rowData]=\"rowData\"\r\n            [col]=\"col\"\r\n            (statusChangedEmitter)=\"changeRowStatus($event)\"\r\n          ></table-input-switch-cell>\r\n\r\n          <table-image-cell\r\n            *ngIf=\"col.type === columnDataTypes.Image\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (emitError)=\"onImageError($event, col)\"\r\n          ></table-image-cell>\r\n\r\n          <table-image-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.ImageWithString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (emitError)=\"onImageError($event, col)\"\r\n          ></table-image-string-cell>\r\n\r\n          <table-decrypted-string\r\n            *ngIf=\"col.type === columnDataTypes.DecryptedString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-decrypted-string>\r\n        </td>\r\n\r\n        <td *ngIf=\"actions && actions.length > 0\" class=\"actionsCol\">\r\n          <actions-cell\r\n            [rowData]=\"rowData\"\r\n            [actions]=\"actions\"\r\n            (onItemSelected)=\"applyAction($event)\"\r\n          ></actions-cell>\r\n        </td>\r\n\r\n        <td id=\"showExpand\" class=\"d-xl-none d-lg-none\">\r\n          <button\r\n            type=\"button\"\r\n            pButton\r\n            pRipple\r\n            [pRowToggler]=\"rowData\"\r\n            class=\"p-button-text p-button-rounded p-button-plain\"\r\n            [icon]=\"expanded ? 'pi pi-chevron-down' : 'pi pi-chevron-right'\"\r\n          ></button>\r\n        </td>\r\n      </tr>\r\n    </ng-template>\r\n    <ng-template pTemplate=\"rowexpansion\" let-rowData let-columns=\"columns\">\r\n      <div class=\"expanded-container\">\r\n        <div class=\"expand-row\" *ngFor=\"let col of columns\">\r\n          <div class=\"expand-header\">{{ col.header }}</div>\r\n\r\n          <table-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.String\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-string-cell>\r\n\r\n          <table-render-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.RenderString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-render-string-cell>\r\n\r\n          <table-custome-cell\r\n            *ngIf=\"col.type === columnDataTypes.customeCell\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-custome-cell>\r\n\r\n          <table-date-cell\r\n            *ngIf=\"col.type === columnDataTypes.Date\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-date-cell>\r\n\r\n          <table-date-time-cell\r\n            *ngIf=\"col.type === columnDataTypes.DateTime\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-date-time-cell>\r\n\r\n          <table-input-switch-cell\r\n            *ngIf=\"col.type === columnDataTypes.Boolean\"\r\n            [rowData]=\"rowData\"\r\n            [col]=\"col\"\r\n            (statusChangedEmitter)=\"changeRowStatus($event)\"\r\n          ></table-input-switch-cell>\r\n\r\n          <table-image-cell\r\n            *ngIf=\"col.type === columnDataTypes.Image\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (emitError)=\"onImageError($event, col)\"\r\n          ></table-image-cell>\r\n\r\n          <table-image-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.ImageWithString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (emitError)=\"onImageError($event, col)\"\r\n          ></table-image-string-cell>\r\n\r\n          <table-decrypted-string\r\n            *ngIf=\"col.type === columnDataTypes.DecryptedString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-decrypted-string>\r\n        </div>\r\n      </div>\r\n    </ng-template>\r\n  </p-table>\r\n</div>\r\n\r\n<ng-template #deleteModal>\r\n  <div class=\"confirmation d-flex align-items-center\">\r\n    <div class=\"d-flex align-items-center\">\r\n      {{ tableTranslatedItemsFromEndUser?.modelDeleteActionName }}\r\n      <span\r\n        class=\"font-weight-bold text-truncate\"\r\n        *ngIf=\"!selectedItem.isHTMLContent\"\r\n        >\"{{ selectedItem[selectedItem.primaryKey] | strLimit }}\"</span\r\n      >\r\n      <span\r\n        class=\"font-weight-bold text-truncate\"\r\n        [innerHtml]=\"selectedItem[selectedItem.primaryKey] | strLimit\"\r\n        *ngIf=\"selectedItem.isHTMLContent\"\r\n      ></span>\r\n      <span> {{ tableTranslatedItemsFromEndUser?.confirmationDeleteMsg }}</span>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n", styles: [":root{--black: #000000;--primary-darker: #003e71;--gray-700: #4e4d55;--gray-500: #868894;--gray-300: #dcdde5;--red-50: #e5e5e5;--white: #fff;--white-50: #f1f3f4;--white-200: #f5f5f5;--white-500: #dadcdd;--gray-100: #e4ebf3;--primary: #1650ed;--danger: #e03303;--rejected-color: #f16b6b;--pending: #f2ae75;--yellow-600: #d99a28;--warning-light-color: #eecf7e;--yellow-900: #937644;--green: green;--green-700: #85cb9c;--shadow-green: rgba(73, 164, 135, .1);--shadow-light-blue: rgba(228, 233, 241, .2);--shadow-blue: rgba(114, 159, 197, .1);--shadow-black: #0000002b;--green-300: #49a487;--primary-light: #1650ed;--primary-light-gradient: linear-gradient(to bottom, #1650ed 40%, #1650ed 93%);--primary-light-right-gradient: linear-gradient(to right, #1650ed, #1650ed);--primary-gradient: linear-gradient(45deg, #1650ed, #1650ed);--secondary-gradient: linear-gradient(45deg, #937644, #f2ae75);--gradient-white: linear-gradient(to top, #fff, #fff);--box-shadow: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-green: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-10: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-primary-light: 0 -25px 0 0 #1650ed;--box-shadow-black: 3px 7px 25px 0 #0000002b;--box-shadow-light: 0 0 16px 0 rgba(107, 132, 153, .12);--box-shadow-light-blue: 6px 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-blue: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-blue-alpha: 0 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-white: 0 0 3px #ccc;--box-shadow-6: 0 4px 10px 0 rgba(0, 0, 0, .06)}.youxel-table .sticky-header ::ng-deep .p-datatable .p-datatable-thead>tr>th{position:sticky}.youxel-table .green-color{color:#cd5c5c}.youxel-table .p-button-danger{margin-left:10px;margin-right:10px}.youxel-table .checkbox-width{width:50px}.youxel-table .p-input-icon-left{margin-left:10px}.youxel-table .p-input-icon-left input{height:36px}.youxel-table .expand-header{color:#868894;margin-bottom:10px}.youxel-table .expand-content{margin-bottom:10px}.youxel-table .description-text{width:200px;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;word-break:break-word;white-space:nowrap;text-overflow:ellipsis}.youxel-table .expanded-container{width:max-content;padding:20px}.youxel-table .expanded-container .expaned-description-text{word-wrap:break-word;width:350px}.youxel-table .image-data{width:45px;height:40px}.youxel-table .image-title{display:flex;align-items:center}.youxel-table .image-title .td-data{margin-left:5px}.youxel-table ::ng-deep .p-datatable .p-datatable-thead>tr>th{border:none}.youxel-table ::ng-deep p-table tr td{cursor:default!important}.youxel-table ::ng-deep p-table tr td.pointer{cursor:pointer!important}.youxel-table ::ng-deep p-table .p-datatable#news-grid .datatable-body .datatable-scroll .datatable-row-wrapper:last-child{border-radius:0 0 8px 8px}@media screen and (min-width: 280px) and (max-width: 550px){.youxel-table ::ng-deep p-table tr th:nth-child(n+4):not(:last-child),.youxel-table ::ng-deep p-table tr td:nth-child(n+4):not(:last-child){display:none}}@media screen and (min-width: 500px) and (max-width: 992px){.youxel-table ::ng-deep .expaned-description-text{width:550px!important}}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator{margin-top:20px;background-color:#e4ebf3;border:none}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator .p-paginator-current{color:#868894;position:absolute;left:0}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-first.p-paginator-element.p-link.p-disabled.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-first.p-paginator-element.p-link.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-last.p-paginator-element.p-link.p-ripple{display:none}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-prev.p-paginator-element.p-link.p-disabled.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-prev.p-paginator-element.p-link.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-next.p-paginator-element.p-link.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-next.p-paginator-element.p-link.p-disabled.p-ripple{color:#cce8ff!important;text-align:center;width:56px!important;border-radius:50px!important;background-color:#fff}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-next.p-paginator-element.p-link.p-ripple span.p-paginator-icon:before,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-next.p-paginator-element.p-link.p-disabled.p-ripple span.p-paginator-icon:before{content:\"\\e91b\"}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-prev.p-paginator-element.p-link.p-ripple span.p-paginator-icon:before,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-prev.p-paginator-element.p-link.p-disabled.p-ripple span.p-paginator-icon:before{content:\"\\e91a\"}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator span.p-paginator-pages{margin:0 20px;padding:0;border-radius:18px;overflow:hidden;background-color:#fff;box-shadow:0 0 20px #729fc51a;list-style:none;display:flex}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator span.p-paginator-pages .p-paginator-page{margin:0}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator span.p-paginator-pages .p-paginator-page.p-paginator-element.p-link.p-highlight.p-ripple{width:45px;height:35px;border:0;display:flex;align-items:center;justify-content:center;padding:.4rem .75rem;z-index:1;color:#01254c!important;font-weight:500!important;border-radius:18px;background-color:#1650ed4d}.youxel-table ::ng-deep p-table .ui-sortable-column-icon:before{content:\"\"}.youxel-table ::ng-deep p-table .p-datatable .datatable-body .datatable-scroll .datatable-row-wrapper:last-child{border-radius:0 0 8px 8px}.youxel-table ::ng-deep p-table .ui-sortable-column-icon.fa-sort-desc:before{content:\"newdownicon\"}.youxel-table ::ng-deep p-table .ui-sortable-column-icon.fa-sort-asc:before{content:\"newupicon\"}.youxel-table ::ng-deep p-table .p-datatable .p-datatable-tbody>tr:hover{background-color:#fff}.youxel-table ::ng-deep p-table .p-datatable{background-color:#e4ebf3}.youxel-table ::ng-deep p-table .p-inputswitch.p-inputswitch-checked .p-inputswitch-slider{background:#a5e6ba}.youxel-table ::ng-deep p-table .p-datatable .p-sortable-column .p-sortable-column-icon{margin-left:0!important}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt{display:flex;flex-direction:column}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt:before,.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt:after{font-size:10px;position:relative}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt:before{content:\"\\e907\";top:5px}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt:after{content:\"\\e906\";top:4px}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-up-alt:after,.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-down:after{position:relative;right:6px;top:5px;font-size:10px;background-position:center;background-repeat:no-repeat;background-size:contain}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-up-alt:before,.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-down:before{font-size:10px;background-size:contain;top:-4px;left:4px;position:relative}.youxel-table ::ng-deep p-table p-sorticon.up .pi-sort-amount-up-alt:before{background-image:url(../../../../assets/images/icons/sort-up.png);color:transparent}.youxel-table ::ng-deep p-table p-sorticon.down .pi-sort-amount-up-alt:after{background-image:url(../../../../assets/images/icons/sort-down.png);color:transparent}.youxel-table ::ng-deep p-table p-sorticon.up .pi-sort-amount-down:before{background-image:url(../../../../assets/images/icons/sort-up.png);color:transparent}.youxel-table ::ng-deep p-table p-sorticon.down .pi-sort-amount-down:after{background-image:url(../../../../assets/images/icons/sort-down.png);color:transparent}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-up-alt:before{content:\"\\e907\"}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-up-alt:after{content:\"\\e906\"}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-down:before{content:\"\\e907\"}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-down:after{content:\"\\e906\"}.youxel-table ::ng-deep p-table .p-datatable .p-sortable-column.p-highlight .p-sortable-column-icon{color:#1650ed}.youxel-table ::ng-deep p-table .p-datatable .p-sortable-column:focus{box-shadow:none;outline:none;background:transparent;color:#1650ed}.youxel-table ::ng-deep p-table .p-datatable .p-sortable-column:hover{background:transparent}.youxel-table ::ng-deep p-table .align-icons{display:flex;flex-direction:column;margin-top:-5px}.youxel-table ::ng-deep p-table .align-header-title{display:flex;align-items:center;font-size:14px;font-weight:400;font-stretch:normal;font-style:normal;line-height:1.29;letter-spacing:normal;text-align:left;color:#868894}.font-weight-bold{font-weight:700;margin:0 5px}.pinIcon{width:16px;height:16px;background-image:url(/assets/images/icons/pin.png)}:host-context(body.lang-ar){direction:rtl!important}:host-context(body.lang-ar) ::ng-deep .youxel-table p-table .p-paginator-bottom.p-paginator{direction:rtl!important}:host-context(body.lang-ar) ::ng-deep button.p-paginator-next.p-paginator-element.p-link.p-ripple span.p-paginator-icon:before,:host-context(body.lang-ar) ::ng-deep button.p-paginator-next.p-paginator-element.p-link.p-disabled.p-ripple span.p-paginator-icon:before{content:\"\\e91a\"!important}:host-context(body.lang-ar) ::ng-deep button.p-paginator-prev.p-paginator-element.p-link.p-ripple span.p-paginator-icon:before,:host-context(body.lang-ar) ::ng-deep button.p-paginator-prev.p-paginator-element.p-link.p-disabled.p-ripple span.p-paginator-icon:before{content:\"\\e91b\"!important}\n"] }]
        }], ctorParameters: function () { return [{ type: i1.LanguageService }, { type: YxlTableService }, { type: i1$3.DialogService }, { type: i4$1.Router }, { type: i4$1.ActivatedRoute }]; }, propDecorators: { data: [{
                type: Input
            }], urls: [{
                type: Input
            }], columns: [{
                type: Input
            }], options: [{
                type: Input
            }], actions: [{
                type: Input
            }], id: [{
                type: Input
            }], tableTranslatedItemsFromEndUser: [{
                type: Input
            }], onSelected: [{
                type: Output
            }], onStatusChanged: [{
                type: Output
            }], onItemDeleted: [{
                type: Output
            }], onGetData: [{
                type: Output
            }], onSortData: [{
                type: Output
            }], deleteModal: [{
                type: ViewChild,
                args: ['deleteModal', { static: true }]
            }] } });

class TablesRolesComponent {
    constructor(languageService) {
        this.languageService = languageService;
        this.col = {
            header: '',
            field: '',
        };
        this.rowData = {};
        this.onUserDataChanged = new EventEmitter();
    }
    ngOnInit() { }
    sendUserData() {
        this.onUserDataChanged.emit(this.rowData);
    }
}
TablesRolesComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: TablesRolesComponent, deps: [{ token: i1.LanguageService }], target: i0.ɵɵFactoryTarget.Component });
TablesRolesComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: TablesRolesComponent, selector: "tables-roles-cell", inputs: { col: "col", rowData: "rowData" }, outputs: { onUserDataChanged: "onUserDataChanged" }, ngImport: i0, template: `
    <span class="roles" (click)="sendUserData()">
      <span class="roles-number">
        {{ 'ACCESS_MANAGEMENT.ROLES.SHOW_ROLES' }}
        <span
          *ngIf="!(languageService.currentLanguage() == 'ar')"
          class="p-paginator-icon pi pi-angle-right"
        ></span>
        <span
          *ngIf="languageService.currentLanguage() == 'ar'"
          class="p-paginator-icon pi pi-angle-left"
        ></span>
      </span>
    </span>
  `, isInline: true, styles: [":root{--black: #000000;--primary-darker: #003e71;--gray-700: #4e4d55;--gray-500: #868894;--gray-300: #dcdde5;--red-50: #e5e5e5;--white: #fff;--white-50: #f1f3f4;--white-200: #f5f5f5;--white-500: #dadcdd;--gray-100: #e4ebf3;--primary: #1650ed;--danger: #e03303;--rejected-color: #f16b6b;--pending: #f2ae75;--yellow-600: #d99a28;--warning-light-color: #eecf7e;--yellow-900: #937644;--green: green;--green-700: #85cb9c;--shadow-green: rgba(73, 164, 135, .1);--shadow-light-blue: rgba(228, 233, 241, .2);--shadow-blue: rgba(114, 159, 197, .1);--shadow-black: #0000002b;--green-300: #49a487;--primary-light: #1650ed;--primary-light-gradient: linear-gradient(to bottom, #1650ed 40%, #1650ed 93%);--primary-light-right-gradient: linear-gradient(to right, #1650ed, #1650ed);--primary-gradient: linear-gradient(45deg, #1650ed, #1650ed);--secondary-gradient: linear-gradient(45deg, #937644, #f2ae75);--gradient-white: linear-gradient(to top, #fff, #fff);--box-shadow: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-green: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-10: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-primary-light: 0 -25px 0 0 #1650ed;--box-shadow-black: 3px 7px 25px 0 #0000002b;--box-shadow-light: 0 0 16px 0 rgba(107, 132, 153, .12);--box-shadow-light-blue: 6px 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-blue: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-blue-alpha: 0 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-white: 0 0 3px #ccc;--box-shadow-6: 0 4px 10px 0 rgba(0, 0, 0, .06)}.roles{display:flex;align-items:center}.roles .first-role{margin-right:10px;max-width:55px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.roles .roles-number{width:100px;height:23px;text-align:center!important;display:initial!important;cursor:pointer;font-size:12px;padding:0!important;border-radius:5px;color:#fff;justify-content:flex-start;background-image:linear-gradient(to right,#1650ed,#1650ed);position:relative;font-weight:500}.roles .roles-number .p-paginator-icon{font-size:.8rem;margin:4px 0 0 5px}\n"], directives: [{ type: i1$4.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: TablesRolesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'tables-roles-cell', template: `
    <span class="roles" (click)="sendUserData()">
      <span class="roles-number">
        {{ 'ACCESS_MANAGEMENT.ROLES.SHOW_ROLES' }}
        <span
          *ngIf="!(languageService.currentLanguage() == 'ar')"
          class="p-paginator-icon pi pi-angle-right"
        ></span>
        <span
          *ngIf="languageService.currentLanguage() == 'ar'"
          class="p-paginator-icon pi pi-angle-left"
        ></span>
      </span>
    </span>
  `, styles: [":root{--black: #000000;--primary-darker: #003e71;--gray-700: #4e4d55;--gray-500: #868894;--gray-300: #dcdde5;--red-50: #e5e5e5;--white: #fff;--white-50: #f1f3f4;--white-200: #f5f5f5;--white-500: #dadcdd;--gray-100: #e4ebf3;--primary: #1650ed;--danger: #e03303;--rejected-color: #f16b6b;--pending: #f2ae75;--yellow-600: #d99a28;--warning-light-color: #eecf7e;--yellow-900: #937644;--green: green;--green-700: #85cb9c;--shadow-green: rgba(73, 164, 135, .1);--shadow-light-blue: rgba(228, 233, 241, .2);--shadow-blue: rgba(114, 159, 197, .1);--shadow-black: #0000002b;--green-300: #49a487;--primary-light: #1650ed;--primary-light-gradient: linear-gradient(to bottom, #1650ed 40%, #1650ed 93%);--primary-light-right-gradient: linear-gradient(to right, #1650ed, #1650ed);--primary-gradient: linear-gradient(45deg, #1650ed, #1650ed);--secondary-gradient: linear-gradient(45deg, #937644, #f2ae75);--gradient-white: linear-gradient(to top, #fff, #fff);--box-shadow: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-green: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-10: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-primary-light: 0 -25px 0 0 #1650ed;--box-shadow-black: 3px 7px 25px 0 #0000002b;--box-shadow-light: 0 0 16px 0 rgba(107, 132, 153, .12);--box-shadow-light-blue: 6px 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-blue: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-blue-alpha: 0 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-white: 0 0 3px #ccc;--box-shadow-6: 0 4px 10px 0 rgba(0, 0, 0, .06)}.roles{display:flex;align-items:center}.roles .first-role{margin-right:10px;max-width:55px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.roles .roles-number{width:100px;height:23px;text-align:center!important;display:initial!important;cursor:pointer;font-size:12px;padding:0!important;border-radius:5px;color:#fff;justify-content:flex-start;background-image:linear-gradient(to right,#1650ed,#1650ed);position:relative;font-weight:500}.roles .roles-number .p-paginator-icon{font-size:.8rem;margin:4px 0 0 5px}\n"] }]
        }], ctorParameters: function () { return [{ type: i1.LanguageService }]; }, propDecorators: { col: [{
                type: Input
            }], rowData: [{
                type: Input
            }], onUserDataChanged: [{
                type: Output
            }] } });

class YouxelClientSideTableComponent {
    constructor(languageService, dialogService, service, translateService) {
        this.languageService = languageService;
        this.dialogService = dialogService;
        this.service = service;
        this.translateService = translateService;
        this.data = [];
        this.actions = [];
        this.roles = [];
        this.id = 'id';
        this.primaryKey = 'primaryKey';
        this.onSelected = new EventEmitter();
        this.onItemSelected = new EventEmitter();
        this.onSendUserInfo = new EventEmitter();
        this.onStatusChanged = new EventEmitter();
        this.onItemDeleted = new EventEmitter();
        this.onEditItem = new EventEmitter();
        this.columnDataTypes = ColumnDataTypes;
        this.openActionPopup = false;
        this.expandedRows = {};
        this.sortOrder = '';
        this.item = '';
    }
    ngOnInit() { }
    onSort(event) {
        this.isAscending = event.order === -1;
        this.sortOrder = event.field;
    }
    validateAction(event) {
        return (!event.action.customPermission || event.action.customPermission(event.row));
    }
    validateCustomAction(event) {
        return (!(event.action.isEdit || event.action.isDelete) &&
            this.validateAction({ action: event.action, row: event.row }));
    }
    actionClick(event) {
        this.onItemSelected.emit({ action: event.action, row: event.row });
        return event.action.call ? event.action.call(event.row) : event.callback;
    }
    onRowSelect(event) {
        this.onSelected.emit(this.selectedData);
    }
    onRowUnselect(event) {
        this.onSelected.emit(this.selectedData);
    }
    cellClicked(col, row, callback) {
        if (!col.isClicked) {
            return;
        }
        else {
            return col.action ? col.action(row) : callback;
        }
    }
    editUserRoles(event) {
        this.onSendUserInfo.emit(event);
    }
    handleStatusChange(rowData) {
        if (this.urls && this.urls.changeStatus) {
            this.service
                .changeStatus({
                url: this.urls.changeStatus,
                id: rowData.id,
            })
                .subscribe((res) => {
                this.onStatusChanged.emit(rowData);
            });
        }
        else
            this.onStatusChanged.emit(rowData);
    }
    onImageError(event, col) {
        if (col.loadingError)
            event.target.src = col.loadingError;
    }
    applyAction(event) {
        this.selectedItem = event.row;
        if (event.action.isDelete) {
            this.deleteRow(event.row);
        }
        else if (event.action.isEdit) {
            this.editRow(event.row);
        }
    }
    deleteRow(row) {
        var _a, _b, _c, _d, _e;
        const ref = this.dialogService.open(ModalComponent, {
            data: {
                template: this.deleteModal,
                rowData: row,
                buttons: {
                    cancel: (_b = (_a = this.tableTranslatedItemsFromEndUser) === null || _a === void 0 ? void 0 : _a.modelButtonsText) === null || _b === void 0 ? void 0 : _b.cancel,
                    delete: (_d = (_c = this.tableTranslatedItemsFromEndUser) === null || _c === void 0 ? void 0 : _c.modelButtonsText) === null || _d === void 0 ? void 0 : _d.delete,
                },
            },
            header: (_e = this.tableTranslatedItemsFromEndUser) === null || _e === void 0 ? void 0 : _e.modelHeaderText,
        });
        ref.onClose.subscribe((res) => {
            if (res) {
                this.onItemDeleted.emit(row);
            }
        });
    }
    editRow(row) {
        this.onEditItem.emit(row);
    }
}
YouxelClientSideTableComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: YouxelClientSideTableComponent, deps: [{ token: i1.LanguageService }, { token: i1$3.DialogService }, { token: YxlTableService }, { token: i2.TranslateService }], target: i0.ɵɵFactoryTarget.Component });
YouxelClientSideTableComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: YouxelClientSideTableComponent, selector: "app-youxel-clientSide-table", inputs: { data: "data", columns: "columns", selectedData: "selectedData", options: "options", actions: "actions", roles: "roles", id: "id", primaryKey: "primaryKey", tableTranslatedItemsFromEndUser: "tableTranslatedItemsFromEndUser", urls: "urls" }, outputs: { onSelected: "onSelected", onItemSelected: "onItemSelected", onSendUserInfo: "onSendUserInfo", onStatusChanged: "onStatusChanged", onItemDeleted: "onItemDeleted", onEditItem: "onEditItem" }, viewQueries: [{ propertyName: "deleteModal", first: true, predicate: ["deleteModal"], descendants: true, static: true }], ngImport: i0, template: "<div class=\"youxel-table\" *ngIf=\"data?.length\">\r\n  <p-table\r\n    [value]=\"data\"\r\n    [paginator]=\"options.paginator\"\r\n    [columns]=\"columns\"\r\n    [rows]=\"options.pageSize\"\r\n    [expandedRowKeys]=\"expandedRows\"\r\n    currentPageReportTemplate=\"{{\r\n      tableTranslatedItemsFromEndUser?.paginationTranslationTxt?.showing\r\n    }} {last} {{\r\n      tableTranslatedItemsFromEndUser?.paginationTranslationTxt?.off\r\n    }} {totalRecords}\"\r\n    [showCurrentPageReport]=\"true\"\r\n    [totalRecords]=\"data?.totalCount\"\r\n    (onRowSelect)=\"onRowSelect($event)\"\r\n    (onRowUnselect)=\"onRowUnselect($event)\"\r\n    [ngClass]=\"{ 'sticky-header': options.sticky }\"\r\n    styleClass=\"p-datatable-responsive-demo\"\r\n    [sortMode]=\"options.sortMode\"\r\n    [(selection)]=\"selectedData\"\r\n    selectionMode=\"options.selectionMode\"\r\n    resizableColumns=\"options.resizableColumns\"\r\n    responsiveLayout=\"scroll\"\r\n    [responsive]=\"true\"\r\n    (onSort)=\"onSort($event)\"\r\n    [styleClass]=\"languageService.isEnglish() ? '' : 'rtl'\"\r\n    dataKey=\"row\"\r\n    expandableRows=\"true\"\r\n  >\r\n    <ng-template pTemplate=\"header\" let-columns>\r\n      <tr>\r\n        <th style=\"width: 3rem\" *ngIf=\"options.addCheckBox\">\r\n          <p-tableHeaderCheckbox></p-tableHeaderCheckbox>\r\n        </th>\r\n        <th\r\n          pResizableColumn\r\n          *ngFor=\"let col of columns\"\r\n          [pSortableColumn]=\"col.field\"\r\n          [ngClass]=\"{\r\n            disableSort: col.field == 'thumbnail' || col.field == 'photo'\r\n          }\"\r\n        >\r\n          <div\r\n            class=\"align-header-title\"\r\n            [style]=\"col.customStyles?.headerStyle\"\r\n          >\r\n            {{ col.header }}\r\n            <div class=\"align-icons Image_Data_table\" *ngIf=\"col.hideSort\">\r\n              <p-sortIcon\r\n                [field]=\"col.field\"\r\n                [class.up]=\"isAscending == true\"\r\n                [class.down]=\"isAscending == false\"\r\n              >\r\n              </p-sortIcon>\r\n            </div>\r\n            <div class=\"align-icons\" *ngIf=\"!col.hideSort\">\r\n              <p-sortIcon\r\n                [field]=\"col.field\"\r\n                [class.up]=\"isAscending == true\"\r\n                [class.down]=\"isAscending == false\"\r\n              >\r\n              </p-sortIcon>\r\n            </div>\r\n          </div>\r\n        </th>\r\n        <th class=\"align-header-title\" *ngIf=\"actions\">\r\n          {{ tableTranslatedItemsFromEndUser?.actionColHeader }}\r\n        </th>\r\n      </tr>\r\n    </ng-template>\r\n\r\n    <ng-template\r\n      pTemplate=\"body\"\r\n      let-rowData\r\n      let-columns=\"columns\"\r\n      let-editing=\"editing\"\r\n      let-expanded=\"expanded\"\r\n    >\r\n      <tr [pSelectableRow]=\"rowData\" class=\"rowItem\">\r\n        <td class=\"checkbox-width\" *ngIf=\"options.addCheckBox\">\r\n          <p-tableCheckbox [value]=\"rowData\"></p-tableCheckbox>\r\n        </td>\r\n        <td\r\n          *ngFor=\"let col of columns\"\r\n          [style]=\"col.customStyles?.columnStyle\"\r\n          [ngClass]=\"{ pointer: col.isClicked }\"\r\n          (click)=\"cellClicked(col, rowData)\"\r\n        >\r\n          <table-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.String\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-string-cell>\r\n\r\n          <table-date-cell\r\n            *ngIf=\"col.type === columnDataTypes.Date\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          ></table-date-cell>\r\n\r\n          <table-input-switch-cell\r\n            *ngIf=\"col.type === columnDataTypes.Boolean\"\r\n            [rowData]=\"rowData\"\r\n            [col]=\"col\"\r\n            (statusChangedEmitter)=\"handleStatusChange($event)\"\r\n          ></table-input-switch-cell>\r\n\r\n          <table-image-cell\r\n            *ngIf=\"col.type === columnDataTypes.Image\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (emitError)=\"onImageError($event, col)\"\r\n          ></table-image-cell>\r\n\r\n          <table-image-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.ImageWithString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (emitError)=\"onImageError($event, col)\"\r\n          ></table-image-string-cell>\r\n\r\n          <table-custome-cell\r\n            *ngIf=\"col.type === columnDataTypes.customeCell\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-custome-cell>\r\n\r\n          <tables-roles-cell\r\n            *ngIf=\"col.type === columnDataTypes.Roles\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (onUserDataChanged)=\"editUserRoles($event)\"\r\n          >\r\n          </tables-roles-cell>\r\n\r\n          <table-decrypted-string\r\n            *ngIf=\"col.type === columnDataTypes.DecryptedString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-decrypted-string>\r\n        </td>\r\n\r\n        <td *ngIf=\"actions && actions.length > 0\">\r\n          <actions-cell\r\n            [rowData]=\"rowData\"\r\n            [actions]=\"actions\"\r\n            (onItemSelected)=\"applyAction($event)\"\r\n          ></actions-cell>\r\n        </td>\r\n      </tr>\r\n    </ng-template>\r\n\r\n    <ng-template\r\n      pTemplate=\"rowexpansion\"\r\n      let-rowData\r\n      let-columns=\"columns\"\r\n      let-expanded\r\n    >\r\n      <div class=\"expanded-container\">\r\n        <div class=\"expand-row\" *ngFor=\"let col of columns\">\r\n          <div class=\"expand-header\">{{ col.header }}</div>\r\n\r\n          <table-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.String\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-string-cell>\r\n\r\n          <table-date-cell\r\n            *ngIf=\"col.type === columnDataTypes.Date\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          ></table-date-cell>\r\n\r\n          <table-input-switch-cell\r\n            *ngIf=\"col.type === columnDataTypes.Boolean\"\r\n            [rowData]=\"rowData\"\r\n            [col]=\"col\"\r\n            (statusChangedEmitter)=\"handleStatusChange($event)\"\r\n          ></table-input-switch-cell>\r\n\r\n          <table-image-cell\r\n            *ngIf=\"col.type === columnDataTypes.Image\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (emitError)=\"onImageError($event, col)\"\r\n          ></table-image-cell>\r\n\r\n          <table-image-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.ImageWithString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (emitError)=\"onImageError($event, col)\"\r\n          ></table-image-string-cell>\r\n\r\n          <table-custome-cell\r\n            *ngIf=\"col.type === columnDataTypes.customeCell\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-custome-cell>\r\n\r\n          <tables-roles-cell\r\n            *ngIf=\"col.type === columnDataTypes.Roles\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (onUserDataChanged)=\"editUserRoles($event)\"\r\n          >\r\n          </tables-roles-cell>\r\n\r\n          <table-decrypted-string\r\n            *ngIf=\"col.type === columnDataTypes.DecryptedString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-decrypted-string>\r\n        </div>\r\n      </div>\r\n    </ng-template>\r\n  </p-table>\r\n</div>\r\n\r\n<ng-template #deleteModal>\r\n  <div class=\"confirmation d-flex align-items-center\">\r\n    <div class=\"d-flex align-items-center\">\r\n      {{ tableTranslatedItemsFromEndUser?.modelDeleteActionName }}\r\n      <span class=\"font-weight-bold text-truncate\"\r\n        >\"{{ selectedItem[primaryKey] | strLimit }}\"</span\r\n      >\r\n      <span>{{ tableTranslatedItemsFromEndUser?.confirmationDeleteMsg }}</span>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n", styles: [":root{--black: #000000;--primary-darker: #003e71;--gray-700: #4e4d55;--gray-500: #868894;--gray-300: #dcdde5;--red-50: #e5e5e5;--white: #fff;--white-50: #f1f3f4;--white-200: #f5f5f5;--white-500: #dadcdd;--gray-100: #e4ebf3;--primary: #1650ed;--danger: #e03303;--rejected-color: #f16b6b;--pending: #f2ae75;--yellow-600: #d99a28;--warning-light-color: #eecf7e;--yellow-900: #937644;--green: green;--green-700: #85cb9c;--shadow-green: rgba(73, 164, 135, .1);--shadow-light-blue: rgba(228, 233, 241, .2);--shadow-blue: rgba(114, 159, 197, .1);--shadow-black: #0000002b;--green-300: #49a487;--primary-light: #1650ed;--primary-light-gradient: linear-gradient(to bottom, #1650ed 40%, #1650ed 93%);--primary-light-right-gradient: linear-gradient(to right, #1650ed, #1650ed);--primary-gradient: linear-gradient(45deg, #1650ed, #1650ed);--secondary-gradient: linear-gradient(45deg, #937644, #f2ae75);--gradient-white: linear-gradient(to top, #fff, #fff);--box-shadow: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-green: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-10: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-primary-light: 0 -25px 0 0 #1650ed;--box-shadow-black: 3px 7px 25px 0 #0000002b;--box-shadow-light: 0 0 16px 0 rgba(107, 132, 153, .12);--box-shadow-light-blue: 6px 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-blue: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-blue-alpha: 0 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-white: 0 0 3px #ccc;--box-shadow-6: 0 4px 10px 0 rgba(0, 0, 0, .06)}.youxel-table .sticky-header ::ng-deep .p-datatable .p-datatable-thead>tr>th{position:sticky}.youxel-table .green-color{color:#cd5c5c}.youxel-table .p-button-danger{margin-left:10px;margin-right:10px}.youxel-table .checkbox-width{width:50px}.youxel-table .p-input-icon-left{margin-left:10px}.youxel-table .p-input-icon-left input{height:36px}.youxel-table .expand-header{color:#868894;margin-bottom:10px}.youxel-table .role-button{width:100%;padding:10px;background-image:linear-gradient(to bottom,#1650ed 40%,#1650ed 93%);border:none;height:40px;border-radius:5px}.youxel-table .role-button:hover{background-image:linear-gradient(to bottom,#1650ed 40%,#1650ed 93%);box-shadow:2px 4px 14px #18564a33}.youxel-table .expand-content{margin-bottom:10px}.youxel-table .description-text{width:200px;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;word-break:break-word;white-space:nowrap;text-overflow:ellipsis}.youxel-table .expanded-container{width:max-content;padding:20px}.youxel-table .expanded-container .expaned-description-text{word-wrap:break-word;width:350px}.youxel-table .image-data{width:45px;height:40px}.youxel-table .image-title{display:flex;align-items:center}.youxel-table .image-title .td-data{margin-left:5px}.youxel-table ::ng-deep p-table tr td{cursor:default!important}.youxel-table ::ng-deep p-table tr td.pointer{cursor:pointer!important}.youxel-table ::ng-deep .p-datatable .p-datatable-thead>tr>th{border:none}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator{margin-top:20px;background-color:#e4ebf3;border:none}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator .p-paginator-current{color:#868894;position:absolute;left:0}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-first.p-paginator-element.p-link.p-disabled.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-first.p-paginator-element.p-link.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-last.p-paginator-element.p-link.p-ripple{display:none}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-prev.p-paginator-element.p-link.p-disabled.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-prev.p-paginator-element.p-link.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-next.p-paginator-element.p-link.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-next.p-paginator-element.p-link.p-disabled.p-ripple{color:#cce8ff!important;text-align:center;width:56px!important;border-radius:50px!important;background-color:#fff}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-next.p-paginator-element.p-link.p-ripple span.p-paginator-icon:before,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-next.p-paginator-element.p-link.p-disabled.p-ripple span.p-paginator-icon:before{content:\"\\e91b\"}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-prev.p-paginator-element.p-link.p-ripple span.p-paginator-icon:before,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-prev.p-paginator-element.p-link.p-disabled.p-ripple span.p-paginator-icon:before{content:\"\\e91a\"}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator span.p-paginator-pages{margin:0 20px;padding:0;border-radius:18px;overflow:hidden;background-color:#fff;box-shadow:0 0 20px #729fc51a;list-style:none;display:flex}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator span.p-paginator-pages .p-paginator-page{margin:0}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator span.p-paginator-pages .p-paginator-page.p-paginator-element.p-link.p-highlight.p-ripple{width:45px;height:35px;border:0;display:flex;align-items:center;justify-content:center;padding:.4rem .75rem;z-index:1;color:#01254c!important;font-weight:500!important;border-radius:18px;background-color:#1650ed4d}.youxel-table ::ng-deep p-table .ui-sortable-column-icon:before{content:\"\"}.youxel-table ::ng-deep p-table .p-datatable .datatable-body .datatable-scroll .datatable-row-wrapper:last-child{border-radius:0 0 8px 8px}.youxel-table ::ng-deep p-table .ui-sortable-column-icon.fa-sort-desc:before{content:\"newdownicon\"}.youxel-table ::ng-deep p-table .ui-sortable-column-icon.fa-sort-asc:before{content:\"newupicon\"}@media screen and (min-width: 280px) and (max-width: 550px){.youxel-table ::ng-deep p-table tr th:nth-child(n+4):not(:last-child),.youxel-table ::ng-deep p-table tr td:nth-child(n+4):not(:last-child){display:none}}@media screen and (min-width: 500px) and (max-width: 992px){.youxel-table ::ng-deep .expaned-description-text{width:550px!important}}.youxel-table ::ng-deep p-table .p-datatable .p-datatable-tbody>tr:hover{background-color:#e4ebf3}.youxel-table ::ng-deep p-table .p-datatable{background-color:#e4ebf3}.youxel-table ::ng-deep p-table .p-inputswitch.p-inputswitch-checked .p-inputswitch-slider{background:#a5e6ba}.youxel-table ::ng-deep p-table .p-datatable .p-sortable-column .p-sortable-column-icon{margin-left:0!important}.youxel-table ::ng-deep p-table p-sorticon.up .pi-sort-alt:before{content:\"\\e907\";font-size:10px}.youxel-table ::ng-deep p-table .p-datatable .p-sortable-column.p-highlight .p-sortable-column-icon{color:#1650ed}.youxel-table ::ng-deep p-table .p-datatable .p-sortable-column:focus{box-shadow:none;outline:none;background:transparent;color:#1650ed}.youxel-table ::ng-deep p-table .p-datatable .p-sortable-column:hover{background:transparent}.youxel-table ::ng-deep p-table .align-icons{display:flex;flex-direction:column;margin-top:-5px}.youxel-table ::ng-deep p-table .align-icons .down{margin-top:-10px!important}.youxel-table ::ng-deep p-table .align-header-title{display:flex;align-items:center;font-size:14px;font-weight:400;font-stretch:normal;font-style:normal;line-height:1.29;letter-spacing:normal;text-align:left;color:#868894}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt{display:flex;flex-direction:column}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt:before,.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt:after{font-size:10px;position:relative}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt:before{content:\"\\e907\";top:5px}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt:after{content:\"\\e906\";top:4px}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-up-alt:after,.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-down:after{position:relative;right:6px;top:5px;font-size:10px;background-position:center;background-repeat:no-repeat;background-size:contain}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-up-alt:before,.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-down:before{font-size:10px;background-size:contain;top:-4px;left:4px;position:relative}.youxel-table ::ng-deep p-table p-sorticon.up .pi-sort-amount-up-alt:before{background-image:url(../../../../assets/images/icons/sort-up.png);color:transparent}.youxel-table ::ng-deep p-table p-sorticon.down .pi-sort-amount-up-alt:after{background-image:url(../../../../assets/images/icons/sort-down.png);color:transparent}.youxel-table ::ng-deep p-table p-sorticon.up .pi-sort-amount-down:before{background-image:url(../../../../assets/images/icons/sort-up.png);color:transparent}.youxel-table ::ng-deep p-table p-sorticon.down .pi-sort-amount-down:after{background-image:url(../../../../assets/images/icons/sort-down.png);color:transparent}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-up-alt:before{content:\"\\e907\"}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-up-alt:after{content:\"\\e906\"}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-down:before{content:\"\\e907\"}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-down:after{content:\"\\e906\"}.font-weight-bold{font-weight:700}\n"], components: [{ type: i5.Table, selector: "p-table", inputs: ["frozenColumns", "frozenValue", "style", "styleClass", "tableStyle", "tableStyleClass", "paginator", "pageLinks", "rowsPerPageOptions", "alwaysShowPaginator", "paginatorPosition", "paginatorDropdownAppendTo", "paginatorDropdownScrollHeight", "currentPageReportTemplate", "showCurrentPageReport", "showJumpToPageDropdown", "showJumpToPageInput", "showFirstLastIcon", "showPageLinks", "defaultSortOrder", "sortMode", "resetPageOnSort", "selectionMode", "contextMenuSelection", "contextMenuSelectionMode", "dataKey", "metaKeySelection", "rowTrackBy", "lazy", "lazyLoadOnInit", "compareSelectionBy", "csvSeparator", "exportFilename", "filters", "globalFilterFields", "filterDelay", "filterLocale", "expandedRowKeys", "editingRowKeys", "rowExpandMode", "scrollable", "scrollDirection", "rowGroupMode", "scrollHeight", "virtualScroll", "virtualScrollDelay", "virtualRowHeight", "frozenWidth", "responsive", "contextMenu", "resizableColumns", "columnResizeMode", "reorderableColumns", "loading", "loadingIcon", "showLoader", "rowHover", "customSort", "showInitialSortBadge", "autoLayout", "exportFunction", "stateKey", "stateStorage", "editMode", "groupRowsBy", "groupRowsByOrder", "minBufferPx", "maxBufferPx", "responsiveLayout", "breakpoint", "value", "columns", "first", "rows", "totalRecords", "sortField", "sortOrder", "multiSortMeta", "selection"], outputs: ["selectionChange", "contextMenuSelectionChange", "onRowSelect", "onRowUnselect", "onPage", "onSort", "onFilter", "onLazyLoad", "onRowExpand", "onRowCollapse", "onContextMenuSelect", "onColResize", "onColReorder", "onRowReorder", "onEditInit", "onEditComplete", "onEditCancel", "onHeaderCheckboxToggle", "sortFunction", "firstChange", "rowsChange", "onStateSave", "onStateRestore"] }, { type: i5.TableHeaderCheckbox, selector: "p-tableHeaderCheckbox", inputs: ["disabled", "inputId", "name", "ariaLabel"] }, { type: i5.SortIcon, selector: "p-sortIcon", inputs: ["field"] }, { type: i5.TableCheckbox, selector: "p-tableCheckbox", inputs: ["disabled", "value", "index", "inputId", "name", "required", "ariaLabel"] }, { type: StringCellComponent, selector: "table-string-cell", inputs: ["col", "rowData"] }, { type: DateCellComponent, selector: "table-date-cell", inputs: ["col", "rowData"] }, { type: InputSwitchCellComponent, selector: "table-input-switch-cell", inputs: ["col", "rowData"], outputs: ["statusChangedEmitter"] }, { type: ImageCellComponent, selector: "table-image-cell", inputs: ["col", "rowData", "imageStyle"], outputs: ["emitError"] }, { type: ImageStringCellComponent, selector: "table-image-string-cell", inputs: ["col", "rowData", "imageStyle"], outputs: ["emitError"] }, { type: CustomeCellComponent, selector: "table-custome-cell", inputs: ["col", "rowData"] }, { type: TablesRolesComponent, selector: "tables-roles-cell", inputs: ["col", "rowData"], outputs: ["onUserDataChanged"] }, { type: DecryptedStringComponent, selector: "table-decrypted-string", inputs: ["col", "rowData"] }, { type: ActionsCellComponent, selector: "actions-cell", inputs: ["actions", "rowData"], outputs: ["onItemSelected"] }], directives: [{ type: i1$4.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i1$4.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { type: i3.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { type: i1$4.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { type: i5.ResizableColumn, selector: "[pResizableColumn]", inputs: ["pResizableColumnDisabled"] }, { type: i5.SortableColumn, selector: "[pSortableColumn]", inputs: ["pSortableColumn", "pSortableColumnDisabled"] }, { type: i5.SelectableRow, selector: "[pSelectableRow]", inputs: ["pSelectableRow", "pSelectableRowIndex", "pSelectableRowDisabled"] }], pipes: { "strLimit": i1.StringLimitPipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: YouxelClientSideTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-youxel-clientSide-table', template: "<div class=\"youxel-table\" *ngIf=\"data?.length\">\r\n  <p-table\r\n    [value]=\"data\"\r\n    [paginator]=\"options.paginator\"\r\n    [columns]=\"columns\"\r\n    [rows]=\"options.pageSize\"\r\n    [expandedRowKeys]=\"expandedRows\"\r\n    currentPageReportTemplate=\"{{\r\n      tableTranslatedItemsFromEndUser?.paginationTranslationTxt?.showing\r\n    }} {last} {{\r\n      tableTranslatedItemsFromEndUser?.paginationTranslationTxt?.off\r\n    }} {totalRecords}\"\r\n    [showCurrentPageReport]=\"true\"\r\n    [totalRecords]=\"data?.totalCount\"\r\n    (onRowSelect)=\"onRowSelect($event)\"\r\n    (onRowUnselect)=\"onRowUnselect($event)\"\r\n    [ngClass]=\"{ 'sticky-header': options.sticky }\"\r\n    styleClass=\"p-datatable-responsive-demo\"\r\n    [sortMode]=\"options.sortMode\"\r\n    [(selection)]=\"selectedData\"\r\n    selectionMode=\"options.selectionMode\"\r\n    resizableColumns=\"options.resizableColumns\"\r\n    responsiveLayout=\"scroll\"\r\n    [responsive]=\"true\"\r\n    (onSort)=\"onSort($event)\"\r\n    [styleClass]=\"languageService.isEnglish() ? '' : 'rtl'\"\r\n    dataKey=\"row\"\r\n    expandableRows=\"true\"\r\n  >\r\n    <ng-template pTemplate=\"header\" let-columns>\r\n      <tr>\r\n        <th style=\"width: 3rem\" *ngIf=\"options.addCheckBox\">\r\n          <p-tableHeaderCheckbox></p-tableHeaderCheckbox>\r\n        </th>\r\n        <th\r\n          pResizableColumn\r\n          *ngFor=\"let col of columns\"\r\n          [pSortableColumn]=\"col.field\"\r\n          [ngClass]=\"{\r\n            disableSort: col.field == 'thumbnail' || col.field == 'photo'\r\n          }\"\r\n        >\r\n          <div\r\n            class=\"align-header-title\"\r\n            [style]=\"col.customStyles?.headerStyle\"\r\n          >\r\n            {{ col.header }}\r\n            <div class=\"align-icons Image_Data_table\" *ngIf=\"col.hideSort\">\r\n              <p-sortIcon\r\n                [field]=\"col.field\"\r\n                [class.up]=\"isAscending == true\"\r\n                [class.down]=\"isAscending == false\"\r\n              >\r\n              </p-sortIcon>\r\n            </div>\r\n            <div class=\"align-icons\" *ngIf=\"!col.hideSort\">\r\n              <p-sortIcon\r\n                [field]=\"col.field\"\r\n                [class.up]=\"isAscending == true\"\r\n                [class.down]=\"isAscending == false\"\r\n              >\r\n              </p-sortIcon>\r\n            </div>\r\n          </div>\r\n        </th>\r\n        <th class=\"align-header-title\" *ngIf=\"actions\">\r\n          {{ tableTranslatedItemsFromEndUser?.actionColHeader }}\r\n        </th>\r\n      </tr>\r\n    </ng-template>\r\n\r\n    <ng-template\r\n      pTemplate=\"body\"\r\n      let-rowData\r\n      let-columns=\"columns\"\r\n      let-editing=\"editing\"\r\n      let-expanded=\"expanded\"\r\n    >\r\n      <tr [pSelectableRow]=\"rowData\" class=\"rowItem\">\r\n        <td class=\"checkbox-width\" *ngIf=\"options.addCheckBox\">\r\n          <p-tableCheckbox [value]=\"rowData\"></p-tableCheckbox>\r\n        </td>\r\n        <td\r\n          *ngFor=\"let col of columns\"\r\n          [style]=\"col.customStyles?.columnStyle\"\r\n          [ngClass]=\"{ pointer: col.isClicked }\"\r\n          (click)=\"cellClicked(col, rowData)\"\r\n        >\r\n          <table-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.String\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-string-cell>\r\n\r\n          <table-date-cell\r\n            *ngIf=\"col.type === columnDataTypes.Date\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          ></table-date-cell>\r\n\r\n          <table-input-switch-cell\r\n            *ngIf=\"col.type === columnDataTypes.Boolean\"\r\n            [rowData]=\"rowData\"\r\n            [col]=\"col\"\r\n            (statusChangedEmitter)=\"handleStatusChange($event)\"\r\n          ></table-input-switch-cell>\r\n\r\n          <table-image-cell\r\n            *ngIf=\"col.type === columnDataTypes.Image\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (emitError)=\"onImageError($event, col)\"\r\n          ></table-image-cell>\r\n\r\n          <table-image-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.ImageWithString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (emitError)=\"onImageError($event, col)\"\r\n          ></table-image-string-cell>\r\n\r\n          <table-custome-cell\r\n            *ngIf=\"col.type === columnDataTypes.customeCell\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-custome-cell>\r\n\r\n          <tables-roles-cell\r\n            *ngIf=\"col.type === columnDataTypes.Roles\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (onUserDataChanged)=\"editUserRoles($event)\"\r\n          >\r\n          </tables-roles-cell>\r\n\r\n          <table-decrypted-string\r\n            *ngIf=\"col.type === columnDataTypes.DecryptedString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-decrypted-string>\r\n        </td>\r\n\r\n        <td *ngIf=\"actions && actions.length > 0\">\r\n          <actions-cell\r\n            [rowData]=\"rowData\"\r\n            [actions]=\"actions\"\r\n            (onItemSelected)=\"applyAction($event)\"\r\n          ></actions-cell>\r\n        </td>\r\n      </tr>\r\n    </ng-template>\r\n\r\n    <ng-template\r\n      pTemplate=\"rowexpansion\"\r\n      let-rowData\r\n      let-columns=\"columns\"\r\n      let-expanded\r\n    >\r\n      <div class=\"expanded-container\">\r\n        <div class=\"expand-row\" *ngFor=\"let col of columns\">\r\n          <div class=\"expand-header\">{{ col.header }}</div>\r\n\r\n          <table-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.String\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-string-cell>\r\n\r\n          <table-date-cell\r\n            *ngIf=\"col.type === columnDataTypes.Date\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          ></table-date-cell>\r\n\r\n          <table-input-switch-cell\r\n            *ngIf=\"col.type === columnDataTypes.Boolean\"\r\n            [rowData]=\"rowData\"\r\n            [col]=\"col\"\r\n            (statusChangedEmitter)=\"handleStatusChange($event)\"\r\n          ></table-input-switch-cell>\r\n\r\n          <table-image-cell\r\n            *ngIf=\"col.type === columnDataTypes.Image\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (emitError)=\"onImageError($event, col)\"\r\n          ></table-image-cell>\r\n\r\n          <table-image-string-cell\r\n            *ngIf=\"col.type === columnDataTypes.ImageWithString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (emitError)=\"onImageError($event, col)\"\r\n          ></table-image-string-cell>\r\n\r\n          <table-custome-cell\r\n            *ngIf=\"col.type === columnDataTypes.customeCell\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-custome-cell>\r\n\r\n          <tables-roles-cell\r\n            *ngIf=\"col.type === columnDataTypes.Roles\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n            (onUserDataChanged)=\"editUserRoles($event)\"\r\n          >\r\n          </tables-roles-cell>\r\n\r\n          <table-decrypted-string\r\n            *ngIf=\"col.type === columnDataTypes.DecryptedString\"\r\n            [col]=\"col\"\r\n            [rowData]=\"rowData\"\r\n          >\r\n          </table-decrypted-string>\r\n        </div>\r\n      </div>\r\n    </ng-template>\r\n  </p-table>\r\n</div>\r\n\r\n<ng-template #deleteModal>\r\n  <div class=\"confirmation d-flex align-items-center\">\r\n    <div class=\"d-flex align-items-center\">\r\n      {{ tableTranslatedItemsFromEndUser?.modelDeleteActionName }}\r\n      <span class=\"font-weight-bold text-truncate\"\r\n        >\"{{ selectedItem[primaryKey] | strLimit }}\"</span\r\n      >\r\n      <span>{{ tableTranslatedItemsFromEndUser?.confirmationDeleteMsg }}</span>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n", styles: [":root{--black: #000000;--primary-darker: #003e71;--gray-700: #4e4d55;--gray-500: #868894;--gray-300: #dcdde5;--red-50: #e5e5e5;--white: #fff;--white-50: #f1f3f4;--white-200: #f5f5f5;--white-500: #dadcdd;--gray-100: #e4ebf3;--primary: #1650ed;--danger: #e03303;--rejected-color: #f16b6b;--pending: #f2ae75;--yellow-600: #d99a28;--warning-light-color: #eecf7e;--yellow-900: #937644;--green: green;--green-700: #85cb9c;--shadow-green: rgba(73, 164, 135, .1);--shadow-light-blue: rgba(228, 233, 241, .2);--shadow-blue: rgba(114, 159, 197, .1);--shadow-black: #0000002b;--green-300: #49a487;--primary-light: #1650ed;--primary-light-gradient: linear-gradient(to bottom, #1650ed 40%, #1650ed 93%);--primary-light-right-gradient: linear-gradient(to right, #1650ed, #1650ed);--primary-gradient: linear-gradient(45deg, #1650ed, #1650ed);--secondary-gradient: linear-gradient(45deg, #937644, #f2ae75);--gradient-white: linear-gradient(to top, #fff, #fff);--box-shadow: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-green: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-10: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-primary-light: 0 -25px 0 0 #1650ed;--box-shadow-black: 3px 7px 25px 0 #0000002b;--box-shadow-light: 0 0 16px 0 rgba(107, 132, 153, .12);--box-shadow-light-blue: 6px 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-blue: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-blue-alpha: 0 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-white: 0 0 3px #ccc;--box-shadow-6: 0 4px 10px 0 rgba(0, 0, 0, .06)}.youxel-table .sticky-header ::ng-deep .p-datatable .p-datatable-thead>tr>th{position:sticky}.youxel-table .green-color{color:#cd5c5c}.youxel-table .p-button-danger{margin-left:10px;margin-right:10px}.youxel-table .checkbox-width{width:50px}.youxel-table .p-input-icon-left{margin-left:10px}.youxel-table .p-input-icon-left input{height:36px}.youxel-table .expand-header{color:#868894;margin-bottom:10px}.youxel-table .role-button{width:100%;padding:10px;background-image:linear-gradient(to bottom,#1650ed 40%,#1650ed 93%);border:none;height:40px;border-radius:5px}.youxel-table .role-button:hover{background-image:linear-gradient(to bottom,#1650ed 40%,#1650ed 93%);box-shadow:2px 4px 14px #18564a33}.youxel-table .expand-content{margin-bottom:10px}.youxel-table .description-text{width:200px;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;word-break:break-word;white-space:nowrap;text-overflow:ellipsis}.youxel-table .expanded-container{width:max-content;padding:20px}.youxel-table .expanded-container .expaned-description-text{word-wrap:break-word;width:350px}.youxel-table .image-data{width:45px;height:40px}.youxel-table .image-title{display:flex;align-items:center}.youxel-table .image-title .td-data{margin-left:5px}.youxel-table ::ng-deep p-table tr td{cursor:default!important}.youxel-table ::ng-deep p-table tr td.pointer{cursor:pointer!important}.youxel-table ::ng-deep .p-datatable .p-datatable-thead>tr>th{border:none}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator{margin-top:20px;background-color:#e4ebf3;border:none}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator .p-paginator-current{color:#868894;position:absolute;left:0}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-first.p-paginator-element.p-link.p-disabled.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-first.p-paginator-element.p-link.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-last.p-paginator-element.p-link.p-ripple{display:none}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-prev.p-paginator-element.p-link.p-disabled.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-prev.p-paginator-element.p-link.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-next.p-paginator-element.p-link.p-ripple,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-next.p-paginator-element.p-link.p-disabled.p-ripple{color:#cce8ff!important;text-align:center;width:56px!important;border-radius:50px!important;background-color:#fff}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-next.p-paginator-element.p-link.p-ripple span.p-paginator-icon:before,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-next.p-paginator-element.p-link.p-disabled.p-ripple span.p-paginator-icon:before{content:\"\\e91b\"}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-prev.p-paginator-element.p-link.p-ripple span.p-paginator-icon:before,.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator button.p-paginator-prev.p-paginator-element.p-link.p-disabled.p-ripple span.p-paginator-icon:before{content:\"\\e91a\"}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator span.p-paginator-pages{margin:0 20px;padding:0;border-radius:18px;overflow:hidden;background-color:#fff;box-shadow:0 0 20px #729fc51a;list-style:none;display:flex}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator span.p-paginator-pages .p-paginator-page{margin:0}.youxel-table ::ng-deep p-table .p-paginator-bottom.p-paginator span.p-paginator-pages .p-paginator-page.p-paginator-element.p-link.p-highlight.p-ripple{width:45px;height:35px;border:0;display:flex;align-items:center;justify-content:center;padding:.4rem .75rem;z-index:1;color:#01254c!important;font-weight:500!important;border-radius:18px;background-color:#1650ed4d}.youxel-table ::ng-deep p-table .ui-sortable-column-icon:before{content:\"\"}.youxel-table ::ng-deep p-table .p-datatable .datatable-body .datatable-scroll .datatable-row-wrapper:last-child{border-radius:0 0 8px 8px}.youxel-table ::ng-deep p-table .ui-sortable-column-icon.fa-sort-desc:before{content:\"newdownicon\"}.youxel-table ::ng-deep p-table .ui-sortable-column-icon.fa-sort-asc:before{content:\"newupicon\"}@media screen and (min-width: 280px) and (max-width: 550px){.youxel-table ::ng-deep p-table tr th:nth-child(n+4):not(:last-child),.youxel-table ::ng-deep p-table tr td:nth-child(n+4):not(:last-child){display:none}}@media screen and (min-width: 500px) and (max-width: 992px){.youxel-table ::ng-deep .expaned-description-text{width:550px!important}}.youxel-table ::ng-deep p-table .p-datatable .p-datatable-tbody>tr:hover{background-color:#e4ebf3}.youxel-table ::ng-deep p-table .p-datatable{background-color:#e4ebf3}.youxel-table ::ng-deep p-table .p-inputswitch.p-inputswitch-checked .p-inputswitch-slider{background:#a5e6ba}.youxel-table ::ng-deep p-table .p-datatable .p-sortable-column .p-sortable-column-icon{margin-left:0!important}.youxel-table ::ng-deep p-table p-sorticon.up .pi-sort-alt:before{content:\"\\e907\";font-size:10px}.youxel-table ::ng-deep p-table .p-datatable .p-sortable-column.p-highlight .p-sortable-column-icon{color:#1650ed}.youxel-table ::ng-deep p-table .p-datatable .p-sortable-column:focus{box-shadow:none;outline:none;background:transparent;color:#1650ed}.youxel-table ::ng-deep p-table .p-datatable .p-sortable-column:hover{background:transparent}.youxel-table ::ng-deep p-table .align-icons{display:flex;flex-direction:column;margin-top:-5px}.youxel-table ::ng-deep p-table .align-icons .down{margin-top:-10px!important}.youxel-table ::ng-deep p-table .align-header-title{display:flex;align-items:center;font-size:14px;font-weight:400;font-stretch:normal;font-style:normal;line-height:1.29;letter-spacing:normal;text-align:left;color:#868894}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt{display:flex;flex-direction:column}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt:before,.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt:after{font-size:10px;position:relative}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt:before{content:\"\\e907\";top:5px}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-alt:after{content:\"\\e906\";top:4px}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-up-alt:after,.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-down:after{position:relative;right:6px;top:5px;font-size:10px;background-position:center;background-repeat:no-repeat;background-size:contain}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-up-alt:before,.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-down:before{font-size:10px;background-size:contain;top:-4px;left:4px;position:relative}.youxel-table ::ng-deep p-table p-sorticon.up .pi-sort-amount-up-alt:before{background-image:url(../../../../assets/images/icons/sort-up.png);color:transparent}.youxel-table ::ng-deep p-table p-sorticon.down .pi-sort-amount-up-alt:after{background-image:url(../../../../assets/images/icons/sort-down.png);color:transparent}.youxel-table ::ng-deep p-table p-sorticon.up .pi-sort-amount-down:before{background-image:url(../../../../assets/images/icons/sort-up.png);color:transparent}.youxel-table ::ng-deep p-table p-sorticon.down .pi-sort-amount-down:after{background-image:url(../../../../assets/images/icons/sort-down.png);color:transparent}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-up-alt:before{content:\"\\e907\"}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-up-alt:after{content:\"\\e906\"}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-down:before{content:\"\\e907\"}.youxel-table ::ng-deep p-table p-sorticon .pi-sort-amount-down:after{content:\"\\e906\"}.font-weight-bold{font-weight:700}\n"] }]
        }], ctorParameters: function () { return [{ type: i1.LanguageService }, { type: i1$3.DialogService }, { type: YxlTableService }, { type: i2.TranslateService }]; }, propDecorators: { data: [{
                type: Input
            }], columns: [{
                type: Input
            }], selectedData: [{
                type: Input
            }], options: [{
                type: Input
            }], actions: [{
                type: Input
            }], roles: [{
                type: Input
            }], id: [{
                type: Input
            }], primaryKey: [{
                type: Input
            }], tableTranslatedItemsFromEndUser: [{
                type: Input
            }], urls: [{
                type: Input
            }], onSelected: [{
                type: Output
            }], onItemSelected: [{
                type: Output
            }], onSendUserInfo: [{
                type: Output
            }], onStatusChanged: [{
                type: Output
            }], onItemDeleted: [{
                type: Output
            }], onEditItem: [{
                type: Output
            }], deleteModal: [{
                type: ViewChild,
                args: ['deleteModal', { static: true }]
            }] } });

class DataTableComponent {
    constructor(service) {
        this.service = service;
        this.data = [];
        this.id = 'id';
        /**
         * all needed translation text for table package
         *
         *  the actions col header
         *
         * text for the model header
         *
         * text for the model button
         *
         * text for the model button
         *
         */
        this.tableTranslatedItemsFromEndUser = {};
        this.onSendUserInfo = new EventEmitter();
        this.onStatusChanged = new EventEmitter();
        this.onItemDeleted = new EventEmitter();
        this.onGetData = new EventEmitter();
        this.onSortData = new EventEmitter();
        this.onEditItem = new EventEmitter();
        this.onFilterReseted = new EventEmitter();
        this.tableTranslatedItems = {
            actionColHeader: 'Actions',
            modelHeaderText: 'Delete Confirmation',
            modelButtonsText: {
                cancel: 'Cancel',
                delete: 'Delete',
            },
            paginationTranslationTxt: {
                showing: 'Showing',
                off: 'Off',
            },
            filterKey: {
                resetAll: 'Reset All',
                results: 'Results',
            },
            modelDeleteActionName: 'Delete',
            confirmationDeleteMsg: 'Delete Confirmation',
        };
    }
    ngOnInit() { }
    ngDoCheck() {
        this.toggleResultFilter();
    }
    toggleResultFilter() {
        const searchValueLength = Object.keys(this.service.search$.value).length;
        if (searchValueLength == 0)
            return false;
        else
            return true;
    }
    sendUserData(event) {
        this.onSendUserInfo.emit(event);
    }
    resetFilter() {
        this.service.initTableData();
        this.service.search$.next({});
        this.onFilterReseted.emit();
    }
    onClickEditItem(event) {
        this.onEditItem.emit(event);
    }
    ngOnChanges() {
        this.tableTranslatedItems = Object.assign(Object.assign({}, this.tableTranslatedItems), this.tableTranslatedItemsFromEndUser);
    }
}
DataTableComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: DataTableComponent, deps: [{ token: YxlTableService }], target: i0.ɵɵFactoryTarget.Component });
DataTableComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: DataTableComponent, selector: "app-data-table", inputs: { data: "data", urls: "urls", columns: "columns", options: "options", actions: "actions", id: "id", tableTranslatedItemsFromEndUser: "tableTranslatedItemsFromEndUser" }, outputs: { onSendUserInfo: "onSendUserInfo", onStatusChanged: "onStatusChanged", onItemDeleted: "onItemDeleted", onGetData: "onGetData", onSortData: "onSortData", onEditItem: "onEditItem", onFilterReseted: "onFilterReseted" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"data-table\">\r\n  <div *ngIf=\"!!urls || data?.length\">\r\n    <youxel-programmatic-control\r\n      *ngIf=\"options.showProgrammaticControl\"\r\n      [data]=\"data?.data\"\r\n    >\r\n    </youxel-programmatic-control>\r\n\r\n    <youxel-table-toolbar>\r\n      <div>\r\n        <ng-content select=\"[yxlTable='title']\"></ng-content>\r\n\r\n        <div\r\n          yxlTable=\"filterResult\"\r\n          class=\"filter-list-result mt-5\"\r\n          *ngIf=\"toggleResultFilter()\"\r\n        >\r\n          <span class=\"result-text d-inline-block\">\r\n            {{ service.pageOptions.totalCount }}\r\n            {{ tableTranslatedItems?.filter?.result }}</span\r\n          >\r\n\r\n          <span class=\"reset\" (click)=\"resetFilter()\">{{\r\n            tableTranslatedItems?.filter?.resetAll\r\n          }}</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"d-flex toolbar-content\">\r\n        <ng-content\r\n          *ngIf=\"options.showAddBtn\"\r\n          select=\"[yxlTable='addBtn']\"\r\n        ></ng-content>\r\n        <ng-content\r\n          *ngIf=\"options.filter\"\r\n          select=\"[yxlTable='filterModal']\"\r\n        ></ng-content>\r\n      </div>\r\n    </youxel-table-toolbar>\r\n\r\n    <div>\r\n      <ng-content select=\"[yxlTable='filterResult']\"></ng-content>\r\n    </div>\r\n\r\n    <!-- add switch here from server or client here -->\r\n    <app-youxel-table\r\n      *ngIf=\"options.isServerSide\"\r\n      [columns]=\"columns\"\r\n      [data]=\"data\"\r\n      [urls]=\"urls\"\r\n      [id]=\"id\"\r\n      [options]=\"options\"\r\n      [actions]=\"actions\"\r\n      [tableTranslatedItemsFromEndUser]=\"tableTranslatedItems\"\r\n      (onItemDeleted)=\"onItemDeleted.emit()\"\r\n      (onGetData)=\"onGetData.emit()\"\r\n      (onStatusChanged)=\"onStatusChanged.emit($event)\"\r\n    >\r\n    </app-youxel-table>\r\n\r\n    <app-youxel-clientSide-table\r\n      *ngIf=\"!options.isServerSide\"\r\n      [columns]=\"columns\"\r\n      [urls]=\"urls\"\r\n      [data]=\"data\"\r\n      [id]=\"id\"\r\n      [options]=\"options\"\r\n      [actions]=\"actions\"\r\n      [tableTranslatedItemsFromEndUser]=\"tableTranslatedItems\"\r\n      (onSendUserInfo)=\"sendUserData($event)\"\r\n      (onStatusChanged)=\"onStatusChanged.emit($event)\"\r\n      (onItemDeleted)=\"onItemDeleted.emit($event)\"\r\n      (onEditItem)=\"onClickEditItem($event)\"\r\n    >\r\n    </app-youxel-clientSide-table>\r\n  </div>\r\n  <ng-content\r\n    *ngIf=\"!service.tableData?.length && !data?.length\"\r\n    select=\"[emptyList]\"\r\n  ></ng-content>\r\n</div>\r\n", styles: [":root{--black: #000000;--primary-darker: #003e71;--gray-700: #4e4d55;--gray-500: #868894;--gray-300: #dcdde5;--red-50: #e5e5e5;--white: #fff;--white-50: #f1f3f4;--white-200: #f5f5f5;--white-500: #dadcdd;--gray-100: #e4ebf3;--primary: #1650ed;--danger: #e03303;--rejected-color: #f16b6b;--pending: #f2ae75;--yellow-600: #d99a28;--warning-light-color: #eecf7e;--yellow-900: #937644;--green: green;--green-700: #85cb9c;--shadow-green: rgba(73, 164, 135, .1);--shadow-light-blue: rgba(228, 233, 241, .2);--shadow-blue: rgba(114, 159, 197, .1);--shadow-black: #0000002b;--green-300: #49a487;--primary-light: #1650ed;--primary-light-gradient: linear-gradient(to bottom, #1650ed 40%, #1650ed 93%);--primary-light-right-gradient: linear-gradient(to right, #1650ed, #1650ed);--primary-gradient: linear-gradient(45deg, #1650ed, #1650ed);--secondary-gradient: linear-gradient(45deg, #937644, #f2ae75);--gradient-white: linear-gradient(to top, #fff, #fff);--box-shadow: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-green: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-10: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-primary-light: 0 -25px 0 0 #1650ed;--box-shadow-black: 3px 7px 25px 0 #0000002b;--box-shadow-light: 0 0 16px 0 rgba(107, 132, 153, .12);--box-shadow-light-blue: 6px 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-blue: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-blue-alpha: 0 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-white: 0 0 3px #ccc;--box-shadow-6: 0 4px 10px 0 rgba(0, 0, 0, .06)}.toolbar-content{justify-content:flex-end}::ng-deep .p-dialog .p-dialog-content{padding-bottom:1rem!important}.filter-list-result{display:flex;align-items:center}.filter-list-result .result-text{font-size:18px;font-weight:600;color:#868894;margin-inline-end:1rem}.filter-list-result .reset{border:none;border-radius:5px;color:#937644;font-size:14px;padding:.2rem 1rem;cursor:pointer}::ng-deep .lang-ar .p-inputswitch .p-inputswitch-slider:before{left:initial!important;right:.25rem}::ng-deep .lang-ar .p-inputswitch.p-inputswitch-checked .p-inputswitch-slider:before{right:2.7rem!important}\n"], components: [{ type: ProgrammaticControlComponent, selector: "youxel-programmatic-control", inputs: ["first", "rows", "data"] }, { type: TableToolbarComponent, selector: "youxel-table-toolbar", inputs: ["options"] }, { type: YouxelTableComponent, selector: "app-youxel-table", inputs: ["data", "urls", "columns", "options", "actions", "id", "tableTranslatedItemsFromEndUser"], outputs: ["onSelected", "onStatusChanged", "onItemDeleted", "onGetData", "onSortData"] }, { type: YouxelClientSideTableComponent, selector: "app-youxel-clientSide-table", inputs: ["data", "columns", "selectedData", "options", "actions", "roles", "id", "primaryKey", "tableTranslatedItemsFromEndUser", "urls"], outputs: ["onSelected", "onItemSelected", "onSendUserInfo", "onStatusChanged", "onItemDeleted", "onEditItem"] }], directives: [{ type: i1$4.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: DataTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-data-table', template: "<div class=\"data-table\">\r\n  <div *ngIf=\"!!urls || data?.length\">\r\n    <youxel-programmatic-control\r\n      *ngIf=\"options.showProgrammaticControl\"\r\n      [data]=\"data?.data\"\r\n    >\r\n    </youxel-programmatic-control>\r\n\r\n    <youxel-table-toolbar>\r\n      <div>\r\n        <ng-content select=\"[yxlTable='title']\"></ng-content>\r\n\r\n        <div\r\n          yxlTable=\"filterResult\"\r\n          class=\"filter-list-result mt-5\"\r\n          *ngIf=\"toggleResultFilter()\"\r\n        >\r\n          <span class=\"result-text d-inline-block\">\r\n            {{ service.pageOptions.totalCount }}\r\n            {{ tableTranslatedItems?.filter?.result }}</span\r\n          >\r\n\r\n          <span class=\"reset\" (click)=\"resetFilter()\">{{\r\n            tableTranslatedItems?.filter?.resetAll\r\n          }}</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"d-flex toolbar-content\">\r\n        <ng-content\r\n          *ngIf=\"options.showAddBtn\"\r\n          select=\"[yxlTable='addBtn']\"\r\n        ></ng-content>\r\n        <ng-content\r\n          *ngIf=\"options.filter\"\r\n          select=\"[yxlTable='filterModal']\"\r\n        ></ng-content>\r\n      </div>\r\n    </youxel-table-toolbar>\r\n\r\n    <div>\r\n      <ng-content select=\"[yxlTable='filterResult']\"></ng-content>\r\n    </div>\r\n\r\n    <!-- add switch here from server or client here -->\r\n    <app-youxel-table\r\n      *ngIf=\"options.isServerSide\"\r\n      [columns]=\"columns\"\r\n      [data]=\"data\"\r\n      [urls]=\"urls\"\r\n      [id]=\"id\"\r\n      [options]=\"options\"\r\n      [actions]=\"actions\"\r\n      [tableTranslatedItemsFromEndUser]=\"tableTranslatedItems\"\r\n      (onItemDeleted)=\"onItemDeleted.emit()\"\r\n      (onGetData)=\"onGetData.emit()\"\r\n      (onStatusChanged)=\"onStatusChanged.emit($event)\"\r\n    >\r\n    </app-youxel-table>\r\n\r\n    <app-youxel-clientSide-table\r\n      *ngIf=\"!options.isServerSide\"\r\n      [columns]=\"columns\"\r\n      [urls]=\"urls\"\r\n      [data]=\"data\"\r\n      [id]=\"id\"\r\n      [options]=\"options\"\r\n      [actions]=\"actions\"\r\n      [tableTranslatedItemsFromEndUser]=\"tableTranslatedItems\"\r\n      (onSendUserInfo)=\"sendUserData($event)\"\r\n      (onStatusChanged)=\"onStatusChanged.emit($event)\"\r\n      (onItemDeleted)=\"onItemDeleted.emit($event)\"\r\n      (onEditItem)=\"onClickEditItem($event)\"\r\n    >\r\n    </app-youxel-clientSide-table>\r\n  </div>\r\n  <ng-content\r\n    *ngIf=\"!service.tableData?.length && !data?.length\"\r\n    select=\"[emptyList]\"\r\n  ></ng-content>\r\n</div>\r\n", styles: [":root{--black: #000000;--primary-darker: #003e71;--gray-700: #4e4d55;--gray-500: #868894;--gray-300: #dcdde5;--red-50: #e5e5e5;--white: #fff;--white-50: #f1f3f4;--white-200: #f5f5f5;--white-500: #dadcdd;--gray-100: #e4ebf3;--primary: #1650ed;--danger: #e03303;--rejected-color: #f16b6b;--pending: #f2ae75;--yellow-600: #d99a28;--warning-light-color: #eecf7e;--yellow-900: #937644;--green: green;--green-700: #85cb9c;--shadow-green: rgba(73, 164, 135, .1);--shadow-light-blue: rgba(228, 233, 241, .2);--shadow-blue: rgba(114, 159, 197, .1);--shadow-black: #0000002b;--green-300: #49a487;--primary-light: #1650ed;--primary-light-gradient: linear-gradient(to bottom, #1650ed 40%, #1650ed 93%);--primary-light-right-gradient: linear-gradient(to right, #1650ed, #1650ed);--primary-gradient: linear-gradient(45deg, #1650ed, #1650ed);--secondary-gradient: linear-gradient(45deg, #937644, #f2ae75);--gradient-white: linear-gradient(to top, #fff, #fff);--box-shadow: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-green: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-10: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-primary-light: 0 -25px 0 0 #1650ed;--box-shadow-black: 3px 7px 25px 0 #0000002b;--box-shadow-light: 0 0 16px 0 rgba(107, 132, 153, .12);--box-shadow-light-blue: 6px 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-blue: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-blue-alpha: 0 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-white: 0 0 3px #ccc;--box-shadow-6: 0 4px 10px 0 rgba(0, 0, 0, .06)}.toolbar-content{justify-content:flex-end}::ng-deep .p-dialog .p-dialog-content{padding-bottom:1rem!important}.filter-list-result{display:flex;align-items:center}.filter-list-result .result-text{font-size:18px;font-weight:600;color:#868894;margin-inline-end:1rem}.filter-list-result .reset{border:none;border-radius:5px;color:#937644;font-size:14px;padding:.2rem 1rem;cursor:pointer}::ng-deep .lang-ar .p-inputswitch .p-inputswitch-slider:before{left:initial!important;right:.25rem}::ng-deep .lang-ar .p-inputswitch.p-inputswitch-checked .p-inputswitch-slider:before{right:2.7rem!important}\n"] }]
        }], ctorParameters: function () { return [{ type: YxlTableService }]; }, propDecorators: { data: [{
                type: Input
            }], urls: [{
                type: Input
            }], columns: [{
                type: Input
            }], options: [{
                type: Input
            }], actions: [{
                type: Input
            }], id: [{
                type: Input
            }], tableTranslatedItemsFromEndUser: [{
                type: Input
            }], onSendUserInfo: [{
                type: Output
            }], onStatusChanged: [{
                type: Output
            }], onItemDeleted: [{
                type: Output
            }], onGetData: [{
                type: Output
            }], onSortData: [{
                type: Output
            }], onEditItem: [{
                type: Output
            }], onFilterReseted: [{
                type: Output
            }] } });

class ListFilterComponent {
    constructor(yxlTableService, languageService) {
        this.yxlTableService = yxlTableService;
        this.languageService = languageService;
        this.buttonsText = {
            apply: 'TABLE.FILTER.APPLY',
            close: 'TABLE.FILTER.CLOSE',
        };
        this.closeFilterPopup = new EventEmitter();
        this.filteredData = new EventEmitter();
        this.filterpopup = false;
        this.isActive = false;
    }
    ngOnInit() {
    }
    openFilter() {
        this.filterpopup = true;
    }
    closeFilter() {
        this.filterpopup = this.isActive = false;
        this.formGroup.reset();
        this.closeFilterPopup.emit(this.formGroup);
    }
    sendFilterData() {
        this.filteredData.emit(this.formGroup);
        this.filterpopup = false;
        this.isActive = true;
        this.yxlTableService.search$.next(Object.assign({}, this.formGroup.value));
    }
    hideFilterPopup() {
        this.filterpopup = false;
    }
}
ListFilterComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: ListFilterComponent, deps: [{ token: YxlTableService }, { token: i1.LanguageService }], target: i0.ɵɵFactoryTarget.Component });
ListFilterComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.1", type: ListFilterComponent, selector: "youxel-list-filter", inputs: { formGroup: "formGroup", fields: "fields", model: "model", filterBtnStyle: "filterBtnStyle", buttonsText: "buttonsText", isActive: "isActive" }, outputs: { closeFilterPopup: "closeFilterPopup", filteredData: "filteredData" }, ngImport: i0, template: "<div class=\"filter-popup\" [class.filter-popup-ar]=\"languageService.currentLanguage() == 'ar'\">\r\n  <button class=\"filter\"\r\n    [style.backgroundColor]=\" filterpopup || isActive ? filterBtnStyle?.isOpened : filterBtnStyle?.isClosed\"\r\n    (click)=\"openFilter()\">\r\n    <img class=\"filter-img\" src=\"assets/svg-icon/filter-icon.svg\" alt=\"\" />\r\n  </button>\r\n\r\n  <div class=\"filter-form\" *ngIf=\"filterpopup\">\r\n    <p class=\"filter-title\"> {{'TABLE.TOOLBAR.FILTERS'|translate}} </p>\r\n\r\n    <form [formGroup]=\"formGroup\">\r\n      <div class=\"formlyContainer\">\r\n        <app-form-builder [form]='formGroup' [fields]='fields' [model]='model'></app-form-builder>\r\n      </div>\r\n\r\n      <hr class=\"hr-divider\">\r\n\r\n      <div class=\"action-buttons\">\r\n        <button type=\"button\" class=\"filter-btn primary-gredient\" (click)=\"sendFilterData()\">\r\n          {{ buttonsText.apply }}\r\n        </button>\r\n\r\n        <button type=\"button\" class=\"filter-cancel-btn\" (click)=\"closeFilter()\">\r\n          {{ buttonsText.close }}\r\n        </button>\r\n\r\n      </div>\r\n\r\n    </form>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"overlay\" (click)=\"hideFilterPopup()\" [style.display]=\"filterpopup? 'block' : 'none'\"></div>\r\n", styles: [":root{--black: #000000;--primary-darker: #003e71;--gray-700: #4e4d55;--gray-500: #868894;--gray-300: #dcdde5;--red-50: #e5e5e5;--white: #fff;--white-50: #f1f3f4;--white-200: #f5f5f5;--white-500: #dadcdd;--gray-100: #e4ebf3;--primary: #1650ed;--danger: #e03303;--rejected-color: #f16b6b;--pending: #f2ae75;--yellow-600: #d99a28;--warning-light-color: #eecf7e;--yellow-900: #937644;--green: green;--green-700: #85cb9c;--shadow-green: rgba(73, 164, 135, .1);--shadow-light-blue: rgba(228, 233, 241, .2);--shadow-blue: rgba(114, 159, 197, .1);--shadow-black: #0000002b;--green-300: #49a487;--primary-light: #1650ed;--primary-light-gradient: linear-gradient(to bottom, #1650ed 40%, #1650ed 93%);--primary-light-right-gradient: linear-gradient(to right, #1650ed, #1650ed);--primary-gradient: linear-gradient(45deg, #1650ed, #1650ed);--secondary-gradient: linear-gradient(45deg, #937644, #f2ae75);--gradient-white: linear-gradient(to top, #fff, #fff);--box-shadow: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-green: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-10: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-primary-light: 0 -25px 0 0 #1650ed;--box-shadow-black: 3px 7px 25px 0 #0000002b;--box-shadow-light: 0 0 16px 0 rgba(107, 132, 153, .12);--box-shadow-light-blue: 6px 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-blue: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-blue-alpha: 0 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-white: 0 0 3px #ccc;--box-shadow-6: 0 4px 10px 0 rgba(0, 0, 0, .06)}.overlay{position:fixed;top:0;left:0;width:100%;height:100vh;z-index:20;display:none}.filter-popup{position:relative;display:inline-block;margin-left:10px}.filter-popup .filter{width:42px;height:40px;border-radius:5px}.filter-popup .filter .filter-img{margin-top:5px}.filter-popup .filter-form{position:absolute;top:3rem;right:0;padding:1.5rem;min-width:370px;z-index:25;border-radius:10px;box-shadow:0 6px 15px #0080ff1f;background-color:#fff}.filter-popup .filter-form .filter-title{font-size:24px;font-weight:600;color:#01254c;margin-bottom:1.5rem}.filter-popup .filter-form .form-group .form-control{padding:12px;height:55px;border-radius:5px;border:1px solid #d2d2d2;color:#42404d;font-size:14px;font-weight:700;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;background-color:#fff;width:100%}.filter-popup .filter-form .form-group .form-control:focus{border-color:#1650ed!important;box-shadow:none}.filter-popup.rtl .filter-form{right:auto;left:0}.filter-popup .popup-divider{height:0;margin:2rem 0;overflow:hidden;border-top:1px solid #dadcdd}.filter-popup .filter-btn{font-size:14px;font-weight:500;border:none;color:#fff;margin:.5rem;padding:.5rem .75rem;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;cursor:pointer}.filter-popup .filter-btn.primary-gredient{background-image:linear-gradient(to bottom,#1650ed 40%,#1650ed 93%);box-shadow:2px 4px 14px #18564a33}.filter-popup .filter-cancel-btn{font-size:14px;font-weight:500;background-color:transparent;border:none;color:inherit;margin:.5rem;padding:.5rem;transition:color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;cursor:pointer}.filter-popup:hover{background-color:#18564a33}.filter-popup .hr-divider{height:0;margin:1.5rem 0;overflow:hidden;border-top:1px solid #dadcdd}.filter-popup-ar .filter-form{right:unset!important;left:0px!important}\n"], directives: [{ type: i1$4.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i4.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { type: i4.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { type: i4.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }], pipes: { "translate": i2.TranslatePipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: ListFilterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'youxel-list-filter', template: "<div class=\"filter-popup\" [class.filter-popup-ar]=\"languageService.currentLanguage() == 'ar'\">\r\n  <button class=\"filter\"\r\n    [style.backgroundColor]=\" filterpopup || isActive ? filterBtnStyle?.isOpened : filterBtnStyle?.isClosed\"\r\n    (click)=\"openFilter()\">\r\n    <img class=\"filter-img\" src=\"assets/svg-icon/filter-icon.svg\" alt=\"\" />\r\n  </button>\r\n\r\n  <div class=\"filter-form\" *ngIf=\"filterpopup\">\r\n    <p class=\"filter-title\"> {{'TABLE.TOOLBAR.FILTERS'|translate}} </p>\r\n\r\n    <form [formGroup]=\"formGroup\">\r\n      <div class=\"formlyContainer\">\r\n        <app-form-builder [form]='formGroup' [fields]='fields' [model]='model'></app-form-builder>\r\n      </div>\r\n\r\n      <hr class=\"hr-divider\">\r\n\r\n      <div class=\"action-buttons\">\r\n        <button type=\"button\" class=\"filter-btn primary-gredient\" (click)=\"sendFilterData()\">\r\n          {{ buttonsText.apply }}\r\n        </button>\r\n\r\n        <button type=\"button\" class=\"filter-cancel-btn\" (click)=\"closeFilter()\">\r\n          {{ buttonsText.close }}\r\n        </button>\r\n\r\n      </div>\r\n\r\n    </form>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"overlay\" (click)=\"hideFilterPopup()\" [style.display]=\"filterpopup? 'block' : 'none'\"></div>\r\n", styles: [":root{--black: #000000;--primary-darker: #003e71;--gray-700: #4e4d55;--gray-500: #868894;--gray-300: #dcdde5;--red-50: #e5e5e5;--white: #fff;--white-50: #f1f3f4;--white-200: #f5f5f5;--white-500: #dadcdd;--gray-100: #e4ebf3;--primary: #1650ed;--danger: #e03303;--rejected-color: #f16b6b;--pending: #f2ae75;--yellow-600: #d99a28;--warning-light-color: #eecf7e;--yellow-900: #937644;--green: green;--green-700: #85cb9c;--shadow-green: rgba(73, 164, 135, .1);--shadow-light-blue: rgba(228, 233, 241, .2);--shadow-blue: rgba(114, 159, 197, .1);--shadow-black: #0000002b;--green-300: #49a487;--primary-light: #1650ed;--primary-light-gradient: linear-gradient(to bottom, #1650ed 40%, #1650ed 93%);--primary-light-right-gradient: linear-gradient(to right, #1650ed, #1650ed);--primary-gradient: linear-gradient(45deg, #1650ed, #1650ed);--secondary-gradient: linear-gradient(45deg, #937644, #f2ae75);--gradient-white: linear-gradient(to top, #fff, #fff);--box-shadow: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-green: 2px 4px 14px 0 rgba(24, 86, 74, .2);--box-shadow-10: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-primary-light: 0 -25px 0 0 #1650ed;--box-shadow-black: 3px 7px 25px 0 #0000002b;--box-shadow-light: 0 0 16px 0 rgba(107, 132, 153, .12);--box-shadow-light-blue: 6px 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-blue: 0 0 20px 0 rgba(114, 159, 197, .1);--box-shadow-blue-alpha: 0 6px 15px 0 rgba(0, 128, 255, .12);--box-shadow-white: 0 0 3px #ccc;--box-shadow-6: 0 4px 10px 0 rgba(0, 0, 0, .06)}.overlay{position:fixed;top:0;left:0;width:100%;height:100vh;z-index:20;display:none}.filter-popup{position:relative;display:inline-block;margin-left:10px}.filter-popup .filter{width:42px;height:40px;border-radius:5px}.filter-popup .filter .filter-img{margin-top:5px}.filter-popup .filter-form{position:absolute;top:3rem;right:0;padding:1.5rem;min-width:370px;z-index:25;border-radius:10px;box-shadow:0 6px 15px #0080ff1f;background-color:#fff}.filter-popup .filter-form .filter-title{font-size:24px;font-weight:600;color:#01254c;margin-bottom:1.5rem}.filter-popup .filter-form .form-group .form-control{padding:12px;height:55px;border-radius:5px;border:1px solid #d2d2d2;color:#42404d;font-size:14px;font-weight:700;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;background-color:#fff;width:100%}.filter-popup .filter-form .form-group .form-control:focus{border-color:#1650ed!important;box-shadow:none}.filter-popup.rtl .filter-form{right:auto;left:0}.filter-popup .popup-divider{height:0;margin:2rem 0;overflow:hidden;border-top:1px solid #dadcdd}.filter-popup .filter-btn{font-size:14px;font-weight:500;border:none;color:#fff;margin:.5rem;padding:.5rem .75rem;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;cursor:pointer}.filter-popup .filter-btn.primary-gredient{background-image:linear-gradient(to bottom,#1650ed 40%,#1650ed 93%);box-shadow:2px 4px 14px #18564a33}.filter-popup .filter-cancel-btn{font-size:14px;font-weight:500;background-color:transparent;border:none;color:inherit;margin:.5rem;padding:.5rem;transition:color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;cursor:pointer}.filter-popup:hover{background-color:#18564a33}.filter-popup .hr-divider{height:0;margin:1.5rem 0;overflow:hidden;border-top:1px solid #dadcdd}.filter-popup-ar .filter-form{right:unset!important;left:0px!important}\n"] }]
        }], ctorParameters: function () { return [{ type: YxlTableService }, { type: i1.LanguageService }]; }, propDecorators: { formGroup: [{
                type: Input
            }], fields: [{
                type: Input
            }], model: [{
                type: Input
            }], filterBtnStyle: [{
                type: Input
            }], buttonsText: [{
                type: Input
            }], closeFilterPopup: [{
                type: Output
            }], filteredData: [{
                type: Output
            }], isActive: [{
                type: Input
            }] } });

const MODULES$1 = [
    ToastModule,
    ButtonModule,
    RippleModule,
    TableModule,
    ConfirmDialogModule,
    BreadcrumbModule,
    MessagesModule,
    MessageModule,
    AccordionModule,
    TabViewModule,
    InputTextModule,
    ChartModule,
    CheckboxModule,
    NgApexchartsModule,
    ToolbarModule,
    MenuModule,
    InputSwitchModule,
    OverlayPanelModule,
    RadioButtonModule,
    InputSwitchModule,
    CalendarModule,
    DropdownModule,
    MultiSelectModule,
    AutoCompleteModule,
    MenubarModule,
    AvatarModule,
    AvatarGroupModule,
    NgSelectModule,
    EditorModule,
    SelectButtonModule,
    InputTextareaModule,
    DialogModule,
    DynamicDialogModule,
    DividerModule,
];
const BASEMODULE = [CommonModule];
class SharedModule {
}
SharedModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: SharedModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
SharedModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: SharedModule, imports: [CommonModule, ToastModule,
        ButtonModule,
        RippleModule,
        TableModule,
        ConfirmDialogModule,
        BreadcrumbModule,
        MessagesModule,
        MessageModule,
        AccordionModule,
        TabViewModule,
        InputTextModule,
        ChartModule,
        CheckboxModule,
        NgApexchartsModule,
        ToolbarModule,
        MenuModule,
        InputSwitchModule,
        OverlayPanelModule,
        RadioButtonModule,
        InputSwitchModule,
        CalendarModule,
        DropdownModule,
        MultiSelectModule,
        AutoCompleteModule,
        MenubarModule,
        AvatarModule,
        AvatarGroupModule,
        NgSelectModule,
        EditorModule,
        SelectButtonModule,
        InputTextareaModule,
        DialogModule,
        DynamicDialogModule,
        DividerModule], exports: [ToastModule,
        ButtonModule,
        RippleModule,
        TableModule,
        ConfirmDialogModule,
        BreadcrumbModule,
        MessagesModule,
        MessageModule,
        AccordionModule,
        TabViewModule,
        InputTextModule,
        ChartModule,
        CheckboxModule,
        NgApexchartsModule,
        ToolbarModule,
        MenuModule,
        InputSwitchModule,
        OverlayPanelModule,
        RadioButtonModule,
        InputSwitchModule,
        CalendarModule,
        DropdownModule,
        MultiSelectModule,
        AutoCompleteModule,
        MenubarModule,
        AvatarModule,
        AvatarGroupModule,
        NgSelectModule,
        EditorModule,
        SelectButtonModule,
        InputTextareaModule,
        DialogModule,
        DynamicDialogModule,
        DividerModule] });
SharedModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: SharedModule, imports: [[...BASEMODULE, ...MODULES$1], ToastModule,
        ButtonModule,
        RippleModule,
        TableModule,
        ConfirmDialogModule,
        BreadcrumbModule,
        MessagesModule,
        MessageModule,
        AccordionModule,
        TabViewModule,
        InputTextModule,
        ChartModule,
        CheckboxModule,
        NgApexchartsModule,
        ToolbarModule,
        MenuModule,
        InputSwitchModule,
        OverlayPanelModule,
        RadioButtonModule,
        InputSwitchModule,
        CalendarModule,
        DropdownModule,
        MultiSelectModule,
        AutoCompleteModule,
        MenubarModule,
        AvatarModule,
        AvatarGroupModule,
        NgSelectModule,
        EditorModule,
        SelectButtonModule,
        InputTextareaModule,
        DialogModule,
        DynamicDialogModule,
        DividerModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: SharedModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [...BASEMODULE, ...MODULES$1],
                    exports: [...MODULES$1],
                }]
        }] });

function createTranslateLoader(http) {
    return new TranslateHttpLoader(http, 'assets/i18n/', '.json');
}
const COMPONENTS = [
    RenderStringCellComponent,
    DataTableComponent,
    YouxelClientSideTableComponent,
    YouxelTableComponent,
    ListFilterComponent,
    ProgrammaticControlComponent,
    TableToolbarComponent,
    ModalComponent,
    ImageStringCellComponent,
    ImageCellComponent,
    DateCellComponent,
    StringCellComponent,
    CustomeCellComponent,
    ActionsCellComponent,
    InputSwitchCellComponent,
    ValidateActionDirective,
    TableDateTimeCellComponent,
    DecryptedStringComponent,
    TablesRolesComponent,
];
const BASEMODULES = [
    CommonModule,
    TranslateModule.forRoot({
        loader: {
            provide: TranslateLoader,
            useFactory: createTranslateLoader,
            deps: [HttpClient],
        },
    }),
];
const MODULES = [YouxelCoreModule, TableModule, YouxelFormModule, SharedModule];
class YouxelTableModule {
}
YouxelTableModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: YouxelTableModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
YouxelTableModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: YouxelTableModule, declarations: [RenderStringCellComponent,
        DataTableComponent,
        YouxelClientSideTableComponent,
        YouxelTableComponent,
        ListFilterComponent,
        ProgrammaticControlComponent,
        TableToolbarComponent,
        ModalComponent,
        ImageStringCellComponent,
        ImageCellComponent,
        DateCellComponent,
        StringCellComponent,
        CustomeCellComponent,
        ActionsCellComponent,
        InputSwitchCellComponent,
        ValidateActionDirective,
        TableDateTimeCellComponent,
        DecryptedStringComponent,
        TablesRolesComponent], imports: [YouxelCoreModule, TableModule, YouxelFormModule, SharedModule, CommonModule, i2.TranslateModule], exports: [RenderStringCellComponent,
        DataTableComponent,
        YouxelClientSideTableComponent,
        YouxelTableComponent,
        ListFilterComponent,
        ProgrammaticControlComponent,
        TableToolbarComponent,
        ModalComponent,
        ImageStringCellComponent,
        ImageCellComponent,
        DateCellComponent,
        StringCellComponent,
        CustomeCellComponent,
        ActionsCellComponent,
        InputSwitchCellComponent,
        ValidateActionDirective,
        TableDateTimeCellComponent,
        DecryptedStringComponent,
        TablesRolesComponent] });
YouxelTableModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: YouxelTableModule, imports: [[...MODULES, ...BASEMODULES]] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: YouxelTableModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [...COMPONENTS],
                    imports: [...MODULES, ...BASEMODULES],
                    exports: [...COMPONENTS],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { ActionsCellComponent, ColumnDataTypes, CustomeCellComponent, DataTableComponent, DateCellComponent, DecryptedStringComponent, ERequestTypes, ImageCellComponent, ImageStringCellComponent, InputSwitchCellComponent, ListFilterComponent, ModalComponent, ProgrammaticControlComponent, RenderStringCellComponent, StringCellComponent, TableDateTimeCellComponent, TableSortSelectionModes, TableToolbarComponent, TablesRolesComponent, ValidateActionDirective, YouxelClientSideTableComponent, YouxelTableComponent, YouxelTableModule, YxlTableService, createTranslateLoader };
//# sourceMappingURL=youxel-table.mjs.map
