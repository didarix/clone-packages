export declare const logger: {
    log: (msg: any, ...optionalParams: any[]) => void | boolean;
    clear: () => void;
    debug: (msg: string, ...optionalParams: any[]) => void | boolean;
    info: (msg: string, ...optionalParams: any[]) => void | boolean;
    warning: (msg: string, ...optionalParams: any[]) => void | boolean;
    error: (msg: string, ...optionalParams: any[]) => void | boolean;
    fatal: (msg: string, ...optionalParams: any[]) => void | boolean;
};
