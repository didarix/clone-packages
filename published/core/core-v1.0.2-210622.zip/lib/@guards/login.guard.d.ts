import { CanActivate, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { StorageService } from '../@services';
import * as i0 from "@angular/core";
export declare class LoginGuard implements CanActivate {
    private storage;
    private router;
    constructor(storage: StorageService, router: Router);
    canActivate(): Observable<boolean> | Promise<boolean> | boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoginGuard>;
}
