export declare enum EDycryptionType {
    RSA = "rsa",
    AES = "aes",
    NONE = "none"
}
