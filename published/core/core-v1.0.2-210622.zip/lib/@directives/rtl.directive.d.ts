import { ElementRef, Renderer2 } from '@angular/core';
import { LanguageService } from '../@services/translation/language.service';
import * as i0 from "@angular/core";
export declare class RtlDirective {
    private elRef;
    private renderer;
    private translation;
    constructor(elRef: ElementRef, renderer: Renderer2, translation: LanguageService);
    switchClassBasedOnLanguage(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RtlDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RtlDirective, "[appSetRTL]", never, {}, {}, never>;
}
