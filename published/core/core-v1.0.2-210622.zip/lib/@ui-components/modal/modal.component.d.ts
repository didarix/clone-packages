import { EventEmitter, OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ModalComponent implements OnInit {
    display: boolean;
    resizable: boolean;
    header: string;
    appendTo: string;
    showFooter: boolean;
    btnText: {
        apply: string;
        close: string;
    };
    modalClosed: EventEmitter<any>;
    submitModalData: EventEmitter<any>;
    modalOpen: EventEmitter<any>;
    constructor();
    ngOnInit(): void;
    onOpen(): boolean;
    afterClosedModal(): boolean;
    closeModal(): void;
    confirmModal(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModalComponent, "app-modal", never, { "display": "display"; "resizable": "resizable"; "header": "header"; "appendTo": "appendTo"; "showFooter": "showFooter"; "btnText": "btnText"; }, { "modalClosed": "modalClosed"; "submitModalData": "submitModalData"; "modalOpen": "modalOpen"; }, never, ["*"]>;
}
