import * as i0 from "@angular/core";
export declare class HttpLoaderComponent {
    backdrop: boolean;
    backgroundColor: string;
    debounceDelay: string;
    extraDuration: string;
    minDuration: string;
    opacity: string;
    backdropBackgroundColor: string;
    spinner: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<HttpLoaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HttpLoaderComponent, "app-http-loader", never, { "backdrop": "backdrop"; "backgroundColor": "backgroundColor"; "debounceDelay": "debounceDelay"; "extraDuration": "extraDuration"; "minDuration": "minDuration"; "opacity": "opacity"; "backdropBackgroundColor": "backdropBackgroundColor"; "spinner": "spinner"; }, {}, never, never>;
}
