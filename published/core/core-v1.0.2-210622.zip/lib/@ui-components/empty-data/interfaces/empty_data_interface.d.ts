export interface IEmptyDataOptions {
    title?: string;
    text?: string;
    subText?: string;
    imagePath?: string;
    showButton?: boolean;
    textButton?: string;
    redirectAction?: () => any;
}
