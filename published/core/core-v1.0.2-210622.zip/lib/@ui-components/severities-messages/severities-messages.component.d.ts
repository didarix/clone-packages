import { OnInit } from '@angular/core';
import { Message, MessageService } from 'primeng/api';
import { PrimeNGConfig } from 'primeng/api';
import * as i0 from "@angular/core";
export declare class SeveritiesMessagesComponent implements OnInit {
    private messageService;
    private primengConfig;
    valueMessages: Message[];
    enableServiceBoolean: boolean;
    constructor(messageService: MessageService, primengConfig: PrimeNGConfig);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SeveritiesMessagesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SeveritiesMessagesComponent, "severities-messages", never, { "valueMessages": "valueMessages"; "enableServiceBoolean": "enableServiceBoolean"; }, {}, never, never>;
}
