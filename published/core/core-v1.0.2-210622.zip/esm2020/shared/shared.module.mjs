import { NgModule } from '@angular/core';
import { NgApexchartsModule } from 'ng-apexcharts';
import { MenuModule } from 'primeng/menu';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
// PrimeNG Modules
import { ToastModule } from 'primeng/toast';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
import { TableModule } from 'primeng/table';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ChartModule } from 'primeng/chart';
import { ToolbarModule } from 'primeng/toolbar';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { CheckboxModule } from 'primeng/checkbox';
import { InputSwitchModule } from 'primeng/inputswitch';
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';
import { MultiSelectModule } from 'primeng/multiselect';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MenubarModule } from 'primeng/menubar';
import { AvatarModule } from 'primeng/avatar';
import { AvatarGroupModule } from 'primeng/avatargroup';
import { EditorModule } from 'primeng/editor';
import { SelectButtonModule } from 'primeng/selectbutton';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { DividerModule } from 'primeng/divider';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { DialogModule } from 'primeng/dialog';
// ng module
// PrimeNG Services
import { AccordionModule } from 'primeng/accordion';
import { TabViewModule } from 'primeng/tabview';
import { InputTextModule } from 'primeng/inputtext';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { RadioButtonModule } from 'primeng/radiobutton';
import { NgSelectModule } from '@ng-select/ng-select';
import * as i0 from "@angular/core";
const MODULES = [
    ToastModule,
    ButtonModule,
    RippleModule,
    TableModule,
    ConfirmDialogModule,
    BreadcrumbModule,
    MessagesModule,
    MessageModule,
    AccordionModule,
    TabViewModule,
    InputTextModule,
    ChartModule,
    CheckboxModule,
    NgApexchartsModule,
    ToolbarModule,
    MenuModule,
    InputSwitchModule,
    OverlayPanelModule,
    RadioButtonModule,
    InputSwitchModule,
    CalendarModule,
    DropdownModule,
    MultiSelectModule,
    AutoCompleteModule,
    MenubarModule,
    AvatarModule,
    AvatarGroupModule,
    NgSelectModule,
    EditorModule,
    SelectButtonModule,
    InputTextareaModule,
    DialogModule,
    DynamicDialogModule,
    DividerModule,
];
export class SharedModule {
}
SharedModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: SharedModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
SharedModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: SharedModule, imports: [ToastModule,
        ButtonModule,
        RippleModule,
        TableModule,
        ConfirmDialogModule,
        BreadcrumbModule,
        MessagesModule,
        MessageModule,
        AccordionModule,
        TabViewModule,
        InputTextModule,
        ChartModule,
        CheckboxModule,
        NgApexchartsModule,
        ToolbarModule,
        MenuModule,
        InputSwitchModule,
        OverlayPanelModule,
        RadioButtonModule,
        InputSwitchModule,
        CalendarModule,
        DropdownModule,
        MultiSelectModule,
        AutoCompleteModule,
        MenubarModule,
        AvatarModule,
        AvatarGroupModule,
        NgSelectModule,
        EditorModule,
        SelectButtonModule,
        InputTextareaModule,
        DialogModule,
        DynamicDialogModule,
        DividerModule], exports: [ToastModule,
        ButtonModule,
        RippleModule,
        TableModule,
        ConfirmDialogModule,
        BreadcrumbModule,
        MessagesModule,
        MessageModule,
        AccordionModule,
        TabViewModule,
        InputTextModule,
        ChartModule,
        CheckboxModule,
        NgApexchartsModule,
        ToolbarModule,
        MenuModule,
        InputSwitchModule,
        OverlayPanelModule,
        RadioButtonModule,
        InputSwitchModule,
        CalendarModule,
        DropdownModule,
        MultiSelectModule,
        AutoCompleteModule,
        MenubarModule,
        AvatarModule,
        AvatarGroupModule,
        NgSelectModule,
        EditorModule,
        SelectButtonModule,
        InputTextareaModule,
        DialogModule,
        DynamicDialogModule,
        DividerModule] });
SharedModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: SharedModule, providers: [], imports: [[...MODULES], ToastModule,
        ButtonModule,
        RippleModule,
        TableModule,
        ConfirmDialogModule,
        BreadcrumbModule,
        MessagesModule,
        MessageModule,
        AccordionModule,
        TabViewModule,
        InputTextModule,
        ChartModule,
        CheckboxModule,
        NgApexchartsModule,
        ToolbarModule,
        MenuModule,
        InputSwitchModule,
        OverlayPanelModule,
        RadioButtonModule,
        InputSwitchModule,
        CalendarModule,
        DropdownModule,
        MultiSelectModule,
        AutoCompleteModule,
        MenubarModule,
        AvatarModule,
        AvatarGroupModule,
        NgSelectModule,
        EditorModule,
        SelectButtonModule,
        InputTextareaModule,
        DialogModule,
        DynamicDialogModule,
        DividerModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.1", ngImport: i0, type: SharedModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [...MODULES],
                    providers: [],
                    exports: [...MODULES],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2hhcmVkLm1vZHVsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL2xpYnMvY29yZS9zcmMvc2hhcmVkL3NoYXJlZC5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUN6QyxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDbkQsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGNBQWMsQ0FBQztBQUMxQyxPQUFPLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQUU1RCxrQkFBa0I7QUFDbEIsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUM1QyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDOUMsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQzlDLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDNUMsT0FBTyxFQUFFLG1CQUFtQixFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDNUQsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUM1QyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDaEQsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sc0JBQXNCLENBQUM7QUFDMUQsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLGtCQUFrQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLHFCQUFxQixDQUFDO0FBQ3hELE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQUNsRCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sa0JBQWtCLENBQUM7QUFDbEQsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0scUJBQXFCLENBQUM7QUFDeEQsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sc0JBQXNCLENBQUM7QUFDMUQsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ2hELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUM5QyxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQztBQUN4RCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDOUMsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sc0JBQXNCLENBQUM7QUFDMUQsT0FBTyxFQUFFLG1CQUFtQixFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDNUQsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBRWhELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ3RELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUU5QyxZQUFZO0FBRVosbUJBQW1CO0FBQ25CLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQUNwRCxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDaEQsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBQ3BELE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQUNsRCxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDaEQsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0scUJBQXFCLENBQUM7QUFDeEQsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLHNCQUFzQixDQUFDOztBQUV0RCxNQUFNLE9BQU8sR0FBRztJQUNkLFdBQVc7SUFDWCxZQUFZO0lBQ1osWUFBWTtJQUNaLFdBQVc7SUFDWCxtQkFBbUI7SUFDbkIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxhQUFhO0lBQ2IsZUFBZTtJQUNmLGFBQWE7SUFDYixlQUFlO0lBQ2YsV0FBVztJQUNYLGNBQWM7SUFDZCxrQkFBa0I7SUFDbEIsYUFBYTtJQUNiLFVBQVU7SUFDVixpQkFBaUI7SUFDakIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixpQkFBaUI7SUFDakIsY0FBYztJQUNkLGNBQWM7SUFDZCxpQkFBaUI7SUFDakIsa0JBQWtCO0lBQ2xCLGFBQWE7SUFDYixZQUFZO0lBQ1osaUJBQWlCO0lBQ2pCLGNBQWM7SUFDZCxZQUFZO0lBQ1osa0JBQWtCO0lBQ2xCLG1CQUFtQjtJQUNuQixZQUFZO0lBQ1osbUJBQW1CO0lBQ25CLGFBQWE7Q0FDZCxDQUFDO0FBUUYsTUFBTSxPQUFPLFlBQVk7O3lHQUFaLFlBQVk7MEdBQVosWUFBWSxZQTFDdkIsV0FBVztRQUNYLFlBQVk7UUFDWixZQUFZO1FBQ1osV0FBVztRQUNYLG1CQUFtQjtRQUNuQixnQkFBZ0I7UUFDaEIsY0FBYztRQUNkLGFBQWE7UUFDYixlQUFlO1FBQ2YsYUFBYTtRQUNiLGVBQWU7UUFDZixXQUFXO1FBQ1gsY0FBYztRQUNkLGtCQUFrQjtRQUNsQixhQUFhO1FBQ2IsVUFBVTtRQUNWLGlCQUFpQjtRQUNqQixrQkFBa0I7UUFDbEIsaUJBQWlCO1FBQ2pCLGlCQUFpQjtRQUNqQixjQUFjO1FBQ2QsY0FBYztRQUNkLGlCQUFpQjtRQUNqQixrQkFBa0I7UUFDbEIsYUFBYTtRQUNiLFlBQVk7UUFDWixpQkFBaUI7UUFDakIsY0FBYztRQUNkLFlBQVk7UUFDWixrQkFBa0I7UUFDbEIsbUJBQW1CO1FBQ25CLFlBQVk7UUFDWixtQkFBbUI7UUFDbkIsYUFBYSxhQWpDYixXQUFXO1FBQ1gsWUFBWTtRQUNaLFlBQVk7UUFDWixXQUFXO1FBQ1gsbUJBQW1CO1FBQ25CLGdCQUFnQjtRQUNoQixjQUFjO1FBQ2QsYUFBYTtRQUNiLGVBQWU7UUFDZixhQUFhO1FBQ2IsZUFBZTtRQUNmLFdBQVc7UUFDWCxjQUFjO1FBQ2Qsa0JBQWtCO1FBQ2xCLGFBQWE7UUFDYixVQUFVO1FBQ1YsaUJBQWlCO1FBQ2pCLGtCQUFrQjtRQUNsQixpQkFBaUI7UUFDakIsaUJBQWlCO1FBQ2pCLGNBQWM7UUFDZCxjQUFjO1FBQ2QsaUJBQWlCO1FBQ2pCLGtCQUFrQjtRQUNsQixhQUFhO1FBQ2IsWUFBWTtRQUNaLGlCQUFpQjtRQUNqQixjQUFjO1FBQ2QsWUFBWTtRQUNaLGtCQUFrQjtRQUNsQixtQkFBbUI7UUFDbkIsWUFBWTtRQUNaLG1CQUFtQjtRQUNuQixhQUFhOzBHQVNGLFlBQVksYUFIWixFQUFFLFlBREosQ0FBQyxHQUFHLE9BQU8sQ0FBQyxFQXRDckIsV0FBVztRQUNYLFlBQVk7UUFDWixZQUFZO1FBQ1osV0FBVztRQUNYLG1CQUFtQjtRQUNuQixnQkFBZ0I7UUFDaEIsY0FBYztRQUNkLGFBQWE7UUFDYixlQUFlO1FBQ2YsYUFBYTtRQUNiLGVBQWU7UUFDZixXQUFXO1FBQ1gsY0FBYztRQUNkLGtCQUFrQjtRQUNsQixhQUFhO1FBQ2IsVUFBVTtRQUNWLGlCQUFpQjtRQUNqQixrQkFBa0I7UUFDbEIsaUJBQWlCO1FBQ2pCLGlCQUFpQjtRQUNqQixjQUFjO1FBQ2QsY0FBYztRQUNkLGlCQUFpQjtRQUNqQixrQkFBa0I7UUFDbEIsYUFBYTtRQUNiLFlBQVk7UUFDWixpQkFBaUI7UUFDakIsY0FBYztRQUNkLFlBQVk7UUFDWixrQkFBa0I7UUFDbEIsbUJBQW1CO1FBQ25CLFlBQVk7UUFDWixtQkFBbUI7UUFDbkIsYUFBYTsyRkFTRixZQUFZO2tCQU54QixRQUFRO21CQUFDO29CQUNSLFlBQVksRUFBRSxFQUFFO29CQUNoQixPQUFPLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQztvQkFDckIsU0FBUyxFQUFFLEVBQUU7b0JBQ2IsT0FBTyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUM7aUJBQ3RCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgTmdBcGV4Y2hhcnRzTW9kdWxlIH0gZnJvbSAnbmctYXBleGNoYXJ0cyc7XHJcbmltcG9ydCB7IE1lbnVNb2R1bGUgfSBmcm9tICdwcmltZW5nL21lbnUnO1xyXG5pbXBvcnQgeyBEeW5hbWljRGlhbG9nTW9kdWxlIH0gZnJvbSAncHJpbWVuZy9keW5hbWljZGlhbG9nJztcclxuXHJcbi8vIFByaW1lTkcgTW9kdWxlc1xyXG5pbXBvcnQgeyBUb2FzdE1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvdG9hc3QnO1xyXG5pbXBvcnQgeyBCdXR0b25Nb2R1bGUgfSBmcm9tICdwcmltZW5nL2J1dHRvbic7XHJcbmltcG9ydCB7IFJpcHBsZU1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvcmlwcGxlJztcclxuaW1wb3J0IHsgVGFibGVNb2R1bGUgfSBmcm9tICdwcmltZW5nL3RhYmxlJztcclxuaW1wb3J0IHsgQ29uZmlybURpYWxvZ01vZHVsZSB9IGZyb20gJ3ByaW1lbmcvY29uZmlybWRpYWxvZyc7XHJcbmltcG9ydCB7IENoYXJ0TW9kdWxlIH0gZnJvbSAncHJpbWVuZy9jaGFydCc7XHJcbmltcG9ydCB7IFRvb2xiYXJNb2R1bGUgfSBmcm9tICdwcmltZW5nL3Rvb2xiYXInO1xyXG5pbXBvcnQgeyBPdmVybGF5UGFuZWxNb2R1bGUgfSBmcm9tICdwcmltZW5nL292ZXJsYXlwYW5lbCc7XHJcbmltcG9ydCB7IENoZWNrYm94TW9kdWxlIH0gZnJvbSAncHJpbWVuZy9jaGVja2JveCc7XHJcbmltcG9ydCB7IElucHV0U3dpdGNoTW9kdWxlIH0gZnJvbSAncHJpbWVuZy9pbnB1dHN3aXRjaCc7XHJcbmltcG9ydCB7IENhbGVuZGFyTW9kdWxlIH0gZnJvbSAncHJpbWVuZy9jYWxlbmRhcic7XHJcbmltcG9ydCB7IERyb3Bkb3duTW9kdWxlIH0gZnJvbSAncHJpbWVuZy9kcm9wZG93bic7XHJcbmltcG9ydCB7IE11bHRpU2VsZWN0TW9kdWxlIH0gZnJvbSAncHJpbWVuZy9tdWx0aXNlbGVjdCc7XHJcbmltcG9ydCB7IEF1dG9Db21wbGV0ZU1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvYXV0b2NvbXBsZXRlJztcclxuaW1wb3J0IHsgTWVudWJhck1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvbWVudWJhcic7XHJcbmltcG9ydCB7IEF2YXRhck1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvYXZhdGFyJztcclxuaW1wb3J0IHsgQXZhdGFyR3JvdXBNb2R1bGUgfSBmcm9tICdwcmltZW5nL2F2YXRhcmdyb3VwJztcclxuaW1wb3J0IHsgRWRpdG9yTW9kdWxlIH0gZnJvbSAncHJpbWVuZy9lZGl0b3InO1xyXG5pbXBvcnQgeyBTZWxlY3RCdXR0b25Nb2R1bGUgfSBmcm9tICdwcmltZW5nL3NlbGVjdGJ1dHRvbic7XHJcbmltcG9ydCB7IElucHV0VGV4dGFyZWFNb2R1bGUgfSBmcm9tICdwcmltZW5nL2lucHV0dGV4dGFyZWEnO1xyXG5pbXBvcnQgeyBEaXZpZGVyTW9kdWxlIH0gZnJvbSAncHJpbWVuZy9kaXZpZGVyJztcclxuXHJcbmltcG9ydCB7IEJyZWFkY3J1bWJNb2R1bGUgfSBmcm9tICdwcmltZW5nL2JyZWFkY3J1bWInO1xyXG5pbXBvcnQgeyBEaWFsb2dNb2R1bGUgfSBmcm9tICdwcmltZW5nL2RpYWxvZyc7XHJcblxyXG4vLyBuZyBtb2R1bGVcclxuXHJcbi8vIFByaW1lTkcgU2VydmljZXNcclxuaW1wb3J0IHsgQWNjb3JkaW9uTW9kdWxlIH0gZnJvbSAncHJpbWVuZy9hY2NvcmRpb24nO1xyXG5pbXBvcnQgeyBUYWJWaWV3TW9kdWxlIH0gZnJvbSAncHJpbWVuZy90YWJ2aWV3JztcclxuaW1wb3J0IHsgSW5wdXRUZXh0TW9kdWxlIH0gZnJvbSAncHJpbWVuZy9pbnB1dHRleHQnO1xyXG5pbXBvcnQgeyBNZXNzYWdlc01vZHVsZSB9IGZyb20gJ3ByaW1lbmcvbWVzc2FnZXMnO1xyXG5pbXBvcnQgeyBNZXNzYWdlTW9kdWxlIH0gZnJvbSAncHJpbWVuZy9tZXNzYWdlJztcclxuaW1wb3J0IHsgUmFkaW9CdXR0b25Nb2R1bGUgfSBmcm9tICdwcmltZW5nL3JhZGlvYnV0dG9uJztcclxuaW1wb3J0IHsgTmdTZWxlY3RNb2R1bGUgfSBmcm9tICdAbmctc2VsZWN0L25nLXNlbGVjdCc7XHJcblxyXG5jb25zdCBNT0RVTEVTID0gW1xyXG4gIFRvYXN0TW9kdWxlLFxyXG4gIEJ1dHRvbk1vZHVsZSxcclxuICBSaXBwbGVNb2R1bGUsXHJcbiAgVGFibGVNb2R1bGUsXHJcbiAgQ29uZmlybURpYWxvZ01vZHVsZSxcclxuICBCcmVhZGNydW1iTW9kdWxlLFxyXG4gIE1lc3NhZ2VzTW9kdWxlLFxyXG4gIE1lc3NhZ2VNb2R1bGUsXHJcbiAgQWNjb3JkaW9uTW9kdWxlLFxyXG4gIFRhYlZpZXdNb2R1bGUsXHJcbiAgSW5wdXRUZXh0TW9kdWxlLFxyXG4gIENoYXJ0TW9kdWxlLFxyXG4gIENoZWNrYm94TW9kdWxlLFxyXG4gIE5nQXBleGNoYXJ0c01vZHVsZSxcclxuICBUb29sYmFyTW9kdWxlLFxyXG4gIE1lbnVNb2R1bGUsXHJcbiAgSW5wdXRTd2l0Y2hNb2R1bGUsXHJcbiAgT3ZlcmxheVBhbmVsTW9kdWxlLFxyXG4gIFJhZGlvQnV0dG9uTW9kdWxlLFxyXG4gIElucHV0U3dpdGNoTW9kdWxlLFxyXG4gIENhbGVuZGFyTW9kdWxlLFxyXG4gIERyb3Bkb3duTW9kdWxlLFxyXG4gIE11bHRpU2VsZWN0TW9kdWxlLFxyXG4gIEF1dG9Db21wbGV0ZU1vZHVsZSxcclxuICBNZW51YmFyTW9kdWxlLFxyXG4gIEF2YXRhck1vZHVsZSxcclxuICBBdmF0YXJHcm91cE1vZHVsZSxcclxuICBOZ1NlbGVjdE1vZHVsZSxcclxuICBFZGl0b3JNb2R1bGUsXHJcbiAgU2VsZWN0QnV0dG9uTW9kdWxlLFxyXG4gIElucHV0VGV4dGFyZWFNb2R1bGUsXHJcbiAgRGlhbG9nTW9kdWxlLFxyXG4gIER5bmFtaWNEaWFsb2dNb2R1bGUsXHJcbiAgRGl2aWRlck1vZHVsZSxcclxuXTtcclxuXHJcbkBOZ01vZHVsZSh7XHJcbiAgZGVjbGFyYXRpb25zOiBbXSxcclxuICBpbXBvcnRzOiBbLi4uTU9EVUxFU10sXHJcbiAgcHJvdmlkZXJzOiBbXSxcclxuICBleHBvcnRzOiBbLi4uTU9EVUxFU10sXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBTaGFyZWRNb2R1bGUge31cclxuIl19