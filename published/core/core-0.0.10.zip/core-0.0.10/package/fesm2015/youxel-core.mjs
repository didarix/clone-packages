import * as i1$3 from 'ng-http-loader';
import { Spinkit, NgHttpLoaderModule } from 'ng-http-loader';
import * as i2 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i0 from '@angular/core';
import { Injectable, Inject, Component, Input, EventEmitter, Output, Pipe, Directive, NgModule } from '@angular/core';
import * as i3 from '@angular/common';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i1 from '@angular/common/http';
import { HttpResponse, HttpErrorResponse, HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { DynamicDialogModule, DialogService } from 'primeng/dynamicdialog';
import * as i1$1 from 'primeng/api';
import { MessageService, ConfirmationService } from 'primeng/api';
import { of, BehaviorSubject, ReplaySubject } from 'rxjs';
import * as i1$2 from '@ngx-translate/core';
import * as CryptoJS from 'crypto-js';
import { tap, catchError, finalize } from 'rxjs/operators';
import * as i1$4 from 'primeng/chart';
import { ChartModule } from 'primeng/chart';
import * as i2$1 from 'primeng/message';
import { MessageModule } from 'primeng/message';
import * as i2$2 from 'primeng/messages';
import { MessagesModule } from 'primeng/messages';
import * as i1$5 from 'primeng/breadcrumb';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import * as i1$6 from 'ng-apexcharts';
import { NgApexchartsModule } from 'ng-apexcharts';
import * as i1$7 from 'primeng/confirmdialog';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import * as i1$8 from 'primeng/dialog';
import { DialogModule } from 'primeng/dialog';
import * as i4 from 'primeng/button';
import { ButtonModule } from 'primeng/button';
import { formatDistance } from 'date-fns';
import { arSA, enUS } from 'date-fns/locale';
import { MenuModule } from 'primeng/menu';
import { ToastModule } from 'primeng/toast';
import { RippleModule } from 'primeng/ripple';
import { TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { CheckboxModule } from 'primeng/checkbox';
import { InputSwitchModule } from 'primeng/inputswitch';
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';
import { MultiSelectModule } from 'primeng/multiselect';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MenubarModule } from 'primeng/menubar';
import { AvatarModule } from 'primeng/avatar';
import { AvatarGroupModule } from 'primeng/avatargroup';
import { EditorModule } from 'primeng/editor';
import { SelectButtonModule } from 'primeng/selectbutton';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { DividerModule } from 'primeng/divider';
import { AccordionModule } from 'primeng/accordion';
import { TabViewModule } from 'primeng/tabview';
import { InputTextModule } from 'primeng/inputtext';
import { RadioButtonModule } from 'primeng/radiobutton';
import { NgSelectModule } from '@ng-select/ng-select';

class CoreConfigService {
    constructor(config) {
        this.config = config;
        this.configuration = config;
    }
}
CoreConfigService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: CoreConfigService, deps: [{ token: 'config' }], target: i0.ɵɵFactoryTarget.Injectable });
CoreConfigService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: CoreConfigService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: CoreConfigService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () {
        return [{ type: undefined, decorators: [{
                        type: Inject,
                        args: ['config']
                    }] }];
    } });

// import APIURL from './env-url';
/**
 * Manipulate the HTTP requests for the whole app
 * handle the main POST, GET, UPDATE, DELETE methods
 */
class HttpService {
    constructor(http, coreConfigService) {
        this.http = http;
        this.coreConfigService = coreConfigService;
        this.environemt = this.coreConfigService.configuration.environment;
        this.baseUrl = this.environemt.baseUrl;
    }
    /**
     * @description Base backend URL
     *
     * @readonly
     * @type {string}
     */
    // get URL(): string {
    //   return this.baseUrl;
    // }
    get URL() {
        return this.environemt.baseUrl;
    }
    /**
     * @description Post request using angular httpClient module
     * @param url - the end point url
     * @param data - request payload
     * @param options - to add custom config for request header
     * @return Observable of response, comes from the end point
     */
    post(url, data, options) {
        return this.http.post(this.environemt.baseUrl + url, data, options);
    }
    /**
     * @description Post request using angular httpClient module
     * @param url - the end point url
     * @param data - request payload
     * @return Observable of response, comes from the end point
     */
    postUrl(url, data) {
        return this.http.post(url, data);
    }
    /**
     * @description Get request using angular httpClient module
     * @param url - the end point url
     * @param data - request payload
     * @return Observable of response, comes from the end point
     */
    get(url, data) {
        return this.http.get(this.environemt.baseUrl + url, data);
    }
    /**
     * @description PUT request using angular httpClient module
     * you can bass a parameter (data) in the url separated by '/'
     * @param url - the end point url
     * @param data - request payload
     * @return Observable of response, comes from the end point
     */
    put(url, data, options) {
        return this.http.put(this.environemt.baseUrl + url, data, options);
    }
    /**
     * @description DELETE request using angular httpClient module
     * you can bass a parameter (data) in the url separated by '/'
     * @param url - the end point url
     * @param data - request payload
     * @return Observable of response, comes from the end point
     */
    delete(url, data) {
        return this.http.delete(this.environemt.baseUrl + url + '/' + data);
    }
    deleteWithRequestBody(url, data) {
        return this.http.delete(this.environemt.baseUrl + url, { body: data });
    }
}
HttpService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: HttpService, deps: [{ token: i1.HttpClient }, { token: CoreConfigService }], target: i0.ɵɵFactoryTarget.Injectable });
HttpService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: HttpService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: HttpService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: i1.HttpClient }, { type: CoreConfigService }]; } });

class StorageService {
    constructor() { }
    /**
     * Save items to local storage
     * By key, value pairs
     * @param key the name of property
     * @param value the value we need to store
     */
    setItem(key, value) {
        return of(localStorage.setItem(key, value));
    }
    /**
     * Get the value from local storage for a given property
     * @param key the key of the item we need
     * @returns  the value of the given key
     */
    getItem(key) {
        return of(localStorage.getItem(key));
    }
    /**
     * Get the value from local storage for a given property
     * @param  key the key of the item we need
     * @returns  the value of the given key
     */
    getStringItem(key) {
        return localStorage.getItem(key);
    }
    /**
     * Get the token for the current active user
     * @returns  User Token
     */
    getToken() {
        return localStorage.getItem('secret');
    }
    /**
     * Clear the localStorage and active variables
     */
    clearStorage() {
        location.reload();
        return of(localStorage.clear());
    }
    /**
     *
     * @description Get the current language for the user
     * @returns Current Language
     *
     */
    getLang() {
        var _a;
        return (_a = localStorage.getItem('lang')) !== null && _a !== void 0 ? _a : 'ar';
    }
}
StorageService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: StorageService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
StorageService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: StorageService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: StorageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return []; } });

var EToasterTypes;
(function (EToasterTypes) {
    EToasterTypes["success"] = "Success";
    EToasterTypes["warning"] = "Warning";
    EToasterTypes["error"] = "Error";
})(EToasterTypes || (EToasterTypes = {}));
class ToastService {
    constructor(toaster) {
        this.toaster = toaster;
    }
    /**
     * @description Show toaster with multiple styles
     *
     * @param  {} {message - toaster message
     * @param  {} type - toaster type (success, warning, error)
     * @param  {} duration - the toaster duration
     * @param  {IToasterContent} title - toaster title}
     * @returns void
     */
    show({ message, type, duration, title }) {
        type = type !== null && type !== void 0 ? type : EToasterTypes.success;
        duration = duration !== null && duration !== void 0 ? duration : 5000;
        const types = {
            [EToasterTypes.success]: {
                severity: 'success',
                summary: title !== null && title !== void 0 ? title : EToasterTypes.success,
            },
            [EToasterTypes.error]: {
                severity: 'error',
                summary: title !== null && title !== void 0 ? title : EToasterTypes.error,
            },
            [EToasterTypes.warning]: {
                severity: 'warning',
                summary: title !== null && title !== void 0 ? title : EToasterTypes.warning,
            },
        };
        this.toaster.add(Object.assign({ detail: message, life: duration }, types[type]));
    }
}
ToastService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ToastService, deps: [{ token: i1$1.MessageService }], target: i0.ɵɵFactoryTarget.Injectable });
ToastService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ToastService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ToastService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: i1$1.MessageService }]; } });

var LogLevel;
(function (LogLevel) {
    LogLevel[LogLevel["All"] = 0] = "All";
    LogLevel[LogLevel["Debug"] = 1] = "Debug";
    LogLevel[LogLevel["Info"] = 2] = "Info";
    LogLevel[LogLevel["Warning"] = 3] = "Warning";
    LogLevel[LogLevel["Error"] = 4] = "Error";
    LogLevel[LogLevel["Fatal"] = 5] = "Fatal";
    LogLevel[LogLevel["Off"] = 6] = "Off";
})(LogLevel || (LogLevel = {}));

// ---------------------------------------------------------------------
const logLevel = LogLevel.All;
const logWithDate = true;
/**
   * this method for check if level valid
   * @param level the level of log ( All - Info - Warning - Error - Debug - Fatal )
   * @returns (Boolean)
  **/
const shouldLog = (level) => {
    if (level < 0 || level > 6)
        return false;
    let returnValue = false;
    //level >= this.level
    if ((level >= logLevel && level <= LogLevel.Fatal))
        returnValue = true;
    return returnValue;
}; // End shouldLog
/**
   *
   * @param Message A message that will be log
   * @param level the level of log ( All - Info - Warning - Error - Debug - Fatal )
   * @param logWithDate (boolean) for set date in log or not
   * @param extraInfo for any other messages in the same log
   * @returns (Boolean) Just False if there is no message , level Or invalid level
   * @returns (Object) of values for logger
  **/
const logEntry = (message, level, logWithDate, extraInfo) => {
    const entryDate = new Date();
    let returnVal = {
        Date: '',
        Type: '',
        Message: '',
        extraInfo: new Array()
    };
    if (!message || !shouldLog(level))
        return false;
    if (logWithDate)
        returnVal.Date = `${entryDate.getFullYear()}-${entryDate.getMonth()}-${entryDate.getDate()}  ${entryDate.getHours()}:${entryDate.getMinutes()}:${entryDate.getSeconds()}`;
    returnVal.Type = LogLevel[level];
    returnVal.Message = message;
    if (extraInfo && extraInfo.length)
        returnVal.extraInfo = extraInfo;
    return returnVal;
}; // End buildLogString
/**
  * this method for check if App Run on production enviroment or Development enviroment
  * @returns (Boolean) Depende App is production or not
  **/
const isProductionLogger = () => {
    let logProduction = false;
    // if (environment.production)
    // logProduction = true;
    return logProduction;
};
/**
   * This method for present logg Or send to webApi
   * @param message A message that will be log
   * @param level the level of log ( All - Info - Warning - Error - Debug - Fatal )
   * @param params for any other messages in the same log
   * @returns (Boolean ) False just if no message , level or invalid level
  **/
const writeToLog = (message, level, params) => {
    if (!message || !shouldLog(level)) {
        return false;
    }
    else {
        const entry = logEntry(message, level, logWithDate, params);
        if (isProductionLogger()) {
            // Do some thing foe log API
        }
        else {
            console.log(entry);
        }
    } // End check can log
}; // End writeToLog
/**
 * This Method for Log message with type All
 * @param msg that for message will be log
 * @param optionalParams For any other message
 * @returns (False) Just if there is no message avilibale
**/
const log = (msg, ...optionalParams) => {
    if (!msg)
        return false;
    writeToLog(msg, LogLevel.All, optionalParams);
}; // End Log
/**
   * This Method for Log message with type Debug
   * @param msg that for message will be log
   * @param optionalParams For any other message
   * @returns (False) Just if there is no message avilibale
  **/
const debug = (msg, ...optionalParams) => {
    if (!msg)
        return false;
    writeToLog(msg, LogLevel.Debug, optionalParams);
}; // End debug
/**
 * This Method for Log message with type Info
 * @param msg that for message will be log
 * @param optionalParams For any other message
 * @returns (False) Just if there is no message avilibale
**/
const info = (msg, ...optionalParams) => {
    if (!msg)
        return false;
    writeToLog(msg, LogLevel.Info, optionalParams);
}; // End info
/**
 * This Method for Log message with type Warning
 * @param msg that for message will be log
 * @param optionalParams For any other message
 * @returns (False) Just if there is no message avilibale
**/
const warning = (msg, ...optionalParams) => {
    if (!msg)
        return false;
    writeToLog(msg, LogLevel.Warning, optionalParams);
}; // End warning
/**
 * This Method for Log message with type Error
 * @param msg that for message will be log
 * @param optionalParams For any other message
 * @returns (False) Just if there is no message avilibale
**/
const error = (msg, ...optionalParams) => {
    if (!msg)
        return false;
    writeToLog(msg, LogLevel.Error, optionalParams);
}; // End error
/**
 * This Method for Log message with type Fatal
 * @param msg that for message will be log
 * @param optionalParams For any other message
 * @returns (False) Just if there is no message avilibale
**/
const fatal = (msg, ...optionalParams) => {
    if (!msg)
        return false;
    writeToLog(msg, LogLevel.Fatal, optionalParams);
}; // End fatal
/**
   * This Method for clear all logs form console.log Or form web APi
  **/
const clear = () => {
    if (isProductionLogger()) {
        // Do some thing for API Clear
    }
    else {
        console.clear();
    }
};
const logger = {
    log, clear, debug, info, warning, error, fatal
};

var ELang;
(function (ELang) {
    ELang["EN"] = "en";
    ELang["AR"] = "ar";
})(ELang || (ELang = {}));
var EBodyLangClass;
(function (EBodyLangClass) {
    EBodyLangClass["EN"] = "lang-en";
    EBodyLangClass["AR"] = "lang-ar";
})(EBodyLangClass || (EBodyLangClass = {}));
/**
 * Manipulate the Language for the whole app
 * handle use the default, change, toggle language services
 */
class LanguageService {
    constructor(translate, storage) {
        this.translate = translate;
        this.storage = storage;
    }
    /**
     * Enable the language translation options,
     * Set the language to the current user preferred language
     */
    // enableLanguage(): void {
    //   this.translate.setDefaultLang('en');
    //   this.translate.use(this.currentLanguage());
    // }
    enableLanguage(defaultLang) {
        const checkIfLangSent = defaultLang ? defaultLang : ELang.EN;
        this.translate.setDefaultLang(checkIfLangSent);
        this.translate.use(this.currentLanguage());
    }
    currentLanguage() {
        return this.storage.getLang();
    }
    /**
     * Change the language for the site
     * you can bass a parameter (lang) to the target language
     * @param lang - the target language param
     * @return Returns void
     */
    setLanguage(lang) {
        // the lang to use, if the lang isn't available, it will use the current loader to get them
        this.storage.setItem('lang', lang).subscribe(() => {
            this.translate.use(lang);
        });
    }
    /**
     * Toggle the body element lang class
     */
    toggleBodyLanguageClass() {
        var _a;
        const bodyClass = (_a = document === null || document === void 0 ? void 0 : document.querySelector('body')) === null || _a === void 0 ? void 0 : _a.classList;
        bodyClass === null || bodyClass === void 0 ? void 0 : bodyClass.remove(EBodyLangClass.AR, EBodyLangClass.EN);
        if (this.isEnglish())
            return bodyClass === null || bodyClass === void 0 ? void 0 : bodyClass.add(EBodyLangClass.EN);
        return bodyClass === null || bodyClass === void 0 ? void 0 : bodyClass.add(EBodyLangClass.AR);
    }
    /**
     * Toggle the current language
     */
    toggleLanguage() {
        const toggleLang = this.isEnglish() ? EBodyLangClass.AR : EBodyLangClass.EN;
        this.setLanguage(toggleLang);
        this.setStyle(toggleLang);
        location.reload();
    }
    /**
     * Check the Current Language if english or not
     * @returns True if the current language is english
     */
    isEnglish() {
        return this.currentLanguage() === EBodyLangClass.EN;
    }
    languageChanged() {
        return this.translate.onLangChange;
    }
    /**
     *
     * @description translate at typescript with translation key
     * @param key - the translation key
     * @returns - the translated value
     *
     */
    translateTs(key) {
        return this.translate.instant(key);
    }
    /**
     *
     * @description translate at typescript with translation key
     * @param key - the translation key
     * @returns - the translated value
     *
     */
    stream(key) {
        return this.translate.stream(key);
    }
    setStyle(lang) {
        var _a;
        document.getElementsByTagName('html')[0].setAttribute('lang', lang);
        document.body.setAttribute('dir', lang === ELang.AR ? 'rtl' : 'ltr');
        document.body.classList.remove(EBodyLangClass.EN, EBodyLangClass.AR);
        document.body.classList.add(lang === ELang.EN ? EBodyLangClass.EN : EBodyLangClass.AR);
        (_a = document === null || document === void 0 ? void 0 : document.querySelector('body')) === null || _a === void 0 ? void 0 : _a.setAttribute('style', lang == ELang.AR ? 'text-align:right' : 'text-align:left');
    }
}
LanguageService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: LanguageService, deps: [{ token: i1$2.TranslateService }, { token: StorageService }], target: i0.ɵɵFactoryTarget.Injectable });
LanguageService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: LanguageService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: LanguageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: i1$2.TranslateService }, { type: StorageService }]; } });

// export { AppLazyTranslationModule } from './app.lazy.translation.module';
// export { MyMissingTranslationHandler } from './missing-translation'

class ConfirmService {
    constructor(confirmationService) {
        this.confirmationService = confirmationService;
    }
    confirm(config) {
        return this.confirmationService.confirm(config);
    }
}
ConfirmService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ConfirmService, deps: [{ token: i1$1.ConfirmationService }], target: i0.ɵɵFactoryTarget.Injectable });
ConfirmService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ConfirmService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ConfirmService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: i1$1.ConfirmationService }]; } });

class ServerConfigService {
    constructor(http, coreConfigService) {
        this.http = http;
        this.coreConfigService = coreConfigService;
        this.currentEnvironmentSubject = new BehaviorSubject('');
        this.currentEnvironment = this.currentEnvironmentSubject.asObservable();
        this.packageConfig = this.coreConfigService.configuration;
    }
    init() {
        return new Promise((resolve) => {
            this.http.get(this.packageConfig.envJsonFile).subscribe((data) => {
                // debugger
                this.currentEnvironmentSubject.next(data);
                resolve(true);
            });
        });
    }
}
ServerConfigService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ServerConfigService, deps: [{ token: i1.HttpClient }, { token: CoreConfigService }], target: i0.ɵɵFactoryTarget.Injectable });
ServerConfigService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ServerConfigService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ServerConfigService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: i1.HttpClient }, { type: CoreConfigService }]; } });

class LoaderService {
    constructor() {
        this.isLoading = new BehaviorSubject(false);
    }
    show() {
        this.isLoading.next(true);
    }
    hide() {
        this.isLoading.next(false);
    }
}
LoaderService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: LoaderService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
LoaderService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: LoaderService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: LoaderService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return []; } });

class AesEncrDecrService {
    constructor(coreConfigService) {
        var _a;
        this.coreConfigService = coreConfigService;
        this.CipherOption = {};
        this.configPackageData = this.coreConfigService.configuration.environment;
        const aesKey = (_a = this.configPackageData) === null || _a === void 0 ? void 0 : _a.aesPublicKey;
        this.key = aesKey;
        this.iv = CryptoJS.enc.Utf8.parse(aesKey.substring(0, 16));
        this.CipherOption = {
            // keySize: 256,
            iv: this.iv,
            // mode: CryptoJS.mode.CBC,
            // padding: CryptoJS.pad.Pkcs7
        };
    }
    /**
     * @description `The encrypt method is use for encrypt the value.`
     * @param value {string} to be encrypted
     * @returns encrypted value
     */
    encrypt(value) {
        const message = CryptoJS.enc.Utf8.parse(value.toString());
        var encrypted = CryptoJS.AES.encrypt(message, this.key, this.CipherOption);
        return encrypted.toString();
    }
    /**
     * @description `The decrypt method is use for decrypt the value.`
     * @param value {string} to be decrypted
     * @returns decrypted value
     */
    decrypt(value) {
        if (this.key) {
            var decrypted = CryptoJS.AES.decrypt(value, this.key, this.CipherOption);
            return decrypted.toString(CryptoJS.enc.Utf8);
        }
        else
            throw new Error('you should provide a key to use decryption feature');
    }
}
AesEncrDecrService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: AesEncrDecrService, deps: [{ token: CoreConfigService }], target: i0.ɵɵFactoryTarget.Injectable });
AesEncrDecrService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: AesEncrDecrService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: AesEncrDecrService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: CoreConfigService }]; } });

// import { LanguageService } from './../translation/language.service';
// import { SnackbarService } from '../snackbar/snackbar.service';
/**
 * `ConnectionService` used to check if the used device is connected to the Internet.
 */
class ConnectionService {
    // private snackbarService: SnackbarService
    constructor(toaster) {
        this.toaster = toaster;
        /**
         * A Boolean Observable flag.
         */
        this.connectionMonitor = new BehaviorSubject(navigator.onLine);
        window.addEventListener('offline', (e) => {
            this.connectionMonitor.next(false);
        });
        window.addEventListener('online', (e) => {
            this.connectionMonitor.next(true);
        });
    }
    /**
     * `isConnected()` used for alert if the user connect/disconnect to the Internet.
     * @returns A Boolean Observables
     */
    isConnected() {
        return this.connectionMonitor.asObservable();
    }
    checkConnection() {
        const lang = localStorage.getItem('lang');
        const toaster = () => {
            const message = 'CONNECTION.ONLINE';
            const title = 'TOASTER.SUCCESS';
            this.toaster.show({
                message: message,
                type: EToasterTypes.error,
            });
        };
        if (!navigator.onLine)
            toaster();
    }
}
ConnectionService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ConnectionService, deps: [{ token: ToastService }], target: i0.ɵɵFactoryTarget.Injectable });
ConnectionService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ConnectionService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ConnectionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: ToastService }]; } });

class RequestHeadersService {
    constructor(storage) {
        this.storage = storage;
        this.defaultHeaders();
    }
    get token() {
        return this.storage.getToken();
    }
    get lang() {
        return this.storage.getLang();
    }
    get headers() {
        this._HEADERS.Authorization = `Bearer ${this.token}`;
        this._HEADERS.LanguageCode = this.lang;
        return this._HEADERS;
    }
    set headers(value) {
        var _a;
        const oldHeaders = (_a = this._HEADERS) !== null && _a !== void 0 ? _a : {};
        const newValue = value !== null && value !== void 0 ? value : {};
        this._HEADERS = Object.assign(Object.assign({}, oldHeaders), newValue);
    }
    defaultHeaders() {
        if (!this._HEADERS)
            this.headers = {
                Authorization: `Bearer ${this.token}`,
                LanguageCode: this.lang,
            };
    }
}
RequestHeadersService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: RequestHeadersService, deps: [{ token: StorageService }], target: i0.ɵɵFactoryTarget.Injectable });
RequestHeadersService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: RequestHeadersService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: RequestHeadersService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: StorageService }]; } });

/**
 * Token Interceptor
 * An Interceptor for add auth token to the header of each http
 */
class TokenInterceptor {
    constructor(headers) {
        this.headers = headers;
    }
    intercept(request, next) {
        request = request.clone({ setHeaders: this.headers.headers });
        return next.handle(request);
    }
}
TokenInterceptor.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: TokenInterceptor, deps: [{ token: RequestHeadersService }], target: i0.ɵɵFactoryTarget.Injectable });
TokenInterceptor.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: TokenInterceptor, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: TokenInterceptor, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: RequestHeadersService }]; } });

/**
 * Error Interceptor
 * An Interceptor for handle general errors
 */
class ErrorHandlingInterceptor {
    constructor(toaster, router) {
        this.toaster = toaster;
        this.router = router;
    }
    intercept(request, next) {
        return next.handle(request).pipe(tap((event) => {
            var _a;
            if (event instanceof HttpResponse) {
                if ((_a = event === null || event === void 0 ? void 0 : event.url) === null || _a === void 0 ? void 0 : _a.includes('assets/i18n'))
                    return;
            }
        }, (error) => {
            var _a;
            if (error instanceof HttpErrorResponse) {
                if ((_a = error === null || error === void 0 ? void 0 : error.url) === null || _a === void 0 ? void 0 : _a.includes('assets/i18n'))
                    return;
                if (error.status === 500)
                    this.toaster.show({
                        message: 'Server Error Please Try Again Later',
                        type: EToasterTypes.error,
                    });
                else if (error.status === 0)
                    this.toaster.show({
                        message: 'Connection Error Please Try Again Later',
                        type: EToasterTypes.error,
                    });
                else if (error.status === 401)
                    this.router.navigate(['/401']);
                else
                    this.toaster.show({
                        message: error.error.message ||
                            'Something Went Wrong Please Try Again',
                        type: EToasterTypes.error,
                    });
            }
        }));
    }
}
ErrorHandlingInterceptor.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ErrorHandlingInterceptor, deps: [{ token: ToastService }, { token: i2.Router }], target: i0.ɵɵFactoryTarget.Injectable });
ErrorHandlingInterceptor.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ErrorHandlingInterceptor, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ErrorHandlingInterceptor, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: ToastService }, { type: i2.Router }]; } });

/**
 * Interceptors Wrapper
 * An array to wrap all interceptors using at the app
 */
const INTERCEPTORS = [
    { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true },
    {
        provide: HTTP_INTERCEPTORS,
        useClass: ErrorHandlingInterceptor,
        multi: true,
    },
];

class HttpLoaderComponent {
    constructor() {
        this.backdrop = true;
        this.backgroundColor = '#3f1e6d';
        this.minDuration = '300';
        this.opacity = '0.75';
        this.backdropBackgroundColor = '#fefefe';
        this.spinner = Spinkit.skChasingDots;
    }
}
HttpLoaderComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: HttpLoaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
HttpLoaderComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.3", type: HttpLoaderComponent, selector: "app-http-loader", inputs: { backdrop: "backdrop", backgroundColor: "backgroundColor", debounceDelay: "debounceDelay", extraDuration: "extraDuration", minDuration: "minDuration", opacity: "opacity", backdropBackgroundColor: "backdropBackgroundColor", spinner: "spinner" }, ngImport: i0, template: `
    <ng-http-loader
      [backdrop]="backdrop"
      [backgroundColor]="backgroundColor"
      [debounceDelay]="debounceDelay"
      [extraDuration]="extraDuration"
      [minDuration]="minDuration"
      [opacity]="opacity"
      [backdropBackgroundColor]="backdropBackgroundColor"
      [spinner]="spinner"
    ></ng-http-loader>
  `, isInline: true, components: [{ type: i1$3.NgHttpLoaderComponent, selector: "ng-http-loader", inputs: ["backdrop", "backgroundColor", "debounceDelay", "entryComponent", "extraDuration", "filteredHeaders", "filteredMethods", "filteredUrlPatterns", "minDuration", "opacity", "backdropBackgroundColor", "spinner"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: HttpLoaderComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'app-http-loader',
                    template: `
    <ng-http-loader
      [backdrop]="backdrop"
      [backgroundColor]="backgroundColor"
      [debounceDelay]="debounceDelay"
      [extraDuration]="extraDuration"
      [minDuration]="minDuration"
      [opacity]="opacity"
      [backdropBackgroundColor]="backdropBackgroundColor"
      [spinner]="spinner"
    ></ng-http-loader>
  `,
                }]
        }], propDecorators: { backdrop: [{
                type: Input
            }], backgroundColor: [{
                type: Input
            }], debounceDelay: [{
                type: Input
            }], extraDuration: [{
                type: Input
            }], minDuration: [{
                type: Input
            }], opacity: [{
                type: Input
            }], backdropBackgroundColor: [{
                type: Input
            }], spinner: [{
                type: Input
            }] } });

class ChartComponent {
    constructor() { }
    ngOnInit() { }
}
ChartComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ChartComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
ChartComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.3", type: ChartComponent, selector: "app-chart", inputs: { type: "type", data: "data" }, ngImport: i0, template: `
    <div class="card">
      <p-chart [type]="type" [data]="data"></p-chart>
    </div>
  `, isInline: true, components: [{ type: i1$4.UIChart, selector: "p-chart", inputs: ["type", "plugins", "width", "height", "responsive", "data", "options"], outputs: ["onDataSelect"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ChartComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'app-chart',
                    template: `
    <div class="card">
      <p-chart [type]="type" [data]="data"></p-chart>
    </div>
  `,
                }]
        }], ctorParameters: function () { return []; }, propDecorators: { type: [{
                type: Input
            }], data: [{
                type: Input
            }] } });

class InlineMessagesComponent {
    constructor(messageService, primengConfig) {
        this.messageService = messageService;
        this.primengConfig = primengConfig;
    }
    ngOnInit() {
    }
}
InlineMessagesComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: InlineMessagesComponent, deps: [{ token: i1$1.MessageService }, { token: i1$1.PrimeNGConfig }], target: i0.ɵɵFactoryTarget.Component });
InlineMessagesComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.3", type: InlineMessagesComponent, selector: "inline-messages", inputs: { severity: "severity", message: "message" }, ngImport: i0, template: `<p-message [severity]="severity" [text]="message" styleClass="p-mr-2"></p-message>`, isInline: true, components: [{ type: i2$1.UIMessage, selector: "p-message", inputs: ["severity", "text", "escape", "style", "styleClass"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: InlineMessagesComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'inline-messages',
                    template: `<p-message [severity]="severity" [text]="message" styleClass="p-mr-2"></p-message>`
                }]
        }], ctorParameters: function () { return [{ type: i1$1.MessageService }, { type: i1$1.PrimeNGConfig }]; }, propDecorators: { severity: [{
                type: Input
            }], message: [{
                type: Input
            }] } });

class SeveritiesMessagesComponent {
    constructor(messageService, primengConfig) {
        this.messageService = messageService;
        this.primengConfig = primengConfig;
    }
    ngOnInit() {
    }
}
SeveritiesMessagesComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: SeveritiesMessagesComponent, deps: [{ token: i1$1.MessageService }, { token: i1$1.PrimeNGConfig }], target: i0.ɵɵFactoryTarget.Component });
SeveritiesMessagesComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.3", type: SeveritiesMessagesComponent, selector: "severities-messages", inputs: { valueMessages: "valueMessages", enableServiceBoolean: "enableServiceBoolean" }, ngImport: i0, template: `<p-messages [(value)]="valueMessages" [enableService]="enableServiceBoolean"></p-messages>`, isInline: true, components: [{ type: i2$2.Messages, selector: "p-messages", inputs: ["value", "closable", "style", "styleClass", "enableService", "key", "escape", "severity", "showTransitionOptions", "hideTransitionOptions"], outputs: ["valueChange"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: SeveritiesMessagesComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'severities-messages',
                    template: `<p-messages [(value)]="valueMessages" [enableService]="enableServiceBoolean"></p-messages>`
                }]
        }], ctorParameters: function () { return [{ type: i1$1.MessageService }, { type: i1$1.PrimeNGConfig }]; }, propDecorators: { valueMessages: [{
                type: Input
            }], enableServiceBoolean: [{
                type: Input
            }] } });

class BreadcrumbViaItemsComponent {
    constructor() { }
    ngOnInit() {
        this.items = this.crumbs;
    }
}
BreadcrumbViaItemsComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: BreadcrumbViaItemsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
BreadcrumbViaItemsComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.3", type: BreadcrumbViaItemsComponent, selector: "breadcrumb-via-items", inputs: { crumbs: "crumbs" }, ngImport: i0, template: `<p-breadcrumb [model]="crumbs"></p-breadcrumb>`, isInline: true, components: [{ type: i1$5.Breadcrumb, selector: "p-breadcrumb", inputs: ["model", "style", "styleClass", "home", "homeAriaLabel"], outputs: ["onItemClick"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: BreadcrumbViaItemsComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'breadcrumb-via-items',
                    template: `<p-breadcrumb [model]="crumbs"></p-breadcrumb>`,
                }]
        }], ctorParameters: function () { return []; }, propDecorators: { crumbs: [{
                type: Input
            }] } });

class BreadcrumbService {
    constructor() {
        this.crumbs = new ReplaySubject();
        this.crumbs$ = this.crumbs.asObservable();
    }
    setCrumbs(items) {
        this.crumbs.next((items || []).map(item => Object.assign({}, item, {
            routerLinkActiveOptions: { exact: true }
        })));
    }
}
BreadcrumbService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: BreadcrumbService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
BreadcrumbService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: BreadcrumbService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: BreadcrumbService, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return []; } });

/*
https://kimsereyblog.blogspot.com/2017/08/implement-breadcrumb-in-angular-with.html
*/
class BreadcrumbViaRouteComponent {
    constructor(breadcrumb) {
        this.breadcrumb = breadcrumb;
    }
    ngOnInit() {
        this.crumbs$ = this.breadcrumb.crumbs$;
    }
}
BreadcrumbViaRouteComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: BreadcrumbViaRouteComponent, deps: [{ token: BreadcrumbService }], target: i0.ɵɵFactoryTarget.Component });
BreadcrumbViaRouteComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.3", type: BreadcrumbViaRouteComponent, selector: "breadcrumb-via-route", ngImport: i0, template: `<p-breadcrumb [model]="crumbs$ | async"></p-breadcrumb>`, isInline: true, components: [{ type: i1$5.Breadcrumb, selector: "p-breadcrumb", inputs: ["model", "style", "styleClass", "home", "homeAriaLabel"], outputs: ["onItemClick"] }], pipes: { "async": i3.AsyncPipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: BreadcrumbViaRouteComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'breadcrumb-via-route',
                    template: `<p-breadcrumb [model]="crumbs$ | async"></p-breadcrumb>`
                }]
        }], ctorParameters: function () { return [{ type: BreadcrumbService }]; } });

class ApxChartWrapperComponent {
    constructor() { }
    ngOnInit() {
    }
}
ApxChartWrapperComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ApxChartWrapperComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
ApxChartWrapperComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.3", type: ApxChartWrapperComponent, selector: "app-apx-chart-wrapper", inputs: { chart: "chart", annotations: "annotations", colors: "colors", dataLabels: "dataLabels", series: "series", stroke: "stroke", labels: "labels", legend: "legend", fill: "fill", tooltip: "tooltip", plotOptions: "plotOptions", responsive: "responsive", xaxis: "xaxis", yaxis: "yaxis", grid: "grid", states: "states", title: "title", subtitle: "subtitle", theme: "theme" }, ngImport: i0, template: `<apx-chart [series]="series" [plotOptions]="plotOptions" [colors]="colors" [chart]="chart" [title]="title">
</apx-chart>
`, isInline: true, components: [{ type: i1$6.ChartComponent, selector: "apx-chart", inputs: ["chart", "annotations", "colors", "dataLabels", "series", "stroke", "labels", "legend", "markers", "noData", "fill", "tooltip", "plotOptions", "responsive", "xaxis", "yaxis", "grid", "states", "title", "subtitle", "theme", "autoUpdateSeries"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ApxChartWrapperComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'app-apx-chart-wrapper',
                    template: `<apx-chart [series]="series" [plotOptions]="plotOptions" [colors]="colors" [chart]="chart" [title]="title">
</apx-chart>
`
                }]
        }], ctorParameters: function () { return []; }, propDecorators: { chart: [{
                type: Input
            }], annotations: [{
                type: Input
            }], colors: [{
                type: Input
            }], dataLabels: [{
                type: Input
            }], series: [{
                type: Input
            }], stroke: [{
                type: Input
            }], labels: [{
                type: Input
            }], legend: [{
                type: Input
            }], fill: [{
                type: Input
            }], tooltip: [{
                type: Input
            }], plotOptions: [{
                type: Input
            }], responsive: [{
                type: Input
            }], xaxis: [{
                type: Input
            }], yaxis: [{
                type: Input
            }], grid: [{
                type: Input
            }], states: [{
                type: Input
            }], title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], theme: [{
                type: Input
            }] } });

class EmptyDataComponent {
    constructor(router, route) {
        this.router = router;
        this.route = route;
    }
    ngOnInit() { }
    redirectAction() {
        const hasAction = this.options.redirectAction;
        if (hasAction)
            return this.options.redirectAction();
        this.router.navigate(['add'], { relativeTo: this.route.parent });
    }
}
EmptyDataComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: EmptyDataComponent, deps: [{ token: i2.Router }, { token: i2.ActivatedRoute }], target: i0.ɵɵFactoryTarget.Component });
EmptyDataComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.3", type: EmptyDataComponent, selector: "app-empty-data", inputs: { options: "options" }, ngImport: i0, template: "<div emptyList class=\"empty-service\">\r\n  <p class=\"title\">\r\n    {{ options?.title }}\r\n  </p>\r\n  <div class=\"content\">\r\n    <p class=\"text mt-5\">\r\n      {{ options?.text }}\r\n    </p>\r\n    <p>\r\n      {{ options?.subText }}\r\n    </p>\r\n\r\n    <img [src]=\"options?.imagePath\" />\r\n    <div\r\n      class=\"add-news-btn\"\r\n      *ngIf=\"options?.showButton\"\r\n      (click)=\"redirectAction()\"\r\n    >\r\n      {{ options?.textButton }}\r\n    </div>\r\n  </div>\r\n</div>\r\n", styles: ["div.empty-service p.title,div.empty-service p.text{font-size:1.8rem;font-weight:600;color:#868894}div.empty-service .add-news-btn{padding:9px 16px 9px 9px;border-radius:5px;border:none;display:flex;font-size:1.4rem;font-weight:500;align-items:center;justify-content:center;text-decoration:none;box-shadow:2px 4px 14px #18564a33;background-image:linear-gradient(to top,#d64f70,#9c2b80);color:#fff;cursor:pointer}div.empty-service div.content{text-align:center;position:absolute;left:53%;top:60%;transform:translate(-50%,-50%)}div.empty-service div.content p.subText{color:#c5bdbd;font-weight:bolder;z-index:10}div.empty-service div.content img{position:fixed;width:120%;left:0%;top:-19%;z-index:-10}\n"], directives: [{ type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: EmptyDataComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-empty-data', template: "<div emptyList class=\"empty-service\">\r\n  <p class=\"title\">\r\n    {{ options?.title }}\r\n  </p>\r\n  <div class=\"content\">\r\n    <p class=\"text mt-5\">\r\n      {{ options?.text }}\r\n    </p>\r\n    <p>\r\n      {{ options?.subText }}\r\n    </p>\r\n\r\n    <img [src]=\"options?.imagePath\" />\r\n    <div\r\n      class=\"add-news-btn\"\r\n      *ngIf=\"options?.showButton\"\r\n      (click)=\"redirectAction()\"\r\n    >\r\n      {{ options?.textButton }}\r\n    </div>\r\n  </div>\r\n</div>\r\n", styles: ["div.empty-service p.title,div.empty-service p.text{font-size:1.8rem;font-weight:600;color:#868894}div.empty-service .add-news-btn{padding:9px 16px 9px 9px;border-radius:5px;border:none;display:flex;font-size:1.4rem;font-weight:500;align-items:center;justify-content:center;text-decoration:none;box-shadow:2px 4px 14px #18564a33;background-image:linear-gradient(to top,#d64f70,#9c2b80);color:#fff;cursor:pointer}div.empty-service div.content{text-align:center;position:absolute;left:53%;top:60%;transform:translate(-50%,-50%)}div.empty-service div.content p.subText{color:#c5bdbd;font-weight:bolder;z-index:10}div.empty-service div.content img{position:fixed;width:120%;left:0%;top:-19%;z-index:-10}\n"] }]
        }], ctorParameters: function () { return [{ type: i2.Router }, { type: i2.ActivatedRoute }]; }, propDecorators: { options: [{
                type: Input
            }] } });

class ConfirmComponent {
    constructor() { }
    ngOnInit() {
    }
}
ConfirmComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ConfirmComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
ConfirmComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.3", type: ConfirmComponent, selector: "app-confirm", inputs: { style: "style", baseZIndex: "baseZIndex", styleClass: "styleClass" }, ngImport: i0, template: `
    <p-confirmDialog [style]="style" [styleClass]="styleClass" [baseZIndex]="baseZIndex"></p-confirmDialog>
  `, isInline: true, styles: [""], components: [{ type: i1$7.ConfirmDialog, selector: "p-confirmDialog", inputs: ["header", "icon", "message", "style", "styleClass", "maskStyleClass", "acceptIcon", "acceptLabel", "acceptAriaLabel", "acceptVisible", "rejectIcon", "rejectLabel", "rejectAriaLabel", "rejectVisible", "acceptButtonStyleClass", "rejectButtonStyleClass", "closeOnEscape", "dismissableMask", "blockScroll", "rtl", "closable", "appendTo", "key", "autoZIndex", "baseZIndex", "transitionOptions", "focusTrap", "defaultFocus", "breakpoints", "visible", "position"], outputs: ["onHide"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ConfirmComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-confirm', template: `
    <p-confirmDialog [style]="style" [styleClass]="styleClass" [baseZIndex]="baseZIndex"></p-confirmDialog>
  `, styles: [""] }]
        }], ctorParameters: function () { return []; }, propDecorators: { style: [{
                type: Input
            }], baseZIndex: [{
                type: Input
            }], styleClass: [{
                type: Input
            }] } });

class ModalComponent {
    constructor() {
        this.btnText = {
            apply: 'ACTIONS.APPLY',
            close: 'ACTIONS.CLOSE',
        };
        this.modalClosed = new EventEmitter();
        this.submitModalData = new EventEmitter();
        this.modalOpen = new EventEmitter();
    }
    ngOnInit() { }
    onOpen() {
        this.modalOpen.emit(this.display);
        console.log(this.display);
        return this.display;
    }
    afterClosedModal() {
        this.modalClosed.emit(this.display);
        console.log(this.display);
        return this.display;
    }
    closeModal() {
        this.display = false;
    }
    confirmModal() {
        this.submitModalData.emit('log data from  modal content');
    }
}
ModalComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ModalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
ModalComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.1.3", type: ModalComponent, selector: "app-modal", inputs: { display: "display", resizable: "resizable", header: "header", appendTo: "appendTo", showFooter: "showFooter", btnText: "btnText" }, outputs: { modalClosed: "modalClosed", submitModalData: "submitModalData", modalOpen: "modalOpen" }, ngImport: i0, template: "<p-dialog\r\n  [dismissableMask]=\"true\"\r\n  modal=\"modal\"\r\n  [responsive]=\"true\"\r\n  [(visible)]=\"display\"\r\n  [closable]=\"true\"\r\n  [resizable]=\"resizable\"\r\n  styleClass=\"modalStyle\"\r\n  [appendTo]=\"appendTo\"\r\n  (onShow)=\"onOpen()\"\r\n  (onHide)=\"afterClosedModal()\"\r\n>\r\n  <ng-template pTemplate=\"header\">\r\n    <div class=\"header\">{{ header | translate }}</div>\r\n  </ng-template>\r\n\r\n  <ng-content></ng-content>\r\n\r\n  <hr *ngIf=\"showFooter\" />\r\n\r\n  <ng-container *ngIf=\"showFooter\">\r\n    <ng-template pTemplate=\"footer\">\r\n      <div class=\"m\">\r\n        <button class=\"apply\" pButton type=\"button\" (click)=\"confirmModal()\">\r\n          {{ btnText.apply | translate }}\r\n        </button>\r\n        <button class=\"close button-text p-2\" (click)=\"closeModal()\">\r\n          {{ btnText.close | translate }}\r\n        </button>\r\n      </div>\r\n    </ng-template>\r\n  </ng-container>\r\n</p-dialog>\r\n", styles: ["div.header{width:100%;font-size:2.4rem;font-weight:600;color:#23292f;margin:1.8rem 0 0}hr{height:0;margin:1.5rem 0;overflow:hidden;border-top:1px solid #e9ecef}button.apply,::ng-deep .p-button:enabled:active,::ng-deep .p-button:enabled:hover{border-radius:5px;border:none;font-size:1.4rem;font-weight:500;text-decoration:none;color:#fff;box-shadow:2px 4px 14px #18564a33;background-image:linear-gradient(to right,#d64f70,#9c2b80)}div{text-align:left}div .button-text,div .button-text:enabled:active,div .button-text:enabled:hover{color:#000;background-color:#fff;border:none;cursor:pointer;padding:10px 10px 0}app-modal ::ng-deep .p-field{min-width:300px;height:55px;margin-bottom:.5rem!important}\n"], components: [{ type: i1$8.Dialog, selector: "p-dialog", inputs: ["header", "draggable", "resizable", "positionLeft", "positionTop", "contentStyle", "contentStyleClass", "modal", "closeOnEscape", "dismissableMask", "rtl", "closable", "responsive", "appendTo", "breakpoints", "styleClass", "maskStyleClass", "showHeader", "breakpoint", "blockScroll", "autoZIndex", "baseZIndex", "minX", "minY", "focusOnShow", "maximizable", "keepInViewport", "focusTrap", "transitionOptions", "closeIcon", "closeAriaLabel", "closeTabindex", "minimizeIcon", "maximizeIcon", "visible", "style", "position"], outputs: ["onShow", "onHide", "visibleChange", "onResizeInit", "onResizeEnd", "onDragEnd", "onMaximize"] }], directives: [{ type: i1$1.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i4.ButtonDirective, selector: "[pButton]", inputs: ["iconPos", "loadingIcon", "label", "icon", "loading"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-modal', template: "<p-dialog\r\n  [dismissableMask]=\"true\"\r\n  modal=\"modal\"\r\n  [responsive]=\"true\"\r\n  [(visible)]=\"display\"\r\n  [closable]=\"true\"\r\n  [resizable]=\"resizable\"\r\n  styleClass=\"modalStyle\"\r\n  [appendTo]=\"appendTo\"\r\n  (onShow)=\"onOpen()\"\r\n  (onHide)=\"afterClosedModal()\"\r\n>\r\n  <ng-template pTemplate=\"header\">\r\n    <div class=\"header\">{{ header | translate }}</div>\r\n  </ng-template>\r\n\r\n  <ng-content></ng-content>\r\n\r\n  <hr *ngIf=\"showFooter\" />\r\n\r\n  <ng-container *ngIf=\"showFooter\">\r\n    <ng-template pTemplate=\"footer\">\r\n      <div class=\"m\">\r\n        <button class=\"apply\" pButton type=\"button\" (click)=\"confirmModal()\">\r\n          {{ btnText.apply | translate }}\r\n        </button>\r\n        <button class=\"close button-text p-2\" (click)=\"closeModal()\">\r\n          {{ btnText.close | translate }}\r\n        </button>\r\n      </div>\r\n    </ng-template>\r\n  </ng-container>\r\n</p-dialog>\r\n", styles: ["div.header{width:100%;font-size:2.4rem;font-weight:600;color:#23292f;margin:1.8rem 0 0}hr{height:0;margin:1.5rem 0;overflow:hidden;border-top:1px solid #e9ecef}button.apply,::ng-deep .p-button:enabled:active,::ng-deep .p-button:enabled:hover{border-radius:5px;border:none;font-size:1.4rem;font-weight:500;text-decoration:none;color:#fff;box-shadow:2px 4px 14px #18564a33;background-image:linear-gradient(to right,#d64f70,#9c2b80)}div{text-align:left}div .button-text,div .button-text:enabled:active,div .button-text:enabled:hover{color:#000;background-color:#fff;border:none;cursor:pointer;padding:10px 10px 0}app-modal ::ng-deep .p-field{min-width:300px;height:55px;margin-bottom:.5rem!important}\n"] }]
        }], ctorParameters: function () { return []; }, propDecorators: { display: [{
                type: Input
            }], resizable: [{
                type: Input
            }], header: [{
                type: Input
            }], appendTo: [{
                type: Input
            }], showFooter: [{
                type: Input
            }], btnText: [{
                type: Input
            }], modalClosed: [{
                type: Output
            }], submitModalData: [{
                type: Output
            }], modalOpen: [{
                type: Output
            }] } });

class BreadcrumbInitializedGuard {
    constructor(service) {
        this.service = service;
    }
    canActivate(route, state) {
        const crumbs = route.data['crumbs'];
        this.service.setCrumbs(crumbs);
        return true;
    }
}
BreadcrumbInitializedGuard.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: BreadcrumbInitializedGuard, deps: [{ token: BreadcrumbService }], target: i0.ɵɵFactoryTarget.Injectable });
BreadcrumbInitializedGuard.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: BreadcrumbInitializedGuard });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: BreadcrumbInitializedGuard, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: BreadcrumbService }]; } });

var ENCRYPTION_TYPE;
(function (ENCRYPTION_TYPE) {
    ENCRYPTION_TYPE["RSA"] = "rsa";
    ENCRYPTION_TYPE["AES"] = "aes";
    ENCRYPTION_TYPE["NONE"] = "none";
})(ENCRYPTION_TYPE || (ENCRYPTION_TYPE = {}));

var ToasterEnum;
(function (ToasterEnum) {
    ToasterEnum["error"] = "error";
    ToasterEnum["success"] = "success";
    ToasterEnum["warning"] = "warning";
})(ToasterEnum || (ToasterEnum = {}));

class DecryptStringPipe {
    constructor(aesEncrDecrService, coreConfigService) {
        this.aesEncrDecrService = aesEncrDecrService;
        this.coreConfigService = coreConfigService;
        this.cofigData = this.coreConfigService.configuration;
    }
    transform(value) {
        const AesdecryptionType = this.cofigData.environment.decryptionStringType === ENCRYPTION_TYPE.AES;
        const AesDecryption = () => {
            let decryptedText = this.aesEncrDecrService.decrypt(value);
            return decryptedText;
        };
        if (value)
            if (AesdecryptionType)
                return AesDecryption();
            else
                return value;
        else
            return null;
    }
}
DecryptStringPipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: DecryptStringPipe, deps: [{ token: AesEncrDecrService }, { token: CoreConfigService }], target: i0.ɵɵFactoryTarget.Pipe });
DecryptStringPipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: DecryptStringPipe, name: "decryptString" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: DecryptStringPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'decryptString'
                }]
        }], ctorParameters: function () { return [{ type: AesEncrDecrService }, { type: CoreConfigService }]; } });

class DayAgoPipe {
    constructor(languageService) {
        this.languageService = languageService;
    }
    transform(value) {
        if (value && value !== '-')
            return formatDistance(new Date(value), new Date(), {
                locale: this.languageService.currentLanguage() === 'ar' ? arSA : enUS,
                addSuffix: true,
            });
        return value;
    }
}
DayAgoPipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: DayAgoPipe, deps: [{ token: LanguageService }], target: i0.ɵɵFactoryTarget.Pipe });
DayAgoPipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: DayAgoPipe, name: "DayAgo" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: DayAgoPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'DayAgo',
                }]
        }], ctorParameters: function () { return [{ type: LanguageService }]; } });

class StringLimitPipe {
    transform(value, limit = 25, completeWords = false, ellipsis = '...') {
        if (completeWords)
            limit = value.substr(0, limit).lastIndexOf(' ');
        value = value !== null && value !== void 0 ? value : ' ';
        return value.length > limit ? value.substr(0, limit) + ellipsis : value;
    }
}
StringLimitPipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: StringLimitPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
StringLimitPipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: StringLimitPipe, name: "strLimit" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: StringLimitPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'strLimit',
                }]
        }] });

class HoursFormat {
    transform(value) {
        if (value.toString().length == 1) {
            return '0' + value;
        }
        else {
            return value;
        }
    }
}
HoursFormat.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: HoursFormat, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
HoursFormat.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: HoursFormat, name: "hourFormat" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: HoursFormat, decorators: [{
            type: Pipe,
            args: [{
                    name: 'hourFormat',
                }]
        }] });

class RtlDirective {
    constructor(elRef, renderer, translation) {
        this.elRef = elRef;
        this.renderer = renderer;
        this.translation = translation;
        this.switchClassBasedOnLanguage();
    }
    /*Switch rtl class based on the chosen language from Translation Service*/
    switchClassBasedOnLanguage() {
        this.translation.isEnglish() ? this.renderer.removeClass(this.elRef.nativeElement, 'rtl') : this.renderer.addClass(this.elRef.nativeElement, 'rtl');
        this.translation.languageChanged().subscribe((lang) => {
            this.translation.isEnglish() ? this.renderer.removeClass(this.elRef.nativeElement, 'rtl') : this.renderer.addClass(this.elRef.nativeElement, 'rtl');
        });
    }
}
RtlDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: RtlDirective, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: LanguageService }], target: i0.ɵɵFactoryTarget.Directive });
RtlDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.1.3", type: RtlDirective, selector: "[appSetRTL]", ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: RtlDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[appSetRTL]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: LanguageService }]; } });

class PermissionCheckDirective {
    constructor(eltRef, storage) {
        this.eltRef = eltRef;
        this.storage = storage;
    }
    ngOnInit() {
        if (this.permissions === 'fixedBtn') {
            this.applyPermissions(true);
            return;
        }
        this.storage.getItem('permissions').subscribe(data => {
            if (!data) {
                this.applyPermissions(false);
                return;
            }
            const listPermission = data.split(',');
            if (listPermission.includes(this.permissions))
                this.applyPermissions(true);
            else
                this.applyPermissions(false);
        });
    }
    applyPermissions(allow) {
        const el = this.eltRef.nativeElement;
        if (!allow)
            el.remove();
    }
}
PermissionCheckDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: PermissionCheckDirective, deps: [{ token: i0.ElementRef }, { token: StorageService }], target: i0.ɵɵFactoryTarget.Directive });
PermissionCheckDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.1.3", type: PermissionCheckDirective, selector: "[appPermissionCheck]", inputs: { permissions: ["appPermissionCheck", "permissions"] }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: PermissionCheckDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[appPermissionCheck]',
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: StorageService }]; }, propDecorators: { permissions: [{
                type: Input,
                args: ['appPermissionCheck']
            }] } });

const MODULES$1 = [
    ToastModule,
    ButtonModule,
    RippleModule,
    TableModule,
    ConfirmDialogModule,
    BreadcrumbModule,
    MessagesModule,
    MessageModule,
    AccordionModule,
    TabViewModule,
    InputTextModule,
    ChartModule,
    CheckboxModule,
    NgApexchartsModule,
    ToolbarModule,
    MenuModule,
    InputSwitchModule,
    OverlayPanelModule,
    RadioButtonModule,
    InputSwitchModule,
    CalendarModule,
    DropdownModule,
    MultiSelectModule,
    AutoCompleteModule,
    MenubarModule,
    AvatarModule,
    AvatarGroupModule,
    NgSelectModule,
    EditorModule,
    SelectButtonModule,
    InputTextareaModule,
    DialogModule,
    DynamicDialogModule,
    DividerModule,
];
class SharedModule {
}
SharedModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: SharedModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
SharedModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: SharedModule, imports: [ToastModule,
        ButtonModule,
        RippleModule,
        TableModule,
        ConfirmDialogModule,
        BreadcrumbModule,
        MessagesModule,
        MessageModule,
        AccordionModule,
        TabViewModule,
        InputTextModule,
        ChartModule,
        CheckboxModule,
        NgApexchartsModule,
        ToolbarModule,
        MenuModule,
        InputSwitchModule,
        OverlayPanelModule,
        RadioButtonModule,
        InputSwitchModule,
        CalendarModule,
        DropdownModule,
        MultiSelectModule,
        AutoCompleteModule,
        MenubarModule,
        AvatarModule,
        AvatarGroupModule,
        NgSelectModule,
        EditorModule,
        SelectButtonModule,
        InputTextareaModule,
        DialogModule,
        DynamicDialogModule,
        DividerModule], exports: [ToastModule,
        ButtonModule,
        RippleModule,
        TableModule,
        ConfirmDialogModule,
        BreadcrumbModule,
        MessagesModule,
        MessageModule,
        AccordionModule,
        TabViewModule,
        InputTextModule,
        ChartModule,
        CheckboxModule,
        NgApexchartsModule,
        ToolbarModule,
        MenuModule,
        InputSwitchModule,
        OverlayPanelModule,
        RadioButtonModule,
        InputSwitchModule,
        CalendarModule,
        DropdownModule,
        MultiSelectModule,
        AutoCompleteModule,
        MenubarModule,
        AvatarModule,
        AvatarGroupModule,
        NgSelectModule,
        EditorModule,
        SelectButtonModule,
        InputTextareaModule,
        DialogModule,
        DynamicDialogModule,
        DividerModule] });
SharedModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: SharedModule, providers: [], imports: [[...MODULES$1], ToastModule,
        ButtonModule,
        RippleModule,
        TableModule,
        ConfirmDialogModule,
        BreadcrumbModule,
        MessagesModule,
        MessageModule,
        AccordionModule,
        TabViewModule,
        InputTextModule,
        ChartModule,
        CheckboxModule,
        NgApexchartsModule,
        ToolbarModule,
        MenuModule,
        InputSwitchModule,
        OverlayPanelModule,
        RadioButtonModule,
        InputSwitchModule,
        CalendarModule,
        DropdownModule,
        MultiSelectModule,
        AutoCompleteModule,
        MenubarModule,
        AvatarModule,
        AvatarGroupModule,
        NgSelectModule,
        EditorModule,
        SelectButtonModule,
        InputTextareaModule,
        DialogModule,
        DynamicDialogModule,
        DividerModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: SharedModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [...MODULES$1],
                    providers: [],
                    exports: [...MODULES$1],
                }]
        }] });

const BASICMODULES = [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    HttpClientModule,
    NgHttpLoaderModule.forRoot(),
];
const MODULES = [SharedModule];
const SERVICES = [
    MessageService,
    ConfirmationService,
    BreadcrumbService,
    BreadcrumbInitializedGuard,
    DialogService,
    CoreConfigService,
];
const PIPES = [DayAgoPipe, StringLimitPipe, HoursFormat, DecryptStringPipe];
const DIRECTIVES = [];
const COMPONENTS = [
    BreadcrumbViaItemsComponent,
    BreadcrumbViaRouteComponent,
    HttpLoaderComponent,
    InlineMessagesComponent,
    SeveritiesMessagesComponent,
    ChartComponent,
    ConfirmComponent,
    ApxChartWrapperComponent,
    EmptyDataComponent,
    ModalComponent,
    RtlDirective,
    PermissionCheckDirective,
];
class YouxelCoreModule {
    static forRoot(items) {
        return {
            ngModule: YouxelCoreModule,
            providers: [
                ...SERVICES,
                ...INTERCEPTORS,
                { provide: 'config', useFactory: CoreConfigService, useValue: items },
            ],
        };
    }
}
YouxelCoreModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: YouxelCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
YouxelCoreModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: YouxelCoreModule, declarations: [DayAgoPipe, StringLimitPipe, HoursFormat, DecryptStringPipe, BreadcrumbViaItemsComponent,
        BreadcrumbViaRouteComponent,
        HttpLoaderComponent,
        InlineMessagesComponent,
        SeveritiesMessagesComponent,
        ChartComponent,
        ConfirmComponent,
        ApxChartWrapperComponent,
        EmptyDataComponent,
        ModalComponent,
        RtlDirective,
        PermissionCheckDirective], imports: [SharedModule, CommonModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule,
        HttpClientModule, i1$3.NgHttpLoaderModule], exports: [CommonModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule,
        HttpClientModule, i1$3.NgHttpLoaderModule, DayAgoPipe, StringLimitPipe, HoursFormat, DecryptStringPipe, BreadcrumbViaItemsComponent,
        BreadcrumbViaRouteComponent,
        HttpLoaderComponent,
        InlineMessagesComponent,
        SeveritiesMessagesComponent,
        ChartComponent,
        ConfirmComponent,
        ApxChartWrapperComponent,
        EmptyDataComponent,
        ModalComponent,
        RtlDirective,
        PermissionCheckDirective] });
YouxelCoreModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: YouxelCoreModule, imports: [[...MODULES, ...BASICMODULES], CommonModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule,
        HttpClientModule, i1$3.NgHttpLoaderModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: YouxelCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [...MODULES, ...BASICMODULES],
                    declarations: [...PIPES, ...DIRECTIVES, ...COMPONENTS],
                    exports: [
                        // ...MODULES,
                        ...BASICMODULES,
                        ...PIPES,
                        ...DIRECTIVES,
                        ...COMPONENTS,
                    ],
                }]
        }] });

class AuthGuard {
    constructor(storage, router) {
        this.storage = storage;
        this.router = router;
    }
    canActivate() {
        if (this.storage.getToken() === null) {
            this.router.navigate(['/auth/login']);
            return false;
        }
        else
            return true;
    }
}
AuthGuard.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: AuthGuard, deps: [{ token: StorageService }, { token: i2.Router }], target: i0.ɵɵFactoryTarget.Injectable });
AuthGuard.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: AuthGuard, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: AuthGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: StorageService }, { type: i2.Router }]; } });

class LoginGuard {
    constructor(storage, router) {
        this.storage = storage;
        this.router = router;
    }
    canActivate() {
        if (this.storage.getToken() !== null) {
            this.router.navigate(['/']);
            return false;
        }
        else
            return true;
    }
}
LoginGuard.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: LoginGuard, deps: [{ token: StorageService }, { token: i2.Router }], target: i0.ɵɵFactoryTarget.Injectable });
LoginGuard.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: LoginGuard, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: LoginGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: StorageService }, { type: i2.Router }]; } });

class ConfirmGuard {
    canDeactivate(component, next, state) {
        return component.confirm();
    }
}
ConfirmGuard.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ConfirmGuard, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
ConfirmGuard.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ConfirmGuard, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: ConfirmGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

class LeavePageGuard {
    canDeactivate(component, currentRoute, currentState, nextState) {
        return component.canDeactivate(nextState);
    }
}
LeavePageGuard.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: LeavePageGuard, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
LeavePageGuard.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: LeavePageGuard, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: LeavePageGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class PermissionGuard {
    constructor(router, storage) {
        this.router = router;
        this.storage = storage;
    }
    canActivate(route, state) {
        let stateRoute;
        this.storage.getItem('permissions').subscribe(data => {
            if (!data)
                stateRoute = false;
            else {
                const listPermission = data.split(',');
                if (listPermission.includes(route.data.permission))
                    stateRoute = true;
                else {
                    this.router.navigate(['/']);
                    stateRoute = false;
                }
            }
        });
        return stateRoute;
    }
}
PermissionGuard.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: PermissionGuard, deps: [{ token: i2.Router }, { token: StorageService }], target: i0.ɵɵFactoryTarget.Injectable });
PermissionGuard.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: PermissionGuard, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: PermissionGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: i2.Router }, { type: StorageService }]; } });

class InternetConnectionGuard {
    constructor(connectionService) {
        this.connectionService = connectionService;
        this.connectionService.isConnected().subscribe(res => {
            this.isConnected = res;
        });
    }
    canActivate(route, state) {
        return true;
    }
    canDeactivate(component, currentRoute, currentState, nextState) {
        if (this.isConnected)
            return true;
        else {
            this.connectionService.checkConnection();
            return false;
        }
        // return component.canDeactive(nextState);
    }
}
InternetConnectionGuard.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: InternetConnectionGuard, deps: [{ token: ConnectionService }], target: i0.ɵɵFactoryTarget.Injectable });
InternetConnectionGuard.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: InternetConnectionGuard, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: InternetConnectionGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: ConnectionService }]; } });

class LoaderInterceptorService {
    constructor(loaderService) {
        this.loaderService = loaderService;
        this.totalRequests = 0;
    }
    checkToHide() {
        if (this.totalRequests === 0) {
            this.loaderService.hide();
        }
    }
    decrementCounter() {
        this.totalRequests--;
    }
    incrementCounter() {
        this.totalRequests++;
    }
    intercept(req, next) {
        this.incrementCounter();
        this.loaderService.show();
        return next.handle(req).pipe(catchError((error) => {
            this.decrementCounter();
            this.checkToHide();
            return of(error);
        }), finalize(() => {
            this.decrementCounter();
            this.checkToHide();
        }));
    }
}
LoaderInterceptorService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: LoaderInterceptorService, deps: [{ token: LoaderService }], target: i0.ɵɵFactoryTarget.Injectable });
LoaderInterceptorService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: LoaderInterceptorService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: LoaderInterceptorService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: LoaderService }]; } });

class CacheInterceptor {
    constructor() { }
    intercept(request, next) {
        request = request.clone({
            setHeaders: {
                'Cache-Control': 'no-cache, no-store, must-revalidate, post- check=0, pre- check=0',
                Pragma: 'no-cache',
                Expires: '0',
            }
        });
        return next.handle(request);
    }
}
CacheInterceptor.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: CacheInterceptor, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
CacheInterceptor.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: CacheInterceptor });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.1.3", ngImport: i0, type: CacheInterceptor, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return []; } });

/**
 * Generated bundle index. Do not edit.
 */

export { AesEncrDecrService, ApxChartWrapperComponent, AuthGuard, BreadcrumbInitializedGuard, BreadcrumbService, BreadcrumbViaItemsComponent, BreadcrumbViaRouteComponent, CacheInterceptor, ChartComponent, ConfirmComponent, ConfirmGuard, ConfirmService, ConnectionService, CoreConfigService, DayAgoPipe, DecryptStringPipe, ENCRYPTION_TYPE, EToasterTypes, EmptyDataComponent, ErrorHandlingInterceptor, HoursFormat, HttpLoaderComponent, HttpService, INTERCEPTORS, InlineMessagesComponent, InternetConnectionGuard, LanguageService, LeavePageGuard, LoaderInterceptorService, LoaderService, LoginGuard, ModalComponent, PermissionCheckDirective, PermissionGuard, RequestHeadersService, RtlDirective, ServerConfigService, SeveritiesMessagesComponent, StorageService, StringLimitPipe, ToastService, ToasterEnum, TokenInterceptor, YouxelCoreModule, logger };
//# sourceMappingURL=youxel-core.mjs.map
