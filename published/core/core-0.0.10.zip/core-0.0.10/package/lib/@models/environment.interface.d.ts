export declare class IEnvironment {
    baseUrl?: string;
    rsaPublicKey?: string;
    aesPublicKey?: string;
    decryptionStringType?: string;
}
