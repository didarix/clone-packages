export declare enum ENCRYPTION_TYPE {
    RSA = "rsa",
    AES = "aes",
    NONE = "none"
}
