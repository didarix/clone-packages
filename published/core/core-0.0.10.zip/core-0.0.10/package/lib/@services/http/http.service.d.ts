import { CoreConfigService } from './../CoreConfig.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IEnvironment } from '../../@models/environment.interface';
import * as i0 from "@angular/core";
export declare class HttpService {
    private http;
    private coreConfigService;
    environemt: IEnvironment;
    private baseUrl;
    packageConfig: any;
    /**
     * @description Base backend URL
     *
     * @readonly
     * @type {string}
     */
    get URL(): string;
    constructor(http: HttpClient, coreConfigService: CoreConfigService);
    /**
     * @description Post request using angular httpClient module
     * @param url - the end point url
     * @param data - request payload
     * @param options - to add custom config for request header
     * @return Observable of response, comes from the end point
     */
    post(url: string, data: any, options?: any): Observable<any>;
    /**
     * @description Post request using angular httpClient module
     * @param url - the end point url
     * @param data - request payload
     * @return Observable of response, comes from the end point
     */
    postUrl(url: string, data: any): Observable<any>;
    /**
     * @description Get request using angular httpClient module
     * @param url - the end point url
     * @param data - request payload
     * @return Observable of response, comes from the end point
     */
    get(url: string, data?: any): Observable<any>;
    /**
     * @description PUT request using angular httpClient module
     * you can bass a parameter (data) in the url separated by '/'
     * @param url - the end point url
     * @param data - request payload
     * @return Observable of response, comes from the end point
     */
    put(url: string, data?: any, options?: any): Observable<any>;
    /**
     * @description DELETE request using angular httpClient module
     * you can bass a parameter (data) in the url separated by '/'
     * @param url - the end point url
     * @param data - request payload
     * @return Observable of response, comes from the end point
     */
    delete(url: string, data?: any): Observable<any>;
    deleteWithRequestBody(url: string, data?: any): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<HttpService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HttpService>;
}
