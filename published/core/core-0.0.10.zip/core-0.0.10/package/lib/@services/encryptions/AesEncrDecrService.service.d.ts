import { CoreConfigService } from './../CoreConfig.service';
import { IEnvironment } from '../../@models/environment.interface';
import * as i0 from "@angular/core";
export declare class AesEncrDecrService {
    private coreConfigService;
    configPackageData: IEnvironment;
    key: any;
    iv: any;
    CipherOption: any;
    constructor(coreConfigService: CoreConfigService);
    /**
     * @description `The encrypt method is use for encrypt the value.`
     * @param value {string} to be encrypted
     * @returns encrypted value
     */
    encrypt(value: string): string;
    /**
     * @description `The decrypt method is use for decrypt the value.`
     * @param value {string} to be decrypted
     * @returns decrypted value
     */
    decrypt(value: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AesEncrDecrService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AesEncrDecrService>;
}
