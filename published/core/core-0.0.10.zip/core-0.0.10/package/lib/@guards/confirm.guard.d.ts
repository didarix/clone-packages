import { ActivatedRouteSnapshot, RouterStateSnapshot, CanDeactivate } from '@angular/router';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export interface CanComponentDeactivate {
    confirm(): boolean;
}
export declare class ConfirmGuard implements CanDeactivate<CanComponentDeactivate> {
    canDeactivate(component: CanComponentDeactivate, next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfirmGuard>;
}
