import { OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import * as i0 from "@angular/core";
export declare class BreadcrumbViaItemsComponent implements OnInit {
    crumbs: MenuItem[];
    items: MenuItem[];
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbViaItemsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbViaItemsComponent, "breadcrumb-via-items", never, { "crumbs": "crumbs"; }, {}, never, never>;
}
