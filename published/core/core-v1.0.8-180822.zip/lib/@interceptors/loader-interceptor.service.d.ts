import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LoaderService } from '../@services';
import * as i0 from "@angular/core";
export declare class LoaderInterceptorService implements HttpInterceptor {
    loaderService: LoaderService;
    private totalRequests;
    constructor(loaderService: LoaderService);
    checkToHide(): void;
    decrementCounter(): void;
    incrementCounter(): void;
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoaderInterceptorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoaderInterceptorService>;
}
