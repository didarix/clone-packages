import { Observable } from 'rxjs';
import { ToastService } from '../toaster/toaster.service';
import * as i0 from "@angular/core";
export declare class ConnectionService {
    private toaster;
    /**
     * A Boolean Observable flag.
     */
    private connectionMonitor;
    constructor(toaster: ToastService);
    /**
     * `isConnected()` used for alert if the user connect/disconnect to the Internet.
     * @returns A Boolean Observables
     */
    isConnected(): Observable<boolean>;
    checkConnection(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConnectionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConnectionService>;
}
