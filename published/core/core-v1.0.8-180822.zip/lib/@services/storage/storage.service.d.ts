import { Observable } from 'rxjs';
import { CoreConfigService } from '../CoreConfig.service';
import * as i0 from "@angular/core";
export declare class StorageService {
    private coreConfigService;
    constructor(coreConfigService: CoreConfigService);
    get getUserTokenKey(): string;
    /**
     * get user langauage key that setted in his storage
     */
    get getUserLanguageKey(): string;
    /**
     * Save items to local storage as observable
     * By key, value pairs
     * @param key the name of property
     * @param value the value we need to store
     */
    setItem(key: string, value: string): Observable<void>;
    /**
     * Get the value from local storage for a given property as observable
     * @param key the key of the item we need
     * @returns  the value of the given key
     */
    getItem(key: string): Observable<string | null>;
    /**
     * Save items to local storage
     * By key, value pairs
     * @param key the name of property
     * @param value the value we need to store
     */
    setStringItem(key: string, value: string): void;
    /**
     * Get the value from local storage for a given property
     * @param  key the key of the item we need
     * @returns  the value of the given key
     */
    getStringItem(key: string): string | null;
    /**
     * Remove the value from local storage for a given property
     * @param key the key of the item we need
     * @returns  the value of the given key
     */
    removeItem(key: string): void;
    /**
     * Get the token for the current active user
     * @returns  User Token it's by default secret
     */
    getToken(): string | null;
    /**
     * Clear the localStorage and active variables
     */
    clearStorage(): Observable<void>;
    /**
     *
     * @description Get the current language for the user
     * @returns Current Language
     *
     */
    getLang(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<StorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StorageService>;
}
