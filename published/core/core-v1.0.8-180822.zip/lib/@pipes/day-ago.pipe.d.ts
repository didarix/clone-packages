import { PipeTransform } from '@angular/core';
import { LanguageService } from '../@services/translation/language.service';
import * as i0 from "@angular/core";
export declare class DayAgoPipe implements PipeTransform {
    private languageService;
    constructor(languageService: LanguageService);
    transform(value: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<DayAgoPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<DayAgoPipe, "DayAgo">;
}
