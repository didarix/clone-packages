import { ElementRef, OnInit } from '@angular/core';
import { StorageService } from '../@services';
import * as i0 from "@angular/core";
export declare class PermissionCheckDirective implements OnInit {
    private eltRef;
    private storage;
    permissions: string;
    constructor(eltRef: ElementRef, storage: StorageService);
    ngOnInit(): void;
    applyPermissions(allow: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionCheckDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PermissionCheckDirective, "[appPermissionCheck]", never, { "permissions": "appPermissionCheck"; }, {}, never>;
}
