import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { StorageService } from '../@services';
import * as i0 from "@angular/core";
export declare class PermissionGuard implements CanActivate {
    private router;
    private storage;
    constructor(router: Router, storage: StorageService);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PermissionGuard>;
}
