/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@youxel/core" />
export * from './index';
