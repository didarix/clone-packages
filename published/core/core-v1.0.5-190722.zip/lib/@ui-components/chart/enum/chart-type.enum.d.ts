export declare enum ChartType {
    Bar = "bar",
    HorizontalBar = "horizontalBar",
    Doughnut = "doughnut",
    Line = "line",
    PolarArea = "polarArea",
    Pie = "pie",
    Radar = "radar"
}
