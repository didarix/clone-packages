import { OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IEmptyDataOptions } from './interfaces/empty_data_interface';
import * as i0 from "@angular/core";
export declare class EmptyDataComponent implements OnInit {
    private router;
    private route;
    options: IEmptyDataOptions;
    constructor(router: Router, route: ActivatedRoute);
    ngOnInit(): void;
    redirectAction(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<EmptyDataComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EmptyDataComponent, "app-empty-data", never, { "options": "options"; }, {}, never, never>;
}
