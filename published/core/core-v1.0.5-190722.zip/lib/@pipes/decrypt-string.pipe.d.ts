import { PipeTransform } from '@angular/core';
import { AesEncrDecrService, CoreConfigService } from '../@services';
import * as i0 from "@angular/core";
export declare class DecryptStringPipe implements PipeTransform {
    private aesEncrDecrService;
    private coreConfigService;
    cofigData: any;
    constructor(aesEncrDecrService: AesEncrDecrService, coreConfigService: CoreConfigService);
    transform(value: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DecryptStringPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<DecryptStringPipe, "decryptString">;
}
