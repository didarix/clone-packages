export interface LoggerObject {
    Date: string;
    Type: string;
    Message: string;
    extraInfo: string[] | Object[] | [];
}
