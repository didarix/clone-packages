import { EDycryptionType, EEncryptionType } from '../enums';
export declare class IYouxelEnvironment {
    baseUrl?: string;
    rsaPublicKey?: string;
    aesPublicKey?: string;
    decryptionStringType?: EDycryptionType;
    encryptionType?: EEncryptionType;
    aesConfig?: IAesConfig;
}
export interface IAesConfig {
    key: string;
    ivSubstring?: number;
}
