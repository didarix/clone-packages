import { OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { PrimeNGConfig } from 'primeng/api';
import * as i0 from "@angular/core";
export declare class InlineMessagesComponent implements OnInit {
    private messageService;
    private primengConfig;
    severity: string;
    message: string;
    constructor(messageService: MessageService, primengConfig: PrimeNGConfig);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InlineMessagesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InlineMessagesComponent, "inline-messages", never, { "severity": "severity"; "message": "message"; }, {}, never, never>;
}
