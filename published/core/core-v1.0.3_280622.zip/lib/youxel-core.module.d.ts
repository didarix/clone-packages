import { ModuleWithProviders } from '@angular/core';
import { IYouxelEnvironment } from './interfaces/environment.interface';
import * as i0 from "@angular/core";
import * as i1 from "./@pipes/day-ago.pipe";
import * as i2 from "./@pipes/string-limit.pipe";
import * as i3 from "./@pipes/hours-format.pipe";
import * as i4 from "./@pipes/decrypt-string.pipe";
import * as i5 from "./@ui-components/breadcrumb-via-items/breadcrumb-via-items.component";
import * as i6 from "./@ui-components/breadcrumb-via-route/breadcrumb-via-route.component";
import * as i7 from "./@ui-components/http-loader/http-loader.component";
import * as i8 from "./@ui-components/inline-messages/inline-messages.component";
import * as i9 from "./@ui-components/severities-messages/severities-messages.component";
import * as i10 from "./@ui-components/chart/chart.component";
import * as i11 from "./@ui-components/confirm/confirm.component";
import * as i12 from "./@ui-components/apx-chart-wrapper/apx-chart-wrapper.component";
import * as i13 from "./@ui-components/empty-data/empty-data.component";
import * as i14 from "./@ui-components/modal/modal.component";
import * as i15 from "./@directives/rtl.directive";
import * as i16 from "./@directives/permission-check.directive";
import * as i17 from "../shared/shared.module";
import * as i18 from "@angular/common";
import * as i19 from "@angular/forms";
import * as i20 from "@angular/router";
import * as i21 from "@angular/common/http";
import * as i22 from "ng-http-loader";
export declare class YouxelCoreModule {
    static forRoot(items: {
        environment: IYouxelEnvironment;
        userTokenKey?: string;
        errorHandlerMessages?: any;
    }): ModuleWithProviders<YouxelCoreModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<YouxelCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<YouxelCoreModule, [typeof i1.DayAgoPipe, typeof i2.StringLimitPipe, typeof i3.HoursFormat, typeof i4.DecryptStringPipe, typeof i5.BreadcrumbViaItemsComponent, typeof i6.BreadcrumbViaRouteComponent, typeof i7.HttpLoaderComponent, typeof i8.InlineMessagesComponent, typeof i9.SeveritiesMessagesComponent, typeof i10.ChartComponent, typeof i11.ConfirmComponent, typeof i12.ApxChartWrapperComponent, typeof i13.EmptyDataComponent, typeof i14.ModalComponent, typeof i15.RtlDirective, typeof i16.PermissionCheckDirective], [typeof i17.SharedModule, typeof i18.CommonModule, typeof i19.FormsModule, typeof i19.ReactiveFormsModule, typeof i20.RouterModule, typeof i21.HttpClientModule, typeof i22.NgHttpLoaderModule], [typeof i18.CommonModule, typeof i19.FormsModule, typeof i19.ReactiveFormsModule, typeof i20.RouterModule, typeof i21.HttpClientModule, typeof i22.NgHttpLoaderModule, typeof i1.DayAgoPipe, typeof i2.StringLimitPipe, typeof i3.HoursFormat, typeof i4.DecryptStringPipe, typeof i5.BreadcrumbViaItemsComponent, typeof i6.BreadcrumbViaRouteComponent, typeof i7.HttpLoaderComponent, typeof i8.InlineMessagesComponent, typeof i9.SeveritiesMessagesComponent, typeof i10.ChartComponent, typeof i11.ConfirmComponent, typeof i12.ApxChartWrapperComponent, typeof i13.EmptyDataComponent, typeof i14.ModalComponent, typeof i15.RtlDirective, typeof i16.PermissionCheckDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<YouxelCoreModule>;
}
