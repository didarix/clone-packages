import { Confirmation, ConfirmationService } from 'primeng/api';
import * as i0 from "@angular/core";
export declare class ConfirmService {
    private confirmationService;
    constructor(confirmationService: ConfirmationService);
    confirm(config: Confirmation): ConfirmationService;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfirmService>;
}
