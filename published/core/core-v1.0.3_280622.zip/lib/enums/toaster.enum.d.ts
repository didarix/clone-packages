export declare enum ToasterEnum {
    error = "error",
    success = "success",
    warning = "warning"
}
