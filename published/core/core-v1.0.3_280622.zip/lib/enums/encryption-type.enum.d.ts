export declare enum EEncryptionType {
    RSA = "rsa",
    AES = "aes",
    NONE = "none"
}
