import { HttpHeaders } from '@angular/common/http';
import { StorageService } from '../@services';
import * as i0 from "@angular/core";
export declare class RequestHeadersService {
    private storage;
    head: HttpHeaders;
    private _HEADERS;
    get token(): string;
    get lang(): string;
    get headers(): any;
    set headers(value: any);
    constructor(storage: StorageService);
    private defaultHeaders;
    static ɵfac: i0.ɵɵFactoryDeclaration<RequestHeadersService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RequestHeadersService>;
}
