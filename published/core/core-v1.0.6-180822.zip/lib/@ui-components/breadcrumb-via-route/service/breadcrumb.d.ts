import { MenuItem } from 'primeng/api';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class BreadcrumbService {
    private crumbs;
    crumbs$: Observable<MenuItem[]>;
    constructor();
    setCrumbs(items: MenuItem[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BreadcrumbService>;
}
