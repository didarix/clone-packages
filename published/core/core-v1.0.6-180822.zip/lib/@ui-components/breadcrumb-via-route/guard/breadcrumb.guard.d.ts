import { CanActivate, RouterStateSnapshot, ActivatedRouteSnapshot } from '@angular/router';
import { BreadcrumbService } from '../service/breadcrumb';
import * as i0 from "@angular/core";
export declare class BreadcrumbInitializedGuard implements CanActivate {
    private service;
    constructor(service: BreadcrumbService);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbInitializedGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BreadcrumbInitializedGuard>;
}
