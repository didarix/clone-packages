import { OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { Observable } from 'rxjs';
import { BreadcrumbService } from './service/breadcrumb';
import * as i0 from "@angular/core";
export declare class BreadcrumbViaRouteComponent implements OnInit {
    private breadcrumb;
    crumbs$: Observable<MenuItem[]>;
    constructor(breadcrumb: BreadcrumbService);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbViaRouteComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbViaRouteComponent, "breadcrumb-via-route", never, {}, {}, never, never>;
}
