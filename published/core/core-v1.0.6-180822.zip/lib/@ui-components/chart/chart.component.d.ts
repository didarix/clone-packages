import { OnInit } from '@angular/core';
import { ChartType } from './enum/chart-type.enum';
import * as i0 from "@angular/core";
export declare class ChartComponent implements OnInit {
    type: ChartType;
    data: any;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChartComponent, "app-chart", never, { "type": "type"; "data": "data"; }, {}, never, never>;
}
