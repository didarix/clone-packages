import { IYouxelEnvironment } from '../../interfaces/environment.interface';
import { CoreConfigService } from '../CoreConfig.service';
import * as i0 from "@angular/core";
export declare class RSAHelper {
    private coreConfigService;
    environemt: IYouxelEnvironment;
    get rsaKey(): string;
    constructor(coreConfigService: CoreConfigService);
    encryptWithPublicKey(valueToEncrypt: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<RSAHelper, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RSAHelper>;
}
