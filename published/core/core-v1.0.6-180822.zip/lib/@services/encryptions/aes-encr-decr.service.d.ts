import * as CryptoJS from 'crypto-js';
import { IYouxelEnvironment } from '../../interfaces/environment.interface';
import { CoreConfigService } from '../CoreConfig.service';
import * as i0 from "@angular/core";
export declare class AesEncrDecrService {
    private coreConfigService;
    environemt: IYouxelEnvironment;
    CipherOption: any;
    get aesKey(): string;
    get encryptedKey(): CryptoJS.lib.WordArray;
    get iv(): CryptoJS.lib.WordArray;
    constructor(coreConfigService: CoreConfigService);
    /**
     * @description `The encrypt method is use for encrypt the value.`
     * @param value {string} to be encrypted
     * @returns encrypted value
     */
    encrypt(value: string): string;
    /**
     * @description `The decrypt method is use for decrypt the value.`
     * @param value {string} to be decrypted
     * @returns decrypted value
     */
    decrypt(value: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AesEncrDecrService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AesEncrDecrService>;
}
