import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, CanDeactivate } from '@angular/router';
import { Observable } from 'rxjs';
import { ConnectionService } from '../@services';
import * as i0 from "@angular/core";
export declare class InternetConnectionGuard implements CanActivate, CanDeactivate<any> {
    private connectionService;
    isConnected: any;
    constructor(connectionService: ConnectionService);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree;
    canDeactivate(component: any, currentRoute: ActivatedRouteSnapshot, currentState: RouterStateSnapshot, nextState?: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree;
    static ɵfac: i0.ɵɵFactoryDeclaration<InternetConnectionGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InternetConnectionGuard>;
}
