import { TokenInterceptor } from './token.interceptor';
import { ErrorHandlingInterceptor } from './error-handling.interceptor';
/**
 * Interceptors Wrapper
 * An array to wrap all interceptors using at the app
 */
export declare const INTERCEPTORS: ({
    provide: import("@angular/core").InjectionToken<import("@angular/common/http").HttpInterceptor[]>;
    useClass: typeof TokenInterceptor;
    multi: boolean;
} | {
    provide: import("@angular/core").InjectionToken<import("@angular/common/http").HttpInterceptor[]>;
    useClass: typeof ErrorHandlingInterceptor;
    multi: boolean;
})[];
