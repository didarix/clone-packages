import { MessageService } from 'primeng/api';
import * as i0 from "@angular/core";
export declare enum EToasterTypes {
    success = "Success",
    warning = "Warning",
    error = "Error"
}
export declare class ToastService {
    private toaster;
    constructor(toaster: MessageService);
    /**
     * @description Show toaster with multiple styles
     *
     * @param  {} {message - toaster message
     * @param  {} type - toaster type (success, warning, error)
     * @param  {} duration - the toaster duration
     * @param  {IToasterContent} title - toaster title}
     * @returns void
     */
    show({ message, type, duration, title }: IToasterContent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToastService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ToastService>;
}
export interface IToasterContent {
    message: string;
    type?: EToasterTypes;
    duration?: number;
    title?: string;
}
