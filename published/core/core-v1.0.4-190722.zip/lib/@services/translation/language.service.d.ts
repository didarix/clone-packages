import { TranslateService } from '@ngx-translate/core';
import { Observable } from 'rxjs';
import { StorageService } from '../storage/storage.service';
import * as i0 from "@angular/core";
export declare enum ELang {
    EN = "en",
    AR = "ar"
}
export declare enum EBodyLangClass {
    EN = "lang-en",
    AR = "lang-ar"
}
export declare class LanguageService {
    private translate;
    private storage;
    constructor(translate: TranslateService, storage: StorageService);
    /**
     * Enable the language translation options,
     * Set the language to the current user preferred language
     */
    enableLanguage(defaultLang?: ELang.AR | ELang.EN): void;
    currentLanguage(): string;
    /**
     * Change the language for the site
     * you can bass a parameter (lang) to the target language
     * @param lang - the target language param
     * @return Returns void
     */
    setLanguage(lang: string): void;
    /**
     * Toggle the body element lang class
     */
    toggleBodyLanguageClass(): void;
    /**
     * Toggle the current language
     */
    toggleLanguage(enableReloading?: boolean): void;
    /**
     * Check the Current Language if english or not
     * @returns True if the current language is english
     */
    isEnglish(): boolean;
    languageChanged(): Observable<any>;
    /**
     *
     * @description translate at typescript with translation key
     * @param key - the translation key
     * @returns - the translated value
     *
     */
    translateTs(key: string): string;
    /**
     *
     * @description translate at typescript with translation key
     * @param key - the translation key
     * @returns - the translated value
     *
     */
    stream(key: string): Observable<any>;
    setStyle(lang: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LanguageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LanguageService>;
}
