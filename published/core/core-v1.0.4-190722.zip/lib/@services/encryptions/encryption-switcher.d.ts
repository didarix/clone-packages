import { RSAHelper } from './RSAHelper.service';
import { AesEncrDecrService } from './aes-encr-decr.service';
import { IYouxelEnvironment } from '../../interfaces/environment.interface';
import { CoreConfigService } from '../CoreConfig.service';
import * as i0 from "@angular/core";
export declare class EncryptionSwitcherService {
    private rsaEncryptionService;
    private aesEncryptionService;
    private coreConfigService;
    environemt: IYouxelEnvironment;
    get encryptionType(): string;
    constructor(rsaEncryptionService: RSAHelper, aesEncryptionService: AesEncrDecrService, coreConfigService: CoreConfigService);
    encrypt(value: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<EncryptionSwitcherService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EncryptionSwitcherService>;
}
