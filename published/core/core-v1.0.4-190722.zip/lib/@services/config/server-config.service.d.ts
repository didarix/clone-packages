import { CoreConfigService } from './../CoreConfig.service';
import { HttpClient } from '@angular/common/http';
import * as i0 from "@angular/core";
export declare class ServerConfigService {
    private http;
    private coreConfigService;
    packageConfig: any;
    constructor(http: HttpClient, coreConfigService: CoreConfigService);
    private currentEnvironmentSubject;
    currentEnvironment: import("rxjs").Observable<any>;
    init(): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ServerConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ServerConfigService>;
}
