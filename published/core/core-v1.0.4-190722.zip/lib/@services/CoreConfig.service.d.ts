import { ICorePackageInterface } from '../interfaces';
import * as i0 from "@angular/core";
export declare class CoreConfigService {
    private config;
    configuration: ICorePackageInterface;
    constructor(config: any);
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CoreConfigService>;
}
