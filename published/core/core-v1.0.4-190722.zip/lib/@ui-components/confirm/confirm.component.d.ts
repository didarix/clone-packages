import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ConfirmComponent implements OnInit {
    style: any;
    baseZIndex: any;
    styleClass: any;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfirmComponent, "app-confirm", never, { "style": "style"; "baseZIndex": "baseZIndex"; "styleClass": "styleClass"; }, {}, never, never>;
}
