export declare enum EPeriodTime {
    AM = "AM",
    PM = "PM"
}
export declare enum ERangeTime {
    from = "from",
    to = "to"
}
