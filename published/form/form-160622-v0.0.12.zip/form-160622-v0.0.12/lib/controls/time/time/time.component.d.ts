import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class TimeComponent extends FieldType {
    static ɵfac: i0.ɵɵFactoryDeclaration<TimeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimeComponent, "app-time", never, {}, {}, never, never>;
}
