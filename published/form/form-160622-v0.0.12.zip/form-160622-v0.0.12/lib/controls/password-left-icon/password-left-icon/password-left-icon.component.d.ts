import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class PasswordLeftIconComponent extends FieldType {
    passwordVisiblity: boolean;
    /**
     * this icon appears beside input if there is an error in validation
     * and if it's send by users of the package
     */
    errorICon: string;
    /**
     * this icon appears inside input as indicator of the field
     */
    leftIcon: string;
    /**
     * style between input and icon beside it
     */
    fieldInlineStyle: any;
    get typePassControl(): string;
    ngOnInit(): void;
    togglePassword(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PasswordLeftIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PasswordLeftIconComponent, "app-password-left-icon", never, {}, {}, never, never>;
}
