import { OnInit } from '@angular/core';
import { FormlyFieldConfig } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class DebugFormlyComponent implements OnInit {
    fields: FormlyFieldConfig[];
    model: {
        [key: string]: any;
    };
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DebugFormlyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DebugFormlyComponent, "app-debug-formly", never, { "fields": "fields"; "model": "model"; }, {}, never, never>;
}
