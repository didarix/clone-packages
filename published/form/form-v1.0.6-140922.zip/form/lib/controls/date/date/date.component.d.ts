import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class DateComponent extends FieldType {
    static ɵfac: i0.ɵɵFactoryDeclaration<DateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DateComponent, "app-date", never, {}, {}, never, never>;
}
