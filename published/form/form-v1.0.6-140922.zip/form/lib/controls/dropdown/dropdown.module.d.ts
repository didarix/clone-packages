import * as i0 from "@angular/core";
import * as i1 from "./dropdown/dropdown.component";
import * as i2 from "@angular/common";
import * as i3 from "@youxel/core";
import * as i4 from "@ngx-translate/core";
import * as i5 from "@angular/forms";
import * as i6 from "../wrapper-formly-field/wrapper-formly-field.module";
import * as i7 from "../../shared/shared.module";
import * as i8 from "@ngx-formly/core";
export declare class DropdownModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DropdownModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DropdownModule, [typeof i1.DropdownComponent], [typeof i2.CommonModule, typeof i3.YouxelCoreModule, typeof i4.TranslateModule, typeof i5.FormsModule, typeof i5.ReactiveFormsModule, typeof i6.WrapperFormlyFieldModule, typeof i7.SharedModule, typeof i8.FormlyModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DropdownModule>;
}
