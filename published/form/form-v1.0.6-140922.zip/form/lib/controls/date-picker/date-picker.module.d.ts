import * as i0 from "@angular/core";
import * as i1 from "./date-picker/date-picker.component";
import * as i2 from "@angular/common";
import * as i3 from "@youxel/core";
import * as i4 from "../../shared/shared.module";
import * as i5 from "../wrapper-formly-field/wrapper-formly-field.module";
import * as i6 from "@ngx-translate/core";
import * as i7 from "ngx-material-timepicker";
import * as i8 from "@ngx-formly/core";
export declare class DatePickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DatePickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DatePickerModule, [typeof i1.DatePickerComponent], [typeof i2.CommonModule, typeof i3.YouxelCoreModule, typeof i4.SharedModule, typeof i5.WrapperFormlyFieldModule, typeof i6.TranslateModule, typeof i7.NgxMaterialTimepickerModule, typeof i8.FormlyModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DatePickerModule>;
}
