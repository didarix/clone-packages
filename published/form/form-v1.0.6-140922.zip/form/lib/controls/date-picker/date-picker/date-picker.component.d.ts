import { OnInit } from '@angular/core';
import { FieldType, FieldTypeConfig, FormlyTemplateOptions } from '@ngx-formly/core';
import { IDatePicker, DateType } from '../datepicker.interface';
import { NgModel } from '@angular/forms';
import { PrimeNGConfig } from 'primeng/api';
import { LanguageService } from '@youxel/core';
import * as i0 from "@angular/core";
interface DatePickerSettings extends IDatePicker, FormlyTemplateOptions {
}
export declare class DatePickerComponent extends FieldType<FieldTypeConfig> implements OnInit {
    private config;
    private translate;
    key: string;
    to: DatePickerSettings;
    dateFormat: string;
    dateType: DateType;
    minDate: string | Date;
    maxDate: string | Date;
    startDateValue: string | Date;
    endDateValue: string | Date | undefined;
    defaultTimeValue: string;
    startTimeValue: string;
    endTimeValue: string;
    private fullDateFormat;
    private get _minDate();
    private get _maxDate();
    get showIcon(): boolean;
    get optionsClass(): {
        'with-time': boolean;
        'date-range': boolean;
    };
    get hoursCount(): number;
    get daysCount(): number;
    get businessDaysCount(): number;
    get isEndDateRequired(): boolean;
    endDateControl: NgModel;
    constructor(config: PrimeNGConfig, translate: LanguageService);
    ngOnInit(): void;
    /**
     *
     * @description set the default date value based on given form control value.
     */
    setDefaultDateValue(): void;
    /**
     *
     * @description set the date-picker translation based on translation property in the template options atherwise Arabic translation
     */
    handleTranslation(): void;
    /**
     *
     * @description update the date-picker value in case the `dateType` is `datepicker`.
     * @description update the date-picker value with start date value in case the `dateType` is `daterangepicker` || `datetimerangepicker`.
     *  and check if the start date is after the end date, then should reset the end date value.
     */
    updateStartDateValue(): void;
    /**
     *
     * @description update the date-picker value with end date value in case the `dateType` is `daterangepicker` || `datetimerangepicker`.
     */
    updateEndDateValue(): void;
    /**
     *
     * @description generate start date value based on start time value and hanle the start time minimum & maximum value.
     */
    getStartTime(): void;
    /**
     *
     * @description generate end date value based on end time value and hanle the end time minimum & maximum value.
     */
    getEndTime(): void;
    /**
     * @description set the date value with selected time to the form control in all cases.
     */
    private setDateValue;
    /**
     *
     * @description set the minimum time for the end time timepicker to the start time if the end time is bigger than the start time.
     */
    private handleMinEndTime;
    /**
     *
     * @description reset end date value if the start date in bigger than end date.
     */
    private resetEndDateValue;
    /**
     *
     * @param date typeof native Date format
     * @param time typeof string
     * @description format the given date with the specific given time
     * @returns `Object` of 4 properties with 4 different formats - `withSelectedTimeDateFormat`, `withSelectedTimeFullDateFormat`
     */
    private formatDate;
    /**
     *
     * @param date typeof any
     * @description check if the given date is instanceof native Date format OR not!.
     * @returns `boolean`
     */
    private isIstanceOfDate;
    /**
     *
     * @param date typeof string
     * @param dateFormat typeof string
     * @description convert the given date based on given format to native Date format.
     * @returns native `Date` format
     */
    private parseDate;
    /**
     *
     * @param date typeof string
     * @param dateFormat typeof string
     * @description check if the given date is valid or not.
     * @returns `Boolean`
     */
    private isValidDate;
    /**
     *
     * @param date typeof native Date Format
     * @returns `string` the selected date with a full date format
     */
    private convertDateToFullDateFormat;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatePickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DatePickerComponent, "app-date-picker", never, {}, {}, never, never>;
}
export {};
