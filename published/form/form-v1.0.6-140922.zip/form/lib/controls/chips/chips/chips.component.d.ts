import { OnInit } from '@angular/core';
import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class ChipsComponent extends FieldType implements OnInit {
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChipsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChipsComponent, "app-chips", never, {}, {}, never, never>;
}
