import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class numbersComponenet extends FieldType {
    static ɵfac: i0.ɵɵFactoryDeclaration<numbersComponenet, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<numbersComponenet, "app-numbers", never, {}, {}, never, never>;
}
