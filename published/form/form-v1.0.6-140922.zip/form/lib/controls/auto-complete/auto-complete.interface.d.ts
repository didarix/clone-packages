import { TemplateRef } from "@angular/core";
export interface IAutoComplete {
    labelPropertyName?: string | null;
    itemTemplate?: TemplateRef<any>;
    selectedItemTemplate?: TemplateRef<any>;
    multiple?: boolean;
    dropdownIcon?: string;
    dropdownMode?: string;
    autofocus?: boolean;
    forceSelection?: boolean;
    style?: string;
    styleClass?: string;
    inputStyle?: string;
    inputStyleClass?: string;
    panelStyle?: string;
    panelStyleClass?: string;
    optionGroupLabel?: string;
    group?: boolean;
    optionGroupChildren?: string;
    inputType?: string;
    emptyMessage?: string;
    showEmptyMessage?: boolean;
    showTransitionOptions?: string;
    hideTransitionOptions?: string;
    onSelect: (event: any) => {};
    onUnselect: (event: any) => {};
    onClear: (event: any) => {};
    onLazyLoad: (event: any) => {};
    APIConfig?: {
        type: 'post' | 'get';
        URL: string;
        responseProperty?: string;
        paramsPropertyName?: string;
        bodyPropertyName?: string;
        params?: any;
        body?: any;
    };
}
