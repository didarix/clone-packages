import { FieldType } from '@ngx-formly/core';
import { EPeriodTime, ERangeTime } from '../range-time';
import * as i0 from "@angular/core";
export declare class RangeTimeComponent extends FieldType {
    get fieldFormControl(): import("@angular/forms").AbstractControl;
    get rangeTimeFrom(): any;
    get rangeTimeTo(): any;
    get EPeriodTime(): typeof EPeriodTime;
    get ERangeTime(): typeof ERangeTime;
    selected: boolean;
    togglePopup(event: any, op: any): void;
    selectToPeriod(period: typeof EPeriodTime): void;
    selectFromPeriod(period: typeof EPeriodTime): void;
    onChangeMinutes(type: ERangeTime, value: any): void;
    onChangeHours(type: ERangeTime, value: any): void;
    setControlValue(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RangeTimeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RangeTimeComponent, "app-range-time", never, {}, {}, never, never>;
}
