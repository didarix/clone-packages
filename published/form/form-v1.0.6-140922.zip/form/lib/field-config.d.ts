import { FormlyFieldConfig, FormlyTemplateOptions } from '@ngx-formly/core';
import { DateControl, Dropdown, IAutoComplete, Toggle, WrapperFomlyField, IDatePicker } from './controls';
import { IRangeTime } from './enums/time-range.enum';
export interface FieldConfig extends FormlyFieldConfig {
    templateOptions?: ToFormly<IAutoComplete & IDatePicker & Dropdown & FormlyTemplateOptions>;
    fieldGroup?: FieldConfig[];
    fieldArray?: FieldConfig;
}
export declare type ToFormly<T> = T & {
    toggle?: Toggle;
    fieldConfig?: WrapperFomlyField;
    date?: DateControl;
    rangeTime?: IRangeTime;
};
