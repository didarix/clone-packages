import { OnInit } from '@angular/core';
import { FieldType, FieldTypeConfig } from '@ngx-formly/core';
import { HttpService } from '@youxel/core';
import { Observable } from 'rxjs';
import { FieldConfig } from '../../../field-config';
import * as i0 from "@angular/core";
declare type DropdownSettings = FieldConfig['templateOptions'];
export declare class DropdownComponent extends FieldType<FieldTypeConfig> implements OnInit {
    private http;
    to: DropdownSettings;
    /**
     * @description dropdown options.
     */
    dropdownOptions: Observable<any[]>;
    constructor(http: HttpService);
    ngOnInit(): void;
    onSelectItem(selectedOption: {
        value: any;
    }): void;
    onFilter(event: any): void;
    onClear(event: any): void;
    /**
     *
     * @param query search value
     * @descriptions search in the server options array based on entered value
     * @returns filtered options
     */
    private callServerSideAPI;
    /**
     *
     * @param response API response
     * @returns the data based on nested properties
     */
    private getDataFromResponse;
    static ɵfac: i0.ɵɵFactoryDeclaration<DropdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DropdownComponent, "app-dropdown", never, {}, {}, never, never>;
}
export {};
