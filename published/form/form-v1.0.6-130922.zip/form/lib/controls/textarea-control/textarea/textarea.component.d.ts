import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class TextareaComponent extends FieldType {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextareaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextareaComponent, "app-textarea", never, {}, {}, never, never>;
}
