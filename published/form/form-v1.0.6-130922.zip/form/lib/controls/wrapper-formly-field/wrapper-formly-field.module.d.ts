import * as i0 from "@angular/core";
import * as i1 from "./formly-wrapper-form-field/formly-wrapper-form-field.component";
import * as i2 from "./formly-validation-message/formly-validation-message.component";
import * as i3 from "./value-under-dropdown/value-under-dropdown.component";
import * as i4 from "@angular/common";
import * as i5 from "@youxel/core";
import * as i6 from "../../shared/shared.module";
import * as i7 from "@ngx-formly/core";
export declare class WrapperFormlyFieldModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<WrapperFormlyFieldModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<WrapperFormlyFieldModule, [typeof i1.FormlyWrapperFormFieldComponent, typeof i2.FormlyValidationMessage, typeof i3.ValueUnderDropdownComponent], [typeof i4.CommonModule, typeof i5.YouxelCoreModule, typeof i6.SharedModule, typeof i7.FormlyModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<WrapperFormlyFieldModule>;
}
