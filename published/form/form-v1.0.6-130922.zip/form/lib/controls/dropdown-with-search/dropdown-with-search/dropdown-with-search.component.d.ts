import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class DropdownWithSearchComponent extends FieldType {
    static ɵfac: i0.ɵɵFactoryDeclaration<DropdownWithSearchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DropdownWithSearchComponent, "app-dropdown-with-search", never, {}, {}, never, never>;
}
