import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class TapsComponent extends FieldType {
    static ɵfac: i0.ɵɵFactoryDeclaration<TapsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TapsComponent, "app-taps", never, {}, {}, never, never>;
}
