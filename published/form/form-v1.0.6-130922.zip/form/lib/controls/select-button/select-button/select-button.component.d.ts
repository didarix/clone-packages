import { OnInit } from '@angular/core';
import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class SelectButtonComponent extends FieldType implements OnInit {
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SelectButtonComponent, "app-select-button", never, {}, {}, never, never>;
}
