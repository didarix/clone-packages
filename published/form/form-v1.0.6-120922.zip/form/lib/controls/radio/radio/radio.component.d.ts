import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class RadioComponent extends FieldType {
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioComponent, "app-radio", never, {}, {}, never, never>;
}
