import * as i0 from "@angular/core";
import * as i1 from "./taps/taps.component";
import * as i2 from "@angular/common";
import * as i3 from "@youxel/core";
import * as i4 from "../../shared/shared.module";
import * as i5 from "@ngx-formly/core";
export declare class TapsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TapsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TapsModule, [typeof i1.TapsComponent], [typeof i2.CommonModule, typeof i3.YouxelCoreModule, typeof i4.SharedModule, typeof i5.FormlyModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TapsModule>;
}
