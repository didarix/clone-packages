import { OnInit } from '@angular/core';
import { FieldType, FieldTypeConfig, FormlyTemplateOptions } from '@ngx-formly/core';
import { HttpService } from '@youxel/core';
import { Observable } from 'rxjs';
import { IAutoComplete } from '../auto-complete.interface';
import * as i0 from "@angular/core";
interface IAutoCompleteConfig extends IAutoComplete, FormlyTemplateOptions {
}
export declare class AutoCompleteComponent extends FieldType<FieldTypeConfig> implements OnInit {
    private http;
    to: IAutoCompleteConfig;
    suggestions: Observable<string[] | any[]>;
    baseSuggestions: Observable<string[] | any[]>;
    labelPropertyName: string | null;
    constructor(http: HttpService);
    ngOnInit(): void;
    /**
     *
     * @param event
     * @description handle the search logic for the suggestions options
     */
    search(event: {
        query: string;
    }): void;
    /**
     *
     * @param event
     * @description handle on select event emitter
     */
    onSelect(event: any): void;
    /**
     *
     * @param event
     * @description handle on unselect event emitter
     */
    onUnselect(event: any): void;
    /**
     *
     * @param event
     * @description handle on clear event emitter
     */
    onClear(event: any): void;
    /**
     *
     * @param event
     * @description handle on lazy load event emitter
     */
    onLazyLoad(event: any): void;
    /**
     *
     * @param option each option of the options
     * @param query search value
     * @descriptions search in the local options array based on entered value
     * @returns filtered options
     */
    private filterClientSide;
    /**
     *
     * @param query search value
     * @descriptions search in the server options array based on entered value
     * @returns filtered options
     */
    private filterServerSide;
    /**
     *
     * @param response API response
     * @returns the data based on nested properties
     */
    private getDataFromResponse;
    static ɵfac: i0.ɵɵFactoryDeclaration<AutoCompleteComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AutoCompleteComponent, "app-auto-complete", never, {}, {}, never, never>;
}
export {};
