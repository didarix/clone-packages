import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class PasswordComponent extends FieldType {
    static ɵfac: i0.ɵɵFactoryDeclaration<PasswordComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PasswordComponent, "app-password", never, {}, {}, never, never>;
}
