export interface WrapperFomlyField {
    leftIcon?: string;
    rightIcon?: string;
    labelIcon?: string;
    labelClassName?: string;
    descriptionClassName?: string;
    containerControlClassName?: string;
    errorClassName?: string;
    controlClassName?: string;
    showValueUnderDropdown?: boolean;
}
