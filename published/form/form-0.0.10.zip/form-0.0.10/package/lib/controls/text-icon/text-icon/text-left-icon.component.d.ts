import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class TextIconComponent extends FieldType {
    defaultIcon: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextIconComponent, "app-text-left-icon", never, {}, {}, never, never>;
}
