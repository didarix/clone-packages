import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class PasswordLeftIconComponent extends FieldType {
    passwordVisiblity: boolean;
    defaultIcon: string;
    togglePassword(): void;
    get typePassControl(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PasswordLeftIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PasswordLeftIconComponent, "app-password-left-icon", never, {}, {}, never, never>;
}
