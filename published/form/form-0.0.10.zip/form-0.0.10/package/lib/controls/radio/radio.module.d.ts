import * as i0 from "@angular/core";
import * as i1 from "./radio/radio.component";
import * as i2 from "@angular/common";
import * as i3 from "@youxel/core";
import * as i4 from "../../shared/shared.module";
import * as i5 from "@ngx-formly/core";
import * as i6 from "@ngx-formly/core/select";
export declare class RadioModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RadioModule, [typeof i1.RadioComponent], [typeof i2.CommonModule, typeof i3.YouxelCoreModule, typeof i4.SharedModule, typeof i5.FormlyModule, typeof i6.FormlySelectModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RadioModule>;
}
