import * as i0 from "@angular/core";
import * as i1 from "./editor/editor.component";
import * as i2 from "@angular/common";
import * as i3 from "@youxel/core";
import * as i4 from "../../shared/shared.module";
import * as i5 from "../wrapper-formly-field/wrapper-formly-field.module";
import * as i6 from "@ngx-formly/core";
export declare class EditorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<EditorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EditorModule, [typeof i1.EditorComponent], [typeof i2.CommonModule, typeof i3.YouxelCoreModule, typeof i4.SharedModule, typeof i5.WrapperFormlyFieldModule, typeof i6.FormlyModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EditorModule>;
}
