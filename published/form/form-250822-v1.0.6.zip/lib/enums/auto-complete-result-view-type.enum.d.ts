export declare enum EAutoCompleteResultViewType {
    Default = "default",
    Custom = "custom"
}
