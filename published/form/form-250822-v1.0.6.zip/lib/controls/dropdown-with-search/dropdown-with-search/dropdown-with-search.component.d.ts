import { OnInit } from '@angular/core';
import { FieldType } from '@ngx-formly/core';
import { EAutoCompleteResultViewType } from '../../../enums';
import { IAutoCompleteLocalizedItems } from '../../../interfaces';
import * as i0 from "@angular/core";
export declare class DropdownWithSearchComponent extends FieldType implements OnInit {
    isOpened: boolean;
    isSearchResult: boolean;
    isShowSearchResult: boolean;
    /**
     * localized items default values
     */
    localizedItems: IAutoCompleteLocalizedItems;
    /**
     * result view typeo
     * default
     * custom => require a custom template from the user
     */
    eViewType: typeof EAutoCompleteResultViewType;
    /**
     * on type we receive an event containing to property
     * term and items
     */
    localSearchResults: {
        term: string;
        items: [];
    };
    ngOnInit(): void;
    /**
     * @description `this method is firing when the search emit new value`
     * @param event that out from the search emitter
     */
    getSearchResult(event: any): void;
    /**
     * on clear don't show search result
     */
    doClearSearchResult(): void;
    /**
     * fire on open dropdown control
     */
    handleOpenDropDown(): void;
    /**
     * fire on close dropdown control
     */
    handleCloseDropDown(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DropdownWithSearchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DropdownWithSearchComponent, "app-dropdown-with-search", never, {}, {}, never, never>;
}
