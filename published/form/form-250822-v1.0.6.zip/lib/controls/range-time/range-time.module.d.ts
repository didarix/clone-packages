import * as i0 from "@angular/core";
import * as i1 from "./range-time/range-time.component";
import * as i2 from "@angular/common";
import * as i3 from "@youxel/core";
import * as i4 from "../../shared/shared.module";
import * as i5 from "primeng/overlaypanel";
import * as i6 from "@ngx-formly/core";
export declare class RangeTimeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RangeTimeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RangeTimeModule, [typeof i1.RangeTimeComponent], [typeof i2.CommonModule, typeof i3.YouxelCoreModule, typeof i4.SharedModule, typeof i5.OverlayPanelModule, typeof i6.FormlyModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RangeTimeModule>;
}
