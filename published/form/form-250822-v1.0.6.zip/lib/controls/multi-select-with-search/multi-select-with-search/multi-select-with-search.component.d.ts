import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class MultiSelectWithSearchComponent extends FieldType {
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiSelectWithSearchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MultiSelectWithSearchComponent, "app-multi-select-with-search", never, {}, {}, never, never>;
}
