import * as i0 from "@angular/core";
import * as i1 from "./custom-check-box/custom-check-box.component";
import * as i2 from "@angular/common";
import * as i3 from "@youxel/core";
import * as i4 from "../../shared/shared.module";
import * as i5 from "@ngx-formly/core";
export declare class CustomCheckBoxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomCheckBoxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CustomCheckBoxModule, [typeof i1.CustomCheckBoxComponent], [typeof i2.CommonModule, typeof i3.YouxelCoreModule, typeof i4.SharedModule, typeof i5.FormlyModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CustomCheckBoxModule>;
}
