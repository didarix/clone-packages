import { OnInit } from '@angular/core';
import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class CustomCheckBoxComponent extends FieldType implements OnInit {
    valCheckBox: boolean;
    ngOnInit(): void;
    updateValue(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomCheckBoxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomCheckBoxComponent, "app-custom-check-box", never, {}, {}, never, never>;
}
