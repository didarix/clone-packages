import * as i0 from "@angular/core";
import * as i1 from "./textarea/textarea.component";
import * as i2 from "@angular/common";
import * as i3 from "@youxel/core";
import * as i4 from "../../shared/shared.module";
import * as i5 from "../wrapper-formly-field/wrapper-formly-field.module";
import * as i6 from "@ngx-formly/core";
export declare class TextareaControlModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextareaControlModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TextareaControlModule, [typeof i1.TextareaComponent], [typeof i2.CommonModule, typeof i3.YouxelCoreModule, typeof i4.SharedModule, typeof i5.WrapperFormlyFieldModule, typeof i6.FormlyModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TextareaControlModule>;
}
