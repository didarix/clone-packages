import * as i0 from "@angular/core";
import * as i1 from "./chips/chips.component";
import * as i2 from "@angular/common";
import * as i3 from "@youxel/core";
import * as i4 from "@ngx-formly/core";
export declare class ChipsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ChipsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ChipsModule, [typeof i1.ChipsComponent], [typeof i2.CommonModule, typeof i3.YouxelCoreModule, typeof i4.FormlyModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ChipsModule>;
}
