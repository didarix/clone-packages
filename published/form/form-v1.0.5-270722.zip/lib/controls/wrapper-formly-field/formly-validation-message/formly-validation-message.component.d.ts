import { OnChanges } from '@angular/core';
import { FormlyConfig, FormlyFieldConfig } from '@ngx-formly/core';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class FormlyValidationMessage implements OnChanges {
    private config;
    field: FormlyFieldConfig;
    errorMessage$: Observable<string>;
    constructor(config: FormlyConfig);
    ngOnChanges(): void;
    get errorMessage(): string | Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormlyValidationMessage, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormlyValidationMessage, "app-formly-validation-message", never, { "field": "field"; }, {}, never, never>;
}
