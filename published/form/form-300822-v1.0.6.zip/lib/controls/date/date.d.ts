export interface DateControl {
    minDate?: Date;
    maxDate?: Date;
    selectOtherMonths?: boolean;
    dateFormate?: string;
    disabledDates?: any[];
    disabledDays?: any[];
}
