import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class ToggleComponent extends FieldType {
    static ɵfac: i0.ɵɵFactoryDeclaration<ToggleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToggleComponent, "app-toggle", never, {}, {}, never, never>;
}
