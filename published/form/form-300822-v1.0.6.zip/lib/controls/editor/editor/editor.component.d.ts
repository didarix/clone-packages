import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class EditorComponent extends FieldType {
    static ɵfac: i0.ɵɵFactoryDeclaration<EditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditorComponent, "app-editor", never, {}, {}, never, never>;
}
