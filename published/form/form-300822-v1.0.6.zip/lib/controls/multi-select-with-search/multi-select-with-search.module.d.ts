import * as i0 from "@angular/core";
import * as i1 from "./multi-select-with-search/multi-select-with-search.component";
import * as i2 from "@angular/common";
import * as i3 from "@youxel/core";
import * as i4 from "../../shared/shared.module";
import * as i5 from "../wrapper-formly-field/wrapper-formly-field.module";
import * as i6 from "@ngx-formly/core";
import * as i7 from "@ngx-formly/core/select";
export declare class MultiSelectWithSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiSelectWithSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MultiSelectWithSearchModule, [typeof i1.MultiSelectWithSearchComponent], [typeof i2.CommonModule, typeof i3.YouxelCoreModule, typeof i4.SharedModule, typeof i5.WrapperFormlyFieldModule, typeof i6.FormlyModule, typeof i7.FormlySelectModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MultiSelectWithSearchModule>;
}
