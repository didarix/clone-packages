export interface ILinkField {
    linkValue?: string;
    linkTitle?: string;
    showHyperlinkImg?: boolean;
    icon?: string;
}
