import * as i0 from "@angular/core";
import * as i1 from "./link/link.component";
import * as i2 from "@angular/common";
import * as i3 from "../wrapper-formly-field/wrapper-formly-field.module";
import * as i4 from "@ngx-formly/core";
export declare class LinkModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LinkModule, [typeof i1.LinkComponent], [typeof i2.CommonModule, typeof i3.WrapperFormlyFieldModule, typeof i4.FormlyModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LinkModule>;
}
