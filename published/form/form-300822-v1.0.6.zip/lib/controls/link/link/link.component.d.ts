import { OnInit } from '@angular/core';
import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class LinkComponent extends FieldType implements OnInit {
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LinkComponent, "app-link", never, {}, {}, never, never>;
}
