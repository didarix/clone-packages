import { OnInit } from '@angular/core';
import { FormlyFieldConfig } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class YouxelFormComponent implements OnInit {
    form: any;
    fields: FormlyFieldConfig[];
    model: {
        [key: string]: any;
    };
    debug: boolean;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<YouxelFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<YouxelFormComponent, "app-youxel-form", never, { "form": "form"; "fields": "fields"; "model": "model"; "debug": "debug"; }, {}, never, never>;
}
