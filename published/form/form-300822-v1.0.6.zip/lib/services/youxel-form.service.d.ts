import * as i0 from "@angular/core";
export declare class YouxelFormService {
    private config;
    module: any;
    SearchUserWithListModule: any;
    constructor(config: any);
    _test(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<YouxelFormService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<YouxelFormService>;
}
