import { FormControl, ValidationErrors } from "@angular/forms";
import { FormlyFieldConfig } from "@ngx-formly/core";
export declare class WhiteSpaceValidator {
    static whiteSpaceValidator(control: FormControl): ValidationErrors;
    static whiteSpaceValidatorMessage(err: any, field: FormlyFieldConfig): string;
}
export declare enum EWhiteSpace {
    WhiteSpace = "whiteSpace"
}
