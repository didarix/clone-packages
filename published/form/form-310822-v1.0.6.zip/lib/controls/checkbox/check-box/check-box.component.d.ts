import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class CheckBoxComponent extends FieldType {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckBoxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckBoxComponent, "app-check-box", never, {}, {}, never, never>;
}
