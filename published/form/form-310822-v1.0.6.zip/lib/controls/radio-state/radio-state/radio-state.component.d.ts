import { FieldType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class RadioStateComponent extends FieldType {
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioStateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioStateComponent, "app-radio-state", never, {}, {}, never, never>;
}
