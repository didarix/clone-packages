export interface ILabelField {
    labelLine: boolean;
    labelLineStyle: object;
}
