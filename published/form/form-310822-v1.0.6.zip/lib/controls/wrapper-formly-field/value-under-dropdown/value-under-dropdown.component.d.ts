import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ValueUnderDropdownComponent implements OnInit {
    fieldControl: any;
    listOfValue: any[];
    constructor();
    ngOnInit(): void;
    remove(itemIndex: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ValueUnderDropdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ValueUnderDropdownComponent, "app-value-under-dropdown", never, { "fieldControl": "fieldControl"; }, {}, never, never>;
}
