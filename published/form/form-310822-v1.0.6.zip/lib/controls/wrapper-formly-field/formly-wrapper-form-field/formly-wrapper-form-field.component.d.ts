import { ChangeDetectorRef, OnInit } from '@angular/core';
import { FieldWrapper } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class FormlyWrapperFormFieldComponent extends FieldWrapper implements OnInit {
    private changeDetectorRef;
    constructor(changeDetectorRef: ChangeDetectorRef);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormlyWrapperFormFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormlyWrapperFormFieldComponent, "app-formly-wrapper-form-field", never, {}, {}, never, never>;
}
