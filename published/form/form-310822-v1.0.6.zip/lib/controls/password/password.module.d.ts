import * as i0 from "@angular/core";
import * as i1 from "./password/password.component";
import * as i2 from "@angular/common";
import * as i3 from "@youxel/core";
import * as i4 from "../../shared/shared.module";
import * as i5 from "@ngx-translate/core";
import * as i6 from "@ngx-formly/core";
export declare class PasswordModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PasswordModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PasswordModule, [typeof i1.PasswordComponent], [typeof i2.CommonModule, typeof i3.YouxelCoreModule, typeof i4.SharedModule, typeof i5.TranslateModule, typeof i6.FormlyModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PasswordModule>;
}
