export interface Toggle {
    activeColor?: string;
}
