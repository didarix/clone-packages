import * as i0 from "@angular/core";
import * as i1 from "./repeat/repeat.component";
import * as i2 from "@angular/common";
import * as i3 from "@youxel/core";
import * as i4 from "../wrapper-formly-field/wrapper-formly-field.module";
import * as i5 from "@ngx-formly/core";
export declare class RepeatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RepeatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RepeatModule, [typeof i1.RepeatComponent], [typeof i2.CommonModule, typeof i3.YouxelCoreModule, typeof i4.WrapperFormlyFieldModule, typeof i5.FormlyModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RepeatModule>;
}
