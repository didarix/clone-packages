import { OnInit } from '@angular/core';
import { FormArray } from '@angular/forms';
import { FieldArrayType } from '@ngx-formly/core';
import * as i0 from "@angular/core";
export declare class RepeatComponent extends FieldArrayType implements OnInit {
    /***
     * @description get formArray control by key
     */
    get formArray(): FormArray;
    constructor();
    ngOnInit(): void;
    /**
     * @description
     * patch value if the defaultValue to the array if key not = 0
     */
    patchFormArrayData(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RepeatComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RepeatComponent, "app-repeat", never, {}, {}, never, never>;
}
